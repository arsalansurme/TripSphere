"""
Automated Test Suite for TripSphere AI Travel Assistant.
Tests all 10 scenarios specified in the prompt plus multi-turn memory updates and tool registry functions.
"""
import os
import sys

# Add project root to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.services.assistant_agent import assistant_agent, TravelToolRegistry
from app.services.travel_providers import travel_provider_service
from app.services.trip_service import trip_service
from app.database.repositories import trip_repo, expense_repo


def run_tests():
    print("=" * 60)
    print("STARTING TRIPSPHERE AI ASSISTANT TEST SUITE")
    print("=" * 60)

    passed = 0
    total = 0

    def assert_test(name: str, condition: bool, err_msg: str = ""):
        nonlocal passed, total
        total += 1
        if condition:
            passed += 1
            print(f"  [PASS] {name}")
        else:
            print(f"  [FAIL] {name}: {err_msg}")
            raise AssertionError(f"Test failed: {name} - {err_msg}")

    # TEST 1: Greeting
    print("\n--- TEST 1: Greeting ---")
    assistant_agent.reset()
    r1 = assistant_agent.process_message("Hey")
    assert_test("Greeting contains friendly tone", "Heyyy" in r1.text or "Hello" in r1.text or "master" in r1.text.lower())
    assert_test("Greeting action type is greeting", r1.action_type == "greeting")

    # TEST 2: Travel Discovery
    print("\n--- TEST 2: Travel Discovery ---")
    r2 = assistant_agent.process_message("I want a beach trip")
    assert_test("Identifies Beach style", assistant_agent.state.travel_style == "Beach")
    assert_test("Asks progressive questions", "how many" in r2.text.lower() or "budget" in r2.text.lower() or "days" in r2.text.lower())

    # TEST 3: Multi-turn Context Memory
    print("\n--- TEST 3: Multi-turn Context Memory ---")
    r3 = assistant_agent.process_message("2 people, 5 days, budget ₹50,000 starting from Delhi to Goa")
    assert_test("Remembers travelers", assistant_agent.state.travelers == 2)
    assert_test("Remembers days", assistant_agent.state.days == 5)
    assert_test("Remembers budget", assistant_agent.state.budget == 50000.0)
    assert_test("Remembers destination", assistant_agent.state.destination == "Goa")
    assert_test("Remembers origin", assistant_agent.state.origin == "Delhi")

    # TEST 3b: Context Memory Update (Non-destructive)
    print("\n--- TEST 3b: Memory Update (2 -> 4 travelers) ---")
    r3b = assistant_agent.process_message("Actually make it 4 people")
    assert_test("Updated travelers to 4", assistant_agent.state.travelers == 4)
    assert_test("Preserved destination Goa", assistant_agent.state.destination == "Goa")
    assert_test("Preserved budget 50000", assistant_agent.state.budget == 50000.0)

    # TEST 4: Hotel Search (Zero Fabrication)
    print("\n--- TEST 4: Hotel Search ---")
    r4 = assistant_agent.process_message("Find me hotels")
    assert_test("Hotel search produces cards", len(r4.cards) > 0)
    assert_test("Honest disclaimer when disconnected", "live booking availability isn't connected yet" in r4.text.lower() or "live hotel inventory" in r4.text.lower())
    # Verify no fabricated fake price
    for c in r4.cards:
        assert_test("Card has price_display or None price_estimated", c.get("price_estimated") is None or "price_display" in c)

    # TEST 5: Flight Search (Zero Fabrication)
    print("\n--- TEST 5: Flight Search ---")
    r5 = assistant_agent.process_message("Find flights")
    assert_test("Flight search produces cards", len(r5.cards) > 0)
    assert_test("Honest flight disclaimer", "live booking availability isn't connected yet" in r5.text.lower() or "live provider" in r5.text.lower())
    for c in r5.cards:
        assert_test("Flight card has official search portal url", "google.com/travel/flights" in c.get("booking_url", ""))

    # TEST 6: Route Planning
    print("\n--- TEST 6: Route Planning ---")
    r6 = assistant_agent.process_message("Plan a route from Madrid to Barcelona")
    assert_test("Calculates route distance", r6.cards and r6.cards[0].get("distance_km", 0) > 400)
    assert_test("Map action emitted with coordinates", r6.map_action and len(r6.map_action.get("coords", [])) > 2)

    # TEST 7: Structured Plan & Trip Creation
    print("\n--- TEST 7: Trip Creation ---")
    r7_plan = assistant_agent.process_message("Plan my trip with an itinerary")
    assert_test("Generated structured plan", len(assistant_agent.state.generated_plan) > 0)
    r7_save = assistant_agent.process_message("Save this trip to Itineraries")
    assert_test("Trip saved to DB", r7_save.action_type == "trip_created")
    # Verify trip in database
    all_trips = trip_service.get_all_trips()
    assert_test("DB contains saved trip", any(assistant_agent.state.destination in t.get("name", "") or assistant_agent.state.destination in t.get("destination", "") for t in all_trips))

    # TEST 8: Invalid Location Handling
    print("\n--- TEST 8: Invalid Location Handling ---")
    r8 = assistant_agent.process_message("where is Zxqvbnmlkjasd99999")
    assert_test("Handles invalid location gracefully", "couldn't locate" in r8.text.lower() or "error" in r8.action_type)

    # TEST 9: Provider / API Disconnected Status
    print("\n--- TEST 9: Provider Disconnected Status ---")
    bk_status = travel_provider_service.execute_booking("flight", "fl_1", {"booking_url": "https://google.com"}, confirmed_by_user=True)
    assert_test("Unconnected provider informs user honestly", bk_status["status"] == "unconnected_provider")
    assert_test("No fake booking ID generated", bk_status.get("booking_id") is None)
    assert_test("Provides redirect URL", "google.com" in bk_status.get("redirect_url", ""))

    # TEST 10: Booking Safety & Confirmation Flow
    print("\n--- TEST 10: Booking Safety & Confirmation Flow ---")
    flight_card = r5.cards[0]
    r10_sel = assistant_agent.initiate_selection("flight", flight_card)
    assert_test("Requires explicit confirmation", r10_sel.action_type == "confirmation")
    assert_test("Pending action is set", assistant_agent.state.pending_action is not None)

    # Confirmation with 'cancel'
    r10_cancel = assistant_agent.process_message("cancel")
    assert_test("Cancelled without reservation", assistant_agent.state.pending_action is None)

    # Reselect and confirm
    assistant_agent.initiate_selection("flight", flight_card)
    r10_conf = assistant_agent.process_message("yes, confirm")
    assert_test("Confirmed and reported status", r10_conf.action_type == "booking_result")

    # TEST 11: Expense Logging
    print("\n--- TEST 11: Expense Logging ---")
    r11 = assistant_agent.process_message("Add expense ₹1,500 for dinner")
    assert_test("Logged expense successfully", r11.action_type == "expense_added")

    # TEST 12: Tool Registry direct execution
    print("\n--- TEST 12: TravelToolRegistry Decoupled Tests ---")
    loc_tool = TravelToolRegistry.search_location("Paris")
    assert_test("Tool search_location works", loc_tool["found"] and abs(loc_tool["latitude"] - 48.85) < 0.5)

    fl_tool = TravelToolRegistry.search_flights("Delhi", "Dubai")
    assert_test("Tool search_flights works", len(fl_tool["results"]) > 0)

    print("\n" + "=" * 60)
    print(f"ALL {passed}/{total} TESTS PASSED SUCCESSFULLY!")
    print("=" * 60)


if __name__ == "__main__":
    run_tests()
