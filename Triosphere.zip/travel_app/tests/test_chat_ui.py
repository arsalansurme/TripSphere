"""
UI Test for ChatScreen in TripSphere.
"""
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from PySide6.QtWidgets import QApplication
from app.ui.chat import ChatScreen


def test_chat_ui():
    app = QApplication.instance()
    if not app:
        app = QApplication(sys.argv)

    screen = ChatScreen()
    assert screen is not None
    print("[PASS] ChatScreen created successfully")

    # Simulate submitting user text
    screen._submit_user_text("Hey")
    print("[PASS] Greeting processed and rendered in UI")

    screen._submit_user_text("Find flights from Mumbai to Goa")
    print("[PASS] Flight cards rendered in UI")

    screen._submit_user_text("Find hotels in Goa")
    print("[PASS] Hotel cards rendered in UI")

    screen._submit_user_text("Show me the route from Mumbai to Goa")
    print("[PASS] Route card rendered in UI")

    screen._clear_conversation()
    print("[PASS] Clear conversation reset successfully")

    screen.cleanup()
    print("[PASS] Cleanup called cleanly")
    print("ALL CHAT UI TESTS PASSED!")


if __name__ == "__main__":
    test_chat_ui()
