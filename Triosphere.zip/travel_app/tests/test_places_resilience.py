import os
import sys
import time
import unittest
from unittest.mock import patch, MagicMock
import requests

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from app.api.places import places_service, PlacesService, OVERPASS_CONNECT_TIMEOUT, OVERPASS_READ_TIMEOUT
from app.ui.explore import NearbyWorker

class TestPlacesResilience(unittest.TestCase):
    def setUp(self):
        places_service.clear_cache()

    def test_timeouts_are_fast_and_reasonable(self):
        """Verify connection and read timeouts are short to prevent UI stalling."""
        self.assertLessEqual(OVERPASS_CONNECT_TIMEOUT, 3.0)
        self.assertLessEqual(OVERPASS_READ_TIMEOUT, 4.0)

    def test_overpass_504_gateway_timeout_fallback(self):
        """Simulate Overpass 504 Gateway Timeout and verify fast fallback."""
        mock_resp_504 = MagicMock()
        mock_resp_504.status_code = 504
        
        svc = PlacesService()
        t0 = time.time()
        with patch("requests.post", return_value=mock_resp_504):
            # Query Mumbai (has SQLite fallback)
            res = svc.get_nearby(19.0760, 72.8777, category="Attractions", radius_m=5000, limit=5)
            dt = time.time() - t0

        self.assertLess(dt, 3.0, f"504 handling took too long: {dt:.2f}s")
        self.assertIsInstance(res, list)
        self.assertGreater(len(res), 0, "Should fall back to SQLite seeded places for Mumbai")
        self.assertEqual(res[0]["source"], "db")

    def test_overpass_read_timeout_fallback(self):
        """Simulate Overpass ReadTimeout and verify fast fallback."""
        svc = PlacesService()
        t0 = time.time()
        with patch("requests.post", side_effect=requests.exceptions.ReadTimeout("Simulated Overpass read timeout")):
            res = svc.get_nearby(19.0760, 72.8777, category="Restaurants", radius_m=3000, limit=5)
            dt = time.time() - t0

        self.assertLess(dt, 2.0, f"Read timeout handling took too long: {dt:.2f}s")
        self.assertIsInstance(res, list)
        self.assertGreater(len(res), 0, "Should fall back to SQLite seeded places")

    def test_places_caching_returns_instantaneously(self):
        """Verify successful queries are cached and return in < 0.01s."""
        fake_places = [
            {"name": "Eiffel Tower", "lat": 48.8584, "lon": 2.2945, "category": "Attractions", "source": "osm"}
        ]
        svc = PlacesService()
        cache_key = (round(48.8566, 3), round(2.3522, 3), "Attractions", 5000, 10)
        svc._cache[cache_key] = (time.time(), fake_places)

        t0 = time.time()
        res = svc.get_nearby(48.8566, 2.3522, category="Attractions", radius_m=5000, limit=10)
        dt = time.time() - t0

        self.assertLess(dt, 0.01, f"Cached query took too long: {dt:.4f}s")
        self.assertEqual(len(res), 1)
        self.assertEqual(res[0]["name"], "Eiffel Tower")

    def test_unknown_location_504_sets_friendly_error(self):
        """When an unknown location has no DB fallback and Overpass 504s, sets last_query_error."""
        mock_resp_504 = MagicMock()
        mock_resp_504.status_code = 504

        svc = PlacesService()
        with patch("requests.post", return_value=mock_resp_504):
            # Remote ocean coordinates (no nearby DB destination within 200km)
            res = svc.get_nearby(0.0, 0.0, category="Attractions", radius_m=5000, limit=5)

        self.assertEqual(res, [])
        self.assertEqual(svc.last_query_error, "Places couldn't be loaded right now.")

    def test_nearby_worker_resolves_and_emits(self):
        """Verify NearbyWorker executes in worker thread without blocking."""
        worker = NearbyWorker(19.0760, 72.8777, "Attractions", 5000, request_id=42, loc_name="Mumbai")
        finished_data = []
        error_data = []

        worker.finished.connect(lambda d: finished_data.append(d))
        worker.error.connect(lambda d: error_data.append(d))

        worker.run()
        self.assertEqual(len(finished_data), 1)
        self.assertEqual(finished_data[0]["request_id"], 42)
        self.assertGreater(len(finished_data[0]["places"]), 0)

if __name__ == "__main__":
    unittest.main()
