"""
Phase 2A — Gemini Connection Test
===================================
Minimal script that:
  1. Loads the project .env (so GEMINI_API_KEY is available).
  2. Calls gemini_client.chat() with a specific test message.
  3. Prints the result clearly without ever printing the API key.
  4. Exits with code 0 on success, 1 on failure.

Run from the travel_app/ project root:
    python -m tests.test_gemini_connection
or:
    python tests/test_gemini_connection.py
"""
import logging
import os
import sys
from pathlib import Path

# ── Bootstrap: ensure project root is on sys.path and .env is loaded ──────────
PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

# Import config first — it calls load_dotenv() which populates os.environ
import app.config  # noqa: F401  (side-effect: loads .env)

# Now we can safely import the Gemini client
from app.services.gemini_client import chat, GEMINI_MODEL

# ── Logging: show INFO+ to console, hide DEBUG (key length logs) ───────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("test_gemini_connection")

def main():
    # ── Safety: confirm key is present WITHOUT printing it ────────────────────────
    api_key_present = bool(os.environ.get("GEMINI_API_KEY", "").strip())
    logger.info("GEMINI_API_KEY present in environment: %s", api_key_present)
    if not api_key_present:
        logger.error("GEMINI_API_KEY is not set. Add it to .env and retry.")
        sys.exit(1)

    # ── Test message ───────────────────────────────────────────────────────────────
    TEST_MESSAGE = (
        "Hello from TripSphere. "
        "Respond with exactly: Gemini connection successful."
    )

    print("\n" + "=" * 60)
    print("TripSphere — Phase 2A: Gemini Connection Test")
    print("=" * 60)
    print(f"Model  : {GEMINI_MODEL}")
    print(f"Message: {TEST_MESSAGE}")
    print("-" * 60)

    response = chat(TEST_MESSAGE)

    print(f"\nSuccess : {response.success}")
    if response.success:
        print(f"Response: {response.text.strip()}")
        if response.usage:
            print(f"Tokens  : in={response.usage.get('input_tokens', '?')}  "
                  f"out={response.usage.get('output_tokens', '?')}")
    else:
        print(f"Error   : {response.error}")

    print("=" * 60 + "\n")

    # Exit code reflects test pass/fail
    if not response.success:
        logger.error("Gemini connection test FAILED: %s", response.error)
        sys.exit(1)

    logger.info("Gemini connection test PASSED.")
    sys.exit(0)


if __name__ == "__main__":
    main()
