"""
Phase 2C Validation Suite — Gemini Tool Calling (search_location).

Verifies:
1. Tool calling works end-to-end:
   User message -> AssistantAgent -> Gemini decides to call search_location ->
   Python executes TravelToolRegistry.search_location -> Gemini gets coordinates ->
   Gemini responds naturally.
2. Direct conversational message without tool:
   Gemini responds directly without invoking search_location.
3. Tool allowlist security:
   Only search_location can be executed; unrecognized tools are safely rejected.
4. Location not found:
   search_location returns found=False; Gemini explains gracefully.
"""
import sys
import os
import time
import logging

# Ensure UTF-8 output on Windows terminal
sys.stdout.reconfigure(encoding="utf-8")
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

logging.basicConfig(level=logging.INFO, format="[%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("test_gemini_tool_calling")

import app.config
from app.services.assistant_agent import AssistantAgent, TravelToolRegistry


def call_with_retry(agent, msg: str, max_retries: int = 4):
    """Execute process_message with backoff if rate limited by free tier."""
    for attempt in range(max_retries):
        resp = agent.process_message(msg)
        if resp.action_type != "error":
            return resp
        wait_time = (attempt + 1) * 12
        logger.warning(f"Error returned (attempt {attempt+1}/{max_retries}). Backing off for {wait_time}s...")
        time.sleep(wait_time)
    return resp


def run_phase_2c_tests():
    print("=" * 70)
    print("PHASE 2C TEST SUITE: GEMINI TOOL CALLING (search_location)")
    print("=" * 70)

    agent = AssistantAgent()

    # -------------------------------------------------------------
    # TEST 1: Direct location query triggers search_location
    # -------------------------------------------------------------
    print("\n--- TEST 1: 'Find Spain.' (Tool Calling) ---")
    r1 = call_with_retry(agent, "Find Spain.")
    print(f"Response: {r1.text[:200]}...")
    assert r1.action_type == "text", f"Expected action_type 'text', got '{r1.action_type}'"
    assert len(r1.text) > 10, "Response text should not be empty"
    # Spain or Madrid or Iberian should be mentioned
    assert any(term in r1.text.lower() for term in ["spain", "madrid", "iberian", "europe", "40"]), (
        f"Response did not mention expected location details: {r1.text}"
    )
    print("[PASS] Test 1: Spain found via tool calling.")

    # -------------------------------------------------------------
    # TEST 2: General conversation does NOT trigger unnecessary tool
    # -------------------------------------------------------------
    print("\n--- TEST 2: General conversation (No Tool Expected) ---")
    time.sleep(3)  # Respect free tier rate limits
    r2 = call_with_retry(agent, "Hi! I'm thinking of planning a vacation next month.")
    print(f"Response: {r2.text[:200]}...")
    assert r2.action_type == "text", f"Expected action_type 'text', got '{r2.action_type}'"
    assert len(r2.text) > 10, "Response text should not be empty"
    print("[PASS] Test 2: General conversation succeeded.")

    # -------------------------------------------------------------
    # TEST 3: Unknown location handling
    # -------------------------------------------------------------
    print("\n--- TEST 3: Unknown location 'Zxqvbnmlkjasd99999' ---")
    time.sleep(3)  # Respect free tier rate limits
    r3 = call_with_retry(agent, "Where is Zxqvbnmlkjasd99999?")
    print(f"Response: {r3.text[:200]}...")
    assert r3.action_type == "text", f"Expected action_type 'text', got '{r3.action_type}'"
    assert any(term in r3.text.lower() for term in ["couldn't", "not find", "unable", "unknown", "doesn't seem", "cannot find", "sorry", "locate", "zxqvbnmlkjasd"]), (
        f"Response did not handle missing location gracefully: {r3.text}"
    )
    print("[PASS] Test 3: Unknown location handled gracefully.")

    # -------------------------------------------------------------
    # TEST 4: Tool allowlist security
    # -------------------------------------------------------------
    print("\n--- TEST 4: Security Allowlist Verification ---")
    # Verify _execute_tool rejects tools not in _TOOL_ALLOWLIST
    bad_result = agent._execute_tool("os_system", {"cmd": "dir"})
    assert bad_result.get("success") is False, "Security fail: unpermitted tool executed"
    assert "not available" in bad_result.get("error", "").lower(), "Expected not available error message"

    # Verify search_location works directly
    good_result = agent._execute_tool("search_location", {"query": "Paris"})
    assert good_result.get("found") is True, f"search_location failed: {good_result}"
    assert "Paris" in good_result.get("name", ""), f"Unexpected name: {good_result.get('name')}"
    print("[PASS] Test 4: Tool allowlist and direct execution verified.")

    print("\n" + "=" * 70)
    print("ALL PHASE 2C TESTS PASSED SUCCESSFULLY!")
    print("=" * 70)


if __name__ == "__main__":
    run_phase_2c_tests()
