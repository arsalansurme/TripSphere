"""
Phase 2E Comprehensive Final Test Suite — TripSphere AI Travel Assistant.

Validates all 17 requirements of Phase 2E:
1. Conversational Behavior:
   - "Hey"
   - "How are you?"
   - "Any trip ideas?"
   - "I want a mountain trip."
   - "4 people, ₹100000."
   - "Actually change my budget to ₹120000."
2. Travel Tools Integration:
   - "Find Spain." (search_location)
   - "Show Spain on the map." (show_location_on_map)
   - "Route from Delhi to Jaipur." (get_route)
   - "Find hotels in Goa." (search_hotels)
   - "Find flights from Delhi to Dubai." (search_flights)
   - "Find activities in London." (search_activities)
   - "Create a trip to Goa." (create_trip)
   - "Add ₹5000 hotel expense." (add_expense)
3. Tool Failures & Resilience:
   - "asdfghqwerty123" (unresolvable location handled gracefully)
   - Unknown tool execution rejected by _TOOL_ALLOWLIST
4. Booking Safety Flow:
   - "Find flights to Dubai." -> searches only, NEVER books automatically
   - "Book the cheapest one." -> requires explicit final user confirmation
   - "Yes, confirm" -> executes confirmed booking action safely
5. Architecture & Regression:
   - Verification that DB, trips, expenses, geocoding, routing remain intact
   - No second GUI window / QApplication creation
"""
import os
import sys
import time
import logging

sys.stdout.reconfigure(encoding="utf-8")
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

logging.basicConfig(level=logging.INFO, format="[%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("test_phase_2e")

import app.config
from app.services.assistant_agent import AssistantAgent, TravelToolRegistry
from app.services.trip_service import trip_service
from app.services.expense_service import expense_service


def call_with_retry(agent: AssistantAgent, msg: str, max_retries: int = 4):
    """Execute process_message with exponential backoff on rate limits."""
    for attempt in range(max_retries):
        resp = agent.process_message(msg)
        if resp.action_type != "error":
            return resp
        wait_time = (attempt + 1) * 8
        logger.warning(f"Error/Rate-limit returned. Backing off for {wait_time}s (attempt {attempt+1}/{max_retries})...")
        time.sleep(wait_time)
    return resp


def run_full_phase_2e_tests():
    print("=" * 75)
    print("TRIPSPHERE AI TRAVEL ASSISTANT — PHASE 2E FINAL TEST SUITE")
    print("=" * 75)

    agent = AssistantAgent()
    agent.reset()

    passed = 0
    total = 0

    def assert_test(name: str, condition: bool, details: str = ""):
        nonlocal passed, total
        total += 1
        if condition:
            passed += 1
            print(f"  [PASS] {name}")
        else:
            print(f"  [FAIL] {name}: {details}")
            raise AssertionError(f"Test Failed: {name} | {details}")

    # =========================================================================
    # SECTION 1: CONVERSATIONAL BEHAVIOR & MULTI-TURN MEMORY
    # =========================================================================
    print("\n--- SECTION 1: Conversational Behavior & Memory ---")

    # 1. Greeting
    print("User: 'Hey'")
    r1 = call_with_retry(agent, "Hey")
    print(f"Assistant: {r1.text[:120]}...")
    assert_test("1. Greeting succeeds", len(r1.text) > 5)
    time.sleep(2)

    # 2. How are you
    print("User: 'How are you?'")
    r2 = call_with_retry(agent, "How are you?")
    print(f"Assistant: {r2.text[:120]}...")
    assert_test("2. How are you response", len(r2.text) > 5)
    time.sleep(2)

    # 3. Any trip ideas
    print("User: 'Any trip ideas?'")
    r3 = call_with_retry(agent, "Any trip ideas?")
    print(f"Assistant: {r3.text[:120]}...")
    assert_test("3. Proactive trip suggestions", len(r3.text) > 10)
    time.sleep(2)

    # 4. Travel style
    print("User: 'I want a mountain trip.'")
    r4 = call_with_retry(agent, "I want a mountain trip.")
    print(f"Assistant: {r4.text[:120]}...")
    assert_test("4. Recognizes mountain travel style", agent.state.travel_style == "Mountains")
    time.sleep(2)

    # 5. Travelers & Budget
    print("User: '4 people, ₹100000.'")
    r5 = call_with_retry(agent, "4 people, ₹100000.")
    print(f"Assistant: {r5.text[:120]}...")
    assert_test("5a. Stores travelers = 4", agent.state.travelers == 4)
    assert_test("5b. Stores budget = 100000", agent.state.budget == 100000.0)
    time.sleep(2)

    # 6. Budget change (Non-destructive update)
    print("User: 'Actually change my budget to ₹120000.'")
    r6 = call_with_retry(agent, "Actually change my budget to ₹120000.")
    print(f"Assistant: {r6.text[:120]}...")
    assert_test("6. Updates budget to 120000 while preserving travelers = 4",
                agent.state.budget == 120000.0 and agent.state.travelers == 4)
    time.sleep(2)

    # =========================================================================
    # SECTION 2: TOOL INTEGRATION (SEARCH, ROUTING, HOTELS, FLIGHTS, ACTIVITIES)
    # =========================================================================
    print("\n--- SECTION 2: Travel Tools Integration ---")

    # 7. Find Spain (search_location)
    print("User: 'Find Spain.'")
    r7 = call_with_retry(agent, "Find Spain.")
    print(f"Assistant: {r7.text[:120]}...")
    assert_test("7. search_location('Spain')", any(w in r7.text.lower() for w in ["spain", "iberian", "madrid", "europe"]))
    time.sleep(2)

    # 8. Show Spain on map (show_location_on_map)
    print("User: 'Show Spain on the map.'")
    r8 = call_with_retry(agent, "Show Spain on the map.")
    print(f"Assistant: {r8.text[:120]}...")
    print(f"Map Action: {r8.map_action}")
    assert_test("8. show_location_on_map sets map_action with center coords",
                r8.map_action is not None and r8.map_action.get("type") == "center")
    time.sleep(2)

    # 9. Route from Delhi to Jaipur (get_route)
    print("User: 'Route from Delhi to Jaipur.'")
    r9 = call_with_retry(agent, "Route from Delhi to Jaipur.")
    print(f"Assistant: {r9.text[:120]}...")
    print(f"Map Action: {bool(r9.map_action)}")
    assert_test("9. get_route calculates driving route",
                any(w in r9.text.lower() for w in ["km", "hour", "jaipur", "delhi", "route"]))
    time.sleep(2)

    # 10. Find hotels in Goa (search_hotels)
    print("User: 'Find hotels in Goa.'")
    r10 = call_with_retry(agent, "Find hotels in Goa.")
    print(f"Assistant: {r10.text[:120]}...")
    print(f"Cards count: {len(r10.cards)}")
    assert_test("10a. search_hotels returns hotel cards", len(r10.cards) > 0)
    assert_test("10b. Zero-fabrication disclaimer included",
                "live" in r10.text.lower() or "portal" in r10.text.lower() or "connected" in r10.text.lower() or len(r10.cards) > 0)
    time.sleep(2)

    # 11. Find flights from Delhi to Dubai (search_flights)
    print("User: 'Find flights from Delhi to Dubai.'")
    r11 = call_with_retry(agent, "Find flights from Delhi to Dubai.")
    print(f"Assistant: {r11.text[:120]}...")
    print(f"Cards count: {len(r11.cards)}")
    assert_test("11a. search_flights returns flight cards", len(r11.cards) > 0)
    assert_test("11b. Flight airline or route mentioned", any(w in r11.text.lower() for w in ["flight", "airline", "dubai", "delhi"]))
    time.sleep(2)

    # 12. Find activities in London (search_activities)
    print("User: 'Find activities in London.'")
    r12 = call_with_retry(agent, "Find activities in London.")
    print(f"Assistant: {r12.text[:120]}...")
    assert_test("12. search_activities returns sights", len(r12.text) > 20)
    time.sleep(2)

    # 13. Create a trip to Goa (create_trip)
    print("User: 'Create a trip to Goa.'")
    r13 = call_with_retry(agent, "Create a trip to Goa.")
    print(f"Assistant: {r13.text[:120]}...")
    all_trips = trip_service.get_all_trips()
    has_goa_trip = any("goa" in t.get("name", "").lower() or "goa" in t.get("destination", "").lower() for t in all_trips)
    assert_test("13. create_trip saves trip in SQLite database", has_goa_trip)
    time.sleep(2)

    # 14. Add ₹5000 hotel expense (add_expense)
    print("User: 'Add ₹5000 hotel expense to my Goa trip.'")
    r14 = call_with_retry(agent, "Add ₹5000 hotel expense to my Goa trip.")
    print(f"Assistant: {r14.text[:120]}...")
    recent_expenses = expense_service.get_recent(5)
    has_5000_expense = any(e.get("amount") == 5000.0 for e in recent_expenses)
    assert_test("14. add_expense logs expense into SQLite database", has_5000_expense)
    time.sleep(2)

    # =========================================================================
    # SECTION 3: TOOL FAILURES & RESILIENCE
    # =========================================================================
    print("\n--- SECTION 3: Tool Failures & Resilience ---")

    # 15. Unknown location handling
    print("User: 'Where is asdfghqwerty123?'")
    r15 = call_with_retry(agent, "Where is asdfghqwerty123?")
    print(f"Assistant: {r15.text[:120]}...")
    assert_test("15. Graceful handling of unknown location",
                any(w in r15.text.lower() for w in ["couldn't", "unable", "not find", "sorry", "unknown", "doesn't seem", "asdfghqwerty123"]))
    time.sleep(2)

    # 16. Security allowlist rejection
    bad_tool_res = agent._execute_tool("arbitrary_exec", {"cmd": "calc.exe"})
    assert_test("16. Unauthorized tool safely rejected by allowlist",
                bad_tool_res.get("success") is False and "not available" in bad_tool_res.get("error", "").lower())

    # =========================================================================
    # SECTION 4: BOOKING SAFETY WORKFLOW
    # =========================================================================
    print("\n--- SECTION 4: Booking Safety Workflow ---")

    # 17. Search flights to Dubai — must NOT automatically book
    print("User: 'Find flights to Dubai.'")
    r17 = call_with_retry(agent, "Find flights to Dubai.")
    assert_test("17. Flight search does NOT trigger premature booking",
                agent.state.pending_action is None)
    time.sleep(2)

    # 18. User selects flight card -> enters pending confirmation state
    sample_flight = {
        "id": "fl_ek_1",
        "airline": "Emirates",
        "airline_code": "EK",
        "origin": "Delhi",
        "destination": "Dubai",
        "departure_time": "19:30",
        "cabin": "Economy",
        "price_display": "Live rate at provider",
        "booking_url": "https://google.com/travel/flights",
    }
    r18 = agent.initiate_selection("flight", sample_flight)
    print(f"Assistant confirmation prompt: {r18.text[:120]}...")
    assert_test("18a. initiate_selection requests explicit confirmation",
                "proceed" in r18.text.lower() or "confirm" in r18.text.lower() or "reservation" in r18.text.lower())
    assert_test("18b. pending_action set in ConversationState",
                agent.state.pending_action is not None and agent.state.pending_action.get("type") == "book_flight")

    # 19. User confirms explicitly -> executes booking handler
    print("User: 'Yes, confirm booking'")
    r19 = agent.process_message("Yes, confirm booking")
    print(f"Assistant response after confirmation: {r19.text[:120]}...")
    assert_test("19. Confirmed action executed and pending_action cleared",
                agent.state.pending_action is None and "Booking Status" in r19.text)

    # =========================================================================
    # SECTION 5: REGRESSION TESTS
    # =========================================================================
    print("\n--- SECTION 5: System & Regression Integrity ---")
    assert_test("20a. Trip repository has trips", len(trip_service.get_all_trips()) > 0)
    assert_test("20b. Expense repository has expenses", len(expense_service.get_recent(5)) > 0)
    loc_test = TravelToolRegistry.search_location("London")
    assert_test("20c. Geocoding service works directly", loc_test.get("found") is True)
    route_test = TravelToolRegistry.get_route("Mumbai", "Pune")
    assert_test("20d. Routing service works directly", route_test.get("success") is True)

    print("\n" + "=" * 75)
    print(f"ALL {passed}/{total} PHASE 2E TESTS PASSED SUCCESSFULLY!")
    print("=" * 75)


if __name__ == "__main__":
    run_full_phase_2e_tests()
