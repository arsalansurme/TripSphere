"""
Unit tests for TripSphere Voice Service and Voice-First Assistant UI.
"""
import os
import sys
import time
import unittest
from unittest.mock import patch, MagicMock

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from PySide6.QtWidgets import QApplication

app = QApplication.instance() or QApplication(sys.argv)

from app.services.voice_service import (
    clean_text_for_speech, VoiceState, TTSEngine, STTEngine, ContinuousVoiceWorker, voice_service
)
from app.ui.chat import ChatScreen, VoiceOrbWidget


class TestVoiceService(unittest.TestCase):

    def test_clean_text_for_speech(self):
        """Test markdown, currency symbols, and emojis are cleaned for speech."""
        raw = "Hey **Arsalan**! 🏖️ Here are flights to *Goa* for ₹15,000:\n- IndiGo\n- Air India\nCheck [link](http://x.com)!"
        cleaned = clean_text_for_speech(raw)
        self.assertNotIn("**", cleaned)
        self.assertNotIn("🏖️", cleaned)
        self.assertNotIn("[link]", cleaned)
        self.assertIn("15,000 rupees", cleaned)
        self.assertIn("IndiGo", cleaned)

    def test_voice_states_enum(self):
        """Verify all 4 required voice states exist."""
        self.assertEqual(VoiceState.IDLE.value, "IDLE")
        self.assertEqual(VoiceState.LISTENING.value, "LISTENING")
        self.assertEqual(VoiceState.THINKING.value, "THINKING")
        self.assertEqual(VoiceState.SPEAKING.value, "SPEAKING")

    def test_tts_engine_interrupt(self):
        """Verify TTS engine stops speaking immediately on stop()."""
        tts = TTSEngine()
        tts.stop()
        self.assertFalse(tts.is_speaking)

    def test_voice_worker_state_transitions(self):
        """Verify ContinuousVoiceWorker state changes and interruption."""
        mock_tts = MagicMock()
        mock_stt = MagicMock()
        mock_stt.listen_and_recognize.return_value = None
        worker = ContinuousVoiceWorker(mock_tts, mock_stt)

        states = []
        worker.state_changed.connect(lambda s: states.append(s))

        # Start conversation
        worker.start_conversation("Hello traveler!")
        self.assertIn(VoiceState.SPEAKING.value, states)

        # Interrupt conversation
        worker.interrupt()
        mock_tts.stop.assert_called()
        time.sleep(0.06)
        self.assertIn(VoiceState.LISTENING.value, states)

        # Stop
        worker.stop()
        self.assertEqual(worker.current_state, VoiceState.IDLE)

    def test_voice_orb_widget_states(self):
        """Verify VoiceOrbWidget updates its state cleanly."""
        orb = VoiceOrbWidget()
        for state in [VoiceState.IDLE, VoiceState.LISTENING, VoiceState.THINKING, VoiceState.SPEAKING]:
            orb.set_state(state)
            self.assertEqual(orb._state, state)

    def test_chat_screen_voice_integration(self):
        """Verify ChatScreen initializes in IDLE voice state and cleans up cleanly."""
        screen = ChatScreen()
        self.assertEqual(screen._orb._state, VoiceState.IDLE)
        self.assertIn("Tap to talk", screen._state_title.text())
        screen.cleanup()


if __name__ == "__main__":
    unittest.main()
