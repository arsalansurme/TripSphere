"""
TripSphere — Centralized Configuration & Theme System
All colours, fonts, paths, and constants live here.
"""
import os
import logging
from pathlib import Path

from dotenv import load_dotenv

# ── Paths ────────────────────────────────────────────────────────────────────
BASE_DIR   = Path(__file__).parent.parent
DATA_DIR   = BASE_DIR / "data"
LOGS_DIR   = BASE_DIR / "logs"
ASSETS_DIR = BASE_DIR / "app" / "assets"
MAP_DIR    = BASE_DIR / "app" / "map"

for d in (DATA_DIR, LOGS_DIR, ASSETS_DIR):
    d.mkdir(parents=True, exist_ok=True)

# ── Environment ──────────────────────────────────────────────────────────────
load_dotenv(BASE_DIR / ".env")

NOMINATIM_USER_AGENT = os.getenv("NOMINATIM_USER_AGENT", "TripSphere/1.0")
ORS_API_KEY          = os.getenv("ORS_API_KEY", "")

# ── App metadata ─────────────────────────────────────────────────────────────
APP_NAME     = "TripSphere"
APP_VERSION  = "1.0.0"
APP_TAGLINE  = "Explore. Plan. Remember."

# ── Database ─────────────────────────────────────────────────────────────────
DB_PATH = DATA_DIR / "tripsphere.db"

# ── Defaults ─────────────────────────────────────────────────────────────────
DEFAULT_CURRENCY      = "₹"
DEFAULT_CURRENCY_CODE = "INR"
DEFAULT_TRAVEL_MODE   = "driving"
DEFAULT_HOME_CITY     = "Mumbai"
DEFAULT_HOME_LAT      = 19.0760
DEFAULT_HOME_LON      = 72.8777

# ── API endpoints ─────────────────────────────────────────────────────────────
NOMINATIM_BASE   = "https://nominatim.openstreetmap.org"
OSRM_BASE        = "https://router.project-osrm.org/route/v1"
OVERPASS_BASE    = "https://overpass-api.de/api/interpreter"
ORS_BASE         = "https://api.openrouteservice.org/v2"

REQUEST_TIMEOUT     = 10   # seconds
CACHE_SECONDS       = 3600 # 1 hour
SEARCH_DEBOUNCE_MS  = 400  # ms debounce for geocoding search
SEARCH_RESULT_LIMIT = 8    # max results per geocoding search

# ── Color Palette — Warm Dark Cinema ──────────────────────────────────────────
COLORS: dict[str, str] = {
    # Backgrounds — layered warm dark
    "bg_deep":       "#0A0A0A",   # near-black base canvas
    "bg_dark":       "#111111",   # primary surface
    "bg_card":       "#171717",   # card background
    "bg_card2":      "#1C1C1C",   # secondary card background
    "bg_elevated":   "#222222",   # hover / raised state

    # Warm travel-inspired accents
    "accent":        "#D4A96A",   # warm gold — primary accent
    "accent_dim":    "#A07840",   # muted gold
    "accent_light":  "#E8C48A",   # light warm gold
    "accent_alt":    "#E8C48A",   # alias for backwards compatibility
    "coral":         "#C96B4A",   # terracotta / burnt orange
    "sand":          "#E8D5B0",   # champagne / cream
    "olive":         "#8A9B6A",   # muted sage olive
    "cream":         "#F5EDD8",   # soft warm cream
    "accent_glow":   "rgba(255,255,255,0.06)",  # warm gold glow
    "accent_bg":     "rgba(255,255,255,0.06)",

    # Text hierarchy
    "text":          "#F5F5F5",   # primary white
    "text_muted":    "#A1A1AA",   # secondary zinc-400
    "text_subtle":   "#71717A",   # tertiary zinc-500
    "text_dim":      "#52525B",   # hint zinc-600

    # Status
    "success":       "#4ADE80",
    "success_bg":    "rgba(74,222,128,0.10)",
    "danger":        "#F87171",
    "danger_bg":     "rgba(248,113,113,0.10)",
    "warning":       "#FBBF24",
    "warning_bg":    "rgba(251,191,36,0.10)",

    # Surfaces & glass — ZERO bright outline borders
    "glass":         "rgba(17, 17, 17, 0.85)",
    "glass_dark":    "rgba(10, 10, 10, 0.90)",
    "glass_light":   "rgba(255,255,255,0.04)",
    "border":        "transparent",
    "border_hover":  "rgba(255,255,255,0.10)",
    "border_bright": "rgba(255,255,255,0.15)",
    "border_accent": "transparent",

    # Sidebar
    "sidebar_bg":     "#0A0A0A",
    "sidebar_hover":  "rgba(255,255,255,0.05)",
    "sidebar_active": "rgba(255,255,255,0.08)",

    # Expense category colors
    "cat_transport":      "#7B9EA3",
    "cat_accommodation":  "#C46E7B",
    "cat_food":           "#E8834A",
    "cat_activities":     "#6CA877",
    "cat_shopping":       "#A882C4",
    "cat_fuel":           "#D4B84A",
    "cat_local":          "#5C9EBF",
    "cat_other":          "#71717A",
}

# ── Font sizes (px as strings for QSS) ───────────────────────────────────────
FONT = {
    "family":  '"Inter", "Segoe UI Variable Display", "Segoe UI", "SF Pro Display", sans-serif',
    "xs":      "10px",
    "sm":      "12px",
    "base":    "14px",
    "md":      "16px",
    "lg":      "20px",
    "xl":      "24px",
    "2xl":     "32px",
    "3xl":     "44px",
    "hero":    "60px",
}

# ── Expense categories ────────────────────────────────────────────────────────
EXPENSE_CATEGORIES = [
    "Transport",
    "Accommodation",
    "Food",
    "Activities",
    "Shopping",
    "Fuel",
    "Local Transport",
    "Other",
]

EXPENSE_CATEGORY_ICONS = {
    "Transport":       "✈",
    "Accommodation":   "🏨",
    "Food":            "🍽",
    "Activities":      "🎯",
    "Shopping":        "🛍",
    "Fuel":            "⛽",
    "Local Transport": "🚕",
    "Other":           "•",
}

# ── Mood options for journal ──────────────────────────────────────────────────
MOODS = ["Amazing", "Happy", "Excited", "Peaceful", "Tired",
         "Adventurous", "Romantic", "Nostalgic", "Okay", "Stressed"]

# ── Logging ──────────────────────────────────────────────────────────────────
def setup_logging() -> logging.Logger:
    """Configure application-wide logging."""
    log_file = LOGS_DIR / "app.log"
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=[
            logging.FileHandler(log_file, encoding="utf-8"),
            logging.StreamHandler(),
        ],
    )
    return logging.getLogger(APP_NAME)

logger = setup_logging()

# ── Master QSS stylesheet ─────────────────────────────────────────────────────
def get_app_stylesheet() -> str:
    """Return the master Qt stylesheet for TripSphere — outline-free dark theme."""
    c = COLORS
    f = FONT
    return f"""
    /* ── Global Reset — No outlines by default ────────────────────── */
    QWidget {{
        background-color: {c['bg_deep']};
        color: {c['text']};
        font-family: "Inter", "Segoe UI Variable Display", "Segoe UI", "SF Pro Display", sans-serif;
        font-size: 14px;
        border: none;
        outline: none;
    }}
    QMainWindow {{
        background-color: {c['bg_deep']};
    }}

    QFrame {{
        border: none;
    }}

    /* ── Scrollbars — thin macOS style ────────────────────────── */
    QScrollBar:vertical {{
        background: transparent;
        width: 4px;
        margin: 0;
    }}
    QScrollBar::handle:vertical {{
        background: rgba(255, 255, 255, 0.12);
        border-radius: 2px;
        min-height: 32px;
    }}
    QScrollBar::handle:vertical:hover {{
        background: rgba(255, 255, 255, 0.25);
    }}
    QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical,
    QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {{
        height: 0; background: transparent;
    }}
    QScrollBar:horizontal {{
        background: transparent;
        height: 4px;
        margin: 0;
    }}
    QScrollBar::handle:horizontal {{
        background: rgba(255, 255, 255, 0.12);
        border-radius: 2px;
        min-width: 32px;
    }}
    QScrollBar::handle:horizontal:hover {{
        background: rgba(255, 255, 255, 0.25);
    }}
    QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal,
    QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal {{
        width: 0; background: transparent;
    }}

    /* ── Input Fields — sleek contrast surfaces ────────────────── */
    QLineEdit {{
        background: rgba(255, 255, 255, 0.05);
        color: {c['text']};
        border: none;
        border-radius: 12px;
        padding: 11px 16px;
        font-size: 14px;
        selection-background-color: rgba(212, 169, 106, 0.25);
    }}
    QLineEdit:focus {{
        background: rgba(255, 255, 255, 0.08);
    }}
    QLineEdit::placeholder {{
        color: {c['text_dim']};
    }}

    QTextEdit, QPlainTextEdit {{
        background: rgba(255, 255, 255, 0.05);
        color: {c['text']};
        border: none;
        border-radius: 14px;
        padding: 12px 16px;
        font-size: 14px;
        selection-background-color: rgba(212, 169, 106, 0.25);
    }}
    QTextEdit:focus, QPlainTextEdit:focus {{
        background: rgba(255, 255, 255, 0.08);
    }}

    /* ── Combo / Spin ───────────────────────────────────────────── */
    QComboBox {{
        background: rgba(255, 255, 255, 0.05);
        color: {c['text']};
        border: none;
        border-radius: 12px;
        padding: 10px 16px;
        font-size: 14px;
    }}
    QComboBox:hover {{
        background: rgba(255, 255, 255, 0.08);
    }}
    QComboBox::drop-down {{
        border: none;
        width: 32px;
    }}
    QComboBox::down-arrow {{
        image: none;
        border-left: 4px solid transparent;
        border-right: 4px solid transparent;
        border-top: 5px solid {c['text_muted']};
        width: 0;
        height: 0;
    }}
    QComboBox QAbstractItemView {{
        background: {c['bg_card']};
        color: {c['text']};
        border: none;
        border-radius: 12px;
        selection-background-color: rgba(255, 255, 255, 0.08);
        selection-color: {c['text']};
        outline: none;
        padding: 6px;
    }}

    QSpinBox, QDoubleSpinBox {{
        background: rgba(255, 255, 255, 0.05);
        color: {c['text']};
        border: none;
        border-radius: 12px;
        padding: 10px 16px;
        font-size: 14px;
    }}
    QSpinBox::up-button, QSpinBox::down-button,
    QDoubleSpinBox::up-button, QDoubleSpinBox::down-button {{
        background: transparent;
        border: none;
        width: 22px;
    }}

    /* ── Date Edit ──────────────────────────────────────────────── */
    QDateEdit {{
        background: rgba(255, 255, 255, 0.05);
        color: {c['text']};
        border: none;
        border-radius: 12px;
        padding: 10px 16px;
        font-size: 14px;
    }}
    QDateEdit::drop-down {{ border: none; width: 32px; }}
    QCalendarWidget {{
        background: {c['bg_dark']};
        color: {c['text']};
        border: none;
        border-radius: 14px;
    }}
    QCalendarWidget QToolButton {{
        color: {c['text']};
        background: transparent;
        border: none;
        font-size: 13px;
        font-weight: 600;
    }}
    QCalendarWidget QMenu {{
        background: {c['bg_card']};
        color: {c['text']};
    }}
    QCalendarWidget QAbstractItemView {{
        background: {c['bg_dark']};
        color: {c['text']};
        selection-background-color: rgba(255,255,255,0.08);
        selection-color: {c['text']};
    }}

    /* ── Push Buttons — clean background contrast ───────────────── */
    QPushButton {{
        background: rgba(255, 255, 255, 0.07);
        color: {c['text']};
        border: none;
        border-radius: 12px;
        padding: 10px 24px;
        font-size: 14px;
        font-weight: 600;
        letter-spacing: 0.1px;
    }}
    QPushButton:hover {{
        background: rgba(255, 255, 255, 0.13);
    }}
    QPushButton:pressed {{
        background: rgba(255, 255, 255, 0.04);
    }}
    QPushButton:disabled {{
        background: rgba(255, 255, 255, 0.02);
        color: {c['text_dim']};
    }}

    /* ── Accent / Primary action buttons ────────────────────────── */
    QPushButton[class="primary"] {{
        background: {c['accent']};
        color: #111111;
        border: none;
        font-weight: 700;
    }}
    QPushButton[class="primary"]:hover {{
        background: {c['accent_light']};
    }}

    /* ── Ghost buttons ──────────────────────────────────────────── */
    QPushButton[flat="true"] {{
        background: transparent;
        color: {c['text_muted']};
        border: none;
    }}
    QPushButton[flat="true"]:hover {{
        background: rgba(255, 255, 255, 0.06);
        color: {c['text']};
    }}

    /* ── Tool Buttons ───────────────────────────────────────────── */
    QToolButton {{
        background: transparent;
        color: {c['text_muted']};
        border: none;
        border-radius: 10px;
        padding: 6px 10px;
        font-size: 14px;
    }}
    QToolButton:hover {{
        background: rgba(255, 255, 255, 0.07);
        color: {c['text']};
    }}

    /* ── Labels ─────────────────────────────────────────────────── */
    QLabel {{
        background: transparent;
        color: {c['text']};
        border: none;
    }}

    /* ── Group Box ──────────────────────────────────────────────── */
    QGroupBox {{
        border: none;
        border-radius: 16px;
        margin-top: 16px;
        padding: 16px 14px 12px 14px;
        font-size: 11px;
        font-weight: 700;
        color: {c['text_subtle']};
        letter-spacing: 1px;
        text-transform: uppercase;
        background: {c['bg_card']};
    }}
    QGroupBox::title {{
        subcontrol-origin: margin;
        left: 16px;
        padding: 0 6px;
        background: transparent;
    }}

    /* ── Tab Widget ─────────────────────────────────────────────── */
    QTabWidget::pane {{
        border: none;
        border-radius: 14px;
        background: rgba(255,255,255,0.02);
    }}
    QTabBar::tab {{
        background: transparent;
        color: {c['text_muted']};
        border: none;
        padding: 10px 22px;
        border-radius: 10px;
        margin-right: 3px;
        font-size: 13px;
        font-weight: 500;
    }}
    QTabBar::tab:selected {{
        background: rgba(255,255,255,0.08);
        color: {c['text']};
        font-weight: 700;
    }}
    QTabBar::tab:hover:!selected {{
        background: rgba(255,255,255,0.05);
        color: {c['text']};
    }}

    /* ── List / Tree / Table ────────────────────────────────────── */
    QListWidget, QTreeWidget, QTableWidget {{
        background: rgba(255, 255, 255, 0.02);
        color: {c['text']};
        border: none;
        border-radius: 14px;
        outline: none;
        font-size: 14px;
    }}
    QListWidget::item, QTreeWidget::item, QTableWidget::item {{
        padding: 10px 14px;
        border-radius: 8px;
        border: none;
    }}
    QListWidget::item:selected, QTreeWidget::item:selected, QTableWidget::item:selected {{
        background: rgba(255, 255, 255, 0.08);
        color: {c['text']};
    }}
    QListWidget::item:hover, QTreeWidget::item:hover, QTableWidget::item:hover {{
        background: rgba(255,255,255,0.04);
    }}
    QHeaderView::section {{
        background: rgba(0,0,0,0.40);
        color: {c['text_subtle']};
        border: none;
        padding: 10px 16px;
        font-weight: 700;
        font-size: 10px;
        text-transform: uppercase;
        letter-spacing: 1px;
    }}

    /* ── Dialog ─────────────────────────────────────────────────── */
    QDialog {{
        background: {c['bg_dark']};
        border: none;
        border-radius: 20px;
    }}

    /* ── Splitter ───────────────────────────────────────────────── */
    QSplitter::handle {{
        background: transparent;
    }}

    /* ── Tooltip ────────────────────────────────────────────────── */
    QToolTip {{
        background: {c['bg_card']};
        color: {c['text']};
        border: none;
        border-radius: 10px;
        padding: 6px 12px;
        font-size: 12px;
    }}

    /* ── Check Box ──────────────────────────────────────────────── */
    QCheckBox {{
        color: {c['text']};
        spacing: 10px;
        font-size: 14px;
        border: none;
    }}
    QCheckBox::indicator {{
        width: 18px;
        height: 18px;
        border-radius: 6px;
        border: none;
        background: rgba(255,255,255,0.08);
    }}
    QCheckBox::indicator:checked {{
        background: {c['accent']};
    }}

    /* ── Radio Button ───────────────────────────────────────────── */
    QRadioButton {{
        color: {c['text']};
        spacing: 10px;
        font-size: 14px;
        border: none;
    }}
    QRadioButton::indicator {{
        width: 18px;
        height: 18px;
        border-radius: 9px;
        border: none;
        background: rgba(255,255,255,0.08);
    }}
    QRadioButton::indicator:checked {{
        background: {c['accent']};
    }}

    /* ── Progress Bar ───────────────────────────────────────────── */
    QProgressBar {{
        background: rgba(255, 255, 255, 0.05);
        border-radius: 6px;
        height: 8px;
        text-align: center;
        color: transparent;
        border: none;
    }}
    QProgressBar::chunk {{
        background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
            stop:0 {c['accent_dim']}, stop:1 {c['accent_light']});
        border-radius: 6px;
    }}

    /* ── Status Bar ─────────────────────────────────────────────── */
    QStatusBar {{
        background: {c['sidebar_bg']};
        color: {c['text_subtle']};
        border-top: 1px solid rgba(255,255,255,0.04);
        font-size: 11px;
        padding: 2px 14px;
    }}
    QStatusBar::item {{ border: none; }}

    /* ── Message Box ────────────────────────────────────────────── */
    QMessageBox {{
        background: {c['bg_dark']};
        color: {c['text']};
    }}
    """
