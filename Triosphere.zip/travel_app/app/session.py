"""
Tracks which profile (user) is currently active in this app session.

TripSphere supports multiple local profiles (no passwords — just a
name picker) so a shared installation can be used by a few people
while keeping each person's trips, expenses, journal, and favorites
separate. The active profile persists across restarts via the
`app_state` table.
"""
from __future__ import annotations

import logging
from app.database.db import db

logger = logging.getLogger(__name__)

_STATE_KEY = "active_user_id"
_current_user_id: int | None = None


def get_current_user_id() -> int:
    """Return the id of the active profile, resolving and caching it on
    first call. Falls back to the first profile (creating a default one
    if the database is completely empty)."""
    global _current_user_id
    if _current_user_id is not None:
        return _current_user_id

    row = db.fetchone("SELECT value FROM app_state WHERE key = ?", (_STATE_KEY,))
    if row and row["value"]:
        try:
            uid = int(row["value"])
            if db.fetchone("SELECT id FROM users WHERE id = ?", (uid,)):
                _current_user_id = uid
                return _current_user_id
        except (TypeError, ValueError):
            pass

    # No valid saved profile — fall back to the first one that exists.
    row = db.fetchone("SELECT id FROM users ORDER BY id LIMIT 1")
    if row:
        _current_user_id = row["id"]
    else:
        db.execute("INSERT INTO users (id, name) VALUES (1, 'Traveller')")
        _current_user_id = 1

    _persist(_current_user_id)
    return _current_user_id


def set_current_user_id(user_id: int) -> None:
    """Switch the active profile and remember the choice for next launch."""
    global _current_user_id
    _current_user_id = user_id
    _persist(user_id)
    logger.info("Active profile switched to user_id=%s", user_id)


def _persist(user_id: int) -> None:
    db.execute(
        """INSERT INTO app_state (key, value) VALUES (?, ?)
           ON CONFLICT(key) DO UPDATE SET value = excluded.value""",
        (_STATE_KEY, str(user_id)),
    )
