"""
Routing service — supports 14 travel modes via OSRM (free, no API key).

Supported by OSRM (returns real route geometry + steps):
    driving, walking, cycling, motorcycle, taxi, rental_car, escooter

Not supported (returns structured "unavailable" response):
    multimodal, bus, train, metro, tram, flight, ferry

Architecture note:
    Unsupported modes return {"supported": False} — the caller must NEVER
    fake route results. Show a clear "unavailable" message instead.
"""
from __future__ import annotations

import logging
import math
from typing import Optional

import requests

from app.config import OSRM_BASE, REQUEST_TIMEOUT

logger = logging.getLogger(__name__)


# ── Travel mode definitions ────────────────────────────────────────────────────

# (display_name, icon, osrm_profile or None, avg_speed_kmh)
TRAVEL_MODES: dict[str, tuple[str, str, Optional[str], float]] = {
    "multimodal":  ("Best / Multimodal", "🔀", None,       None),
    "driving":     ("Driving",           "🚗", "driving",   60.0),
    "walking":     ("Walking",           "🚶", "foot",       5.0),
    "cycling":     ("Cycling",           "🚴", "bike",      15.0),
    "motorcycle":  ("Motorcycle",        "🏍", "driving",   60.0),
    "bus":         ("Bus / Coach",       "🚌", None,       None),
    "taxi":        ("Taxi / Cab",        "🚕", "driving",   50.0),
    "rental_car":  ("Rental Car",        "🚙", "driving",   60.0),
    "train":       ("Train",             "🚆", None,       None),
    "metro":       ("Metro / Subway",    "🚇", None,       None),
    "tram":        ("Tram / Light Rail", "🚊", None,       None),
    "flight":      ("Flight",            "✈️", None,       None),
    "ferry":       ("Ferry / Boat",      "⛴️", None,       None),
    "escooter":    ("E-Scooter",         "🛴", "bike",      18.0),
}

# Modes that will never have routing support here — show graceful message
_UNSUPPORTED_MESSAGES: dict[str, str] = {
    "multimodal": "Multimodal routing (Walk → Bus → Metro) is coming soon.",
    "bus":        "Bus / Coach routing is not yet supported. Try Driving for an estimated route.",
    "train":      "Train routing is not yet supported. Use a rail booking service for schedules.",
    "metro":      "Metro / Subway routing is not yet supported.",
    "tram":       "Tram / Light Rail routing is not yet supported.",
    "flight":     "Flight routing is not yet supported. Use a flight search service instead.",
    "ferry":      "Ferry routing is not yet supported. Check local ferry schedules.",
}


def get_mode_info(mode_key: str) -> dict:
    """Return display info for a mode key."""
    data = TRAVEL_MODES.get(mode_key, TRAVEL_MODES["driving"])
    return {
        "key":     mode_key,
        "name":    data[0],
        "icon":    data[1],
        "profile": data[2],
        "speed":   data[3],
    }


class RoutingService:
    """
    Calculate routes using OSRM demo server.

    Return shape (always a dict, never raises):
    {
        "supported":    bool,
        "mode":         str,
        "mode_name":    str,
        "mode_icon":    str,
        "distance_km":  float,
        "duration_min": float,
        "duration_str": str,
        "geometry":     [[lat, lon], ...],
        "steps":        [{"instruction": str, "distance_m": float, "duration_s": float}, ...],
        "fallback":     bool,          # True = haversine estimate, not real route
        "error":        str | None,    # Non-None when a real error occurred
        "error_type":   str | None,    # "timeout" | "network" | "api_error" | "unsupported"
        "unsupported_message": str | None,
    }
    """

    def get_route(
        self,
        origin_lat: float,
        origin_lon: float,
        dest_lat: float,
        dest_lon: float,
        mode: str = "driving",
    ) -> dict:
        """Calculate route between two points. Never raises."""
        mode_info = get_mode_info(mode)
        base = {
            "mode":       mode,
            "mode_name":  mode_info["name"],
            "mode_icon":  mode_info["icon"],
            "error":      None,
            "error_type": None,
            "unsupported_message": None,
        }

        # ── Unsupported modes ──────────────────────────────────────────────────
        if mode_info["profile"] is None:
            return {
                **base,
                "supported":    False,
                "distance_km":  0.0,
                "duration_min": 0.0,
                "duration_str": "—",
                "geometry":     [],
                "steps":        [],
                "fallback":     False,
                "unsupported_message": _UNSUPPORTED_MESSAGES.get(
                    mode, "This travel mode is currently unavailable for this route."
                ),
            }

        # ── Validate coordinates ───────────────────────────────────────────────
        if not self._valid_coords(origin_lat, origin_lon, dest_lat, dest_lon):
            return {
                **base,
                "supported":    True,
                "distance_km":  0.0,
                "duration_min": 0.0,
                "duration_str": "—",
                "geometry":     [],
                "steps":        [],
                "fallback":     False,
                "error":        "Invalid coordinates provided.",
                "error_type":   "validation",
            }

        # ── Try OSRM ──────────────────────────────────────────────────────────
        osrm_result = self._osrm_route(
            origin_lat, origin_lon, dest_lat, dest_lon, mode_info["profile"]
        )
        if osrm_result:
            return {**base, "supported": True, "fallback": False, **osrm_result}

        # ── Haversine fallback ─────────────────────────────────────────────────
        speed = mode_info["speed"] or 60.0
        dist_km = self.haversine(origin_lat, origin_lon, dest_lat, dest_lon)
        dur_min = (dist_km / speed) * 60
        logger.info("Routing: using haversine fallback for mode=%s", mode)
        return {
            **base,
            "supported":    True,
            "distance_km":  round(dist_km, 2),
            "duration_min": round(dur_min, 1),
            "duration_str": self._format_duration(dur_min),
            "geometry":     [[origin_lat, origin_lon], [dest_lat, dest_lon]],
            "steps":        [],
            "fallback":     True,
        }

    def get_multi_route(
        self,
        waypoints: list[tuple[float, float]],
        mode: str = "driving",
    ) -> dict:
        """
        Calculate route through multiple waypoints.
        waypoints: [(lat, lon), ...]
        """
        if len(waypoints) < 2:
            info = get_mode_info(mode)
            return {
                "supported": True, "mode": mode,
                "mode_name": info["name"], "mode_icon": info["icon"],
                "distance_km": 0, "duration_min": 0, "duration_str": "0 min",
                "geometry": [], "steps": [], "fallback": False,
                "error": None, "error_type": None, "unsupported_message": None,
            }

        total_dist = 0.0
        total_dur  = 0.0
        geometry   = []
        all_steps  = []
        fallback   = False
        first      = True
        base_meta  = {}

        for i in range(len(waypoints) - 1):
            seg = self.get_route(
                waypoints[i][0], waypoints[i][1],
                waypoints[i+1][0], waypoints[i+1][1],
                mode,
            )
            if first:
                base_meta = {k: seg[k] for k in ("mode", "mode_name", "mode_icon",
                                                   "supported", "unsupported_message",
                                                   "error", "error_type")}
                first = False
            if not seg.get("supported"):
                return seg  # Propagate unsupported immediately
            total_dist += seg["distance_km"]
            total_dur  += seg["duration_min"]
            geometry   += seg["geometry"]
            all_steps  += seg.get("steps", [])
            if seg.get("fallback"):
                fallback = True

        return {
            **base_meta,
            "distance_km":  round(total_dist, 2),
            "duration_min": round(total_dur, 1),
            "duration_str": self._format_duration(total_dur),
            "geometry":     geometry,
            "steps":        all_steps,
            "fallback":     fallback,
        }

    # ── Internal ──────────────────────────────────────────────────────────────

    def _osrm_route(
        self,
        o_lat: float, o_lon: float,
        d_lat: float, d_lon: float,
        profile: str,
    ) -> Optional[dict]:
        coords = f"{o_lon},{o_lat};{d_lon},{d_lat}"
        url    = f"{OSRM_BASE}/{profile}/{coords}"
        params = {
            "overview":   "full",
            "geometries": "geojson",
            "steps":      "true",
            "annotations":"false",
        }
        try:
            resp = requests.get(url, params=params, timeout=REQUEST_TIMEOUT)
            resp.raise_for_status()
            data = resp.json()
            if data.get("code") != "Ok" or not data.get("routes"):
                logger.warning("OSRM returned non-Ok: %s", data.get("code"))
                return None

            route    = data["routes"][0]
            dist_km  = route["distance"] / 1000
            dur_min  = route["duration"] / 60
            # GeoJSON coords are [lon, lat] → Leaflet wants [lat, lon]
            geo_pts  = route["geometry"]["coordinates"]
            geometry = [[pt[1], pt[0]] for pt in geo_pts]

            # Extract steps from first leg
            steps = []
            for leg in route.get("legs", []):
                for step in leg.get("steps", []):
                    maneuver = step.get("maneuver", {})
                    steps.append({
                        "instruction": step.get("name") or maneuver.get("type", ""),
                        "distance_m":  step.get("distance", 0),
                        "duration_s":  step.get("duration", 0),
                        "maneuver":    maneuver.get("type", ""),
                        "modifier":    maneuver.get("modifier", ""),
                    })

            return {
                "distance_km":  round(dist_km, 2),
                "duration_min": round(dur_min, 1),
                "duration_str": self._format_duration(dur_min),
                "geometry":     geometry,
                "steps":        steps,
                "error":        None,
                "error_type":   None,
            }
        except requests.exceptions.ConnectionError:
            logger.warning("Routing: no internet connection.")
        except requests.exceptions.Timeout:
            logger.warning("Routing: OSRM timed out (>%ss).", REQUEST_TIMEOUT)
        except Exception as exc:
            logger.error("Routing OSRM error: %s", exc)
        return None

    @staticmethod
    def _valid_coords(o_lat, o_lon, d_lat, d_lon) -> bool:
        for v in (o_lat, o_lon, d_lat, d_lon):
            if v is None or not isinstance(v, (int, float)):
                return False
        if o_lat == 0 and o_lon == 0:
            return False
        if d_lat == 0 and d_lon == 0:
            return False
        return True

    @staticmethod
    def haversine(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        """Calculate great-circle distance in km."""
        R = 6371.0
        phi1, phi2 = math.radians(lat1), math.radians(lat2)
        dphi = math.radians(lat2 - lat1)
        dlam = math.radians(lon2 - lon1)
        a = math.sin(dphi/2)**2 + math.cos(phi1)*math.cos(phi2)*math.sin(dlam/2)**2
        return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))

    @staticmethod
    def _format_duration(minutes: float) -> str:
        """Human-readable duration string."""
        minutes = round(minutes)
        if minutes < 60:
            return f"{minutes} min"
        hours, mins = divmod(minutes, 60)
        return f"{hours} hr {mins} min" if mins else f"{hours} hr"


# Module-level singleton
routing_service = RoutingService()
