"""
Geocoding service using OpenStreetMap Nominatim API.
Includes in-memory + SQLite caching to respect rate limits.

Returns consistent LocationResult dicts with keys:
    name, display_name, latitude, longitude,
    city, region, country, place_type
"""
from __future__ import annotations

import logging
import time
from typing import Any, Optional

import requests

from app.config import NOMINATIM_BASE, NOMINATIM_USER_AGENT, REQUEST_TIMEOUT
from app.database.repositories import cache_repo

logger = logging.getLogger(__name__)

_LAST_REQUEST: float = 0.0
_MIN_INTERVAL: float = 1.1  # Nominatim rate limit: 1 req/sec


def _throttle() -> None:
    """Ensure we don't exceed Nominatim's 1 req/sec limit."""
    global _LAST_REQUEST
    elapsed = time.time() - _LAST_REQUEST
    if elapsed < _MIN_INTERVAL:
        time.sleep(_MIN_INTERVAL - elapsed)
    _LAST_REQUEST = time.time()


_HEADERS = {
    "User-Agent": NOMINATIM_USER_AGENT,
    "Accept-Language": "en",
}

# ── Place type categorization ─────────────────────────────────────────────────

_PLACE_TYPE_MAP: dict[str, str] = {
    # Cities / Admin
    "city":              "city",
    "town":              "town",
    "village":           "village",
    "hamlet":            "village",
    "suburb":            "suburb",
    "neighbourhood":     "neighborhood",
    "borough":           "borough",
    "county":            "region",
    "state":             "state",
    "state_district":    "state",
    "region":            "region",
    "country":           "country",
    "continent":         "continent",
    # Transport
    "aerodrome":         "airport",
    "airport":           "airport",
    "bus_stop":          "bus_stop",
    "railway":           "train_station",
    "station":           "train_station",
    "halt":              "train_station",
    "ferry_terminal":    "ferry_terminal",
    # Tourism / Amenity
    "hotel":             "hotel",
    "museum":            "museum",
    "artwork":           "landmark",
    "attraction":        "attraction",
    "viewpoint":         "viewpoint",
    "monument":          "landmark",
    "memorial":          "landmark",
    "castle":            "landmark",
    "ruins":             "landmark",
    "historic":          "landmark",
    "tourism":           "attraction",
    "park":              "park",
    "nature_reserve":    "nature",
    "beach":             "beach",
    # Addresses
    "house":             "address",
    "building":          "address",
    "road":              "street",
    "path":              "street",
    "street":            "street",
    "residential":       "street",
}


def _categorize_place(category: str, osm_type: str, address: dict) -> str:
    """Determine a human-readable place type."""
    # Check the specific type first
    for key in (osm_type, category):
        if key in _PLACE_TYPE_MAP:
            return _PLACE_TYPE_MAP[key]
    # Fall back to what's in the address
    if address.get("aerodrome") or address.get("airport"):
        return "airport"
    if address.get("city"):
        return "city"
    if address.get("town"):
        return "town"
    if address.get("village"):
        return "village"
    if address.get("country") and not address.get("city"):
        return "country"
    return "place"


class GeocodingService:
    """Search and geocode locations using the Nominatim API."""

    # ── Public API ────────────────────────────────────────────────────────────

    def search(self, query: str, limit: int = 8) -> list[dict]:
        """
        Search for a place by name. Returns a list of normalized location dicts.

        Each dict has consistent keys:
            name, display_name, latitude, longitude,
            city, region, country, place_type,
            lat (alias), lon (alias)
        """
        if not query or not query.strip():
            return []

        cache_key = f"search_v2:{query.lower().strip()}:{limit}"
        cached = cache_repo.get(cache_key)
        if cached is not None:
            return cached

        results = self._nominatim_search(query, limit)
        if results is not None:
            cache_repo.set(cache_key, results)
            return results
        return []

    def geocode(self, place_name: str) -> Optional[dict]:
        """
        Geocode a place name → normalized location dict.
        Returns None if not found or API unavailable.
        """
        results = self.search(place_name, limit=1)
        return results[0] if results else None

    def reverse_geocode(self, lat: float, lon: float) -> Optional[dict]:
        """Reverse geocode coordinates → normalized location dict."""
        cache_key = f"reverse_v2:{lat:.4f}:{lon:.4f}"
        cached = cache_repo.get(cache_key)
        if cached is not None:
            return cached

        result = self._nominatim_reverse(lat, lon)
        if result:
            cache_repo.set(cache_key, result)
        return result

    def suggest(self, partial: str, limit: int = 5) -> list[str]:
        """Return display-name suggestions for a partial query."""
        results = self.search(partial, limit=limit)
        return [r.get("display_name", r.get("name", "")) for r in results]

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _nominatim_search(self, query: str, limit: int) -> Optional[list[dict]]:
        url = f"{NOMINATIM_BASE}/search"
        params = {
            "q":             query,
            "format":        "json",
            "limit":         limit,
            "addressdetails": 1,
            "extratags":     1,
        }
        try:
            _throttle()
            resp = requests.get(
                url, params=params, headers=_HEADERS, timeout=REQUEST_TIMEOUT
            )
            resp.raise_for_status()
            raw = resp.json()
            return [self._normalize(r) for r in raw]
        except requests.exceptions.ConnectionError:
            logger.warning("Geocoding: no internet connection.")
            return None
        except requests.exceptions.Timeout:
            logger.warning("Geocoding: request timed out.")
            return None
        except Exception as exc:
            logger.error("Geocoding error: %s", exc)
            return None

    def _nominatim_reverse(self, lat: float, lon: float) -> Optional[dict]:
        url = f"{NOMINATIM_BASE}/reverse"
        params = {"lat": lat, "lon": lon, "format": "json", "addressdetails": 1}
        try:
            _throttle()
            resp = requests.get(
                url, params=params, headers=_HEADERS, timeout=REQUEST_TIMEOUT
            )
            resp.raise_for_status()
            raw = resp.json()
            if "error" in raw:
                return None
            return self._normalize(raw)
        except Exception as exc:
            logger.error("Reverse geocoding error: %s", exc)
            return None

    @staticmethod
    def _normalize(raw: dict) -> dict:
        """Normalise a Nominatim result into a consistent location dict.

        Canonical output keys:
            name, display_name,
            latitude, longitude,      ← primary (float)
            lat, lon,                  ← aliases for lat/lon (float, same values)
            city, region, country,
            place_type,
            osm_id, bbox
        """
        addr:     dict = raw.get("address", {}) if isinstance(raw.get("address"), dict) else {}
        category: str  = raw.get("category", raw.get("type", "place"))
        osm_type: str  = raw.get("type", "")

        # ── Structured address fields ─────────────────────────────────────────
        country = addr.get("country", "")
        region  = (
            addr.get("state")
            or addr.get("state_district")
            or addr.get("region")
            or addr.get("county")
            or ""
        )
        city = (
            addr.get("city")
            or addr.get("town")
            or addr.get("village")
            or addr.get("hamlet")
            or addr.get("suburb")
            or addr.get("county")
            or ""
        )

        # ── Name resolution ────────────────────────────────────────────────────
        name = (
            raw.get("name")
            or addr.get("amenity")
            or addr.get("road")
            or addr.get("aerodrome")
            or city
            or raw.get("display_name", "Unknown").split(",")[0].strip()
        )

        # ── Coordinates ────────────────────────────────────────────────────────
        lat = float(raw.get("lat", 0))
        lon = float(raw.get("lon", 0))

        # ── Place type ─────────────────────────────────────────────────────────
        place_type = _categorize_place(category, osm_type, addr)

        return {
            # Primary names
            "name":         name,
            "display_name": raw.get("display_name", ""),
            # Canonical coordinate keys
            "latitude":     lat,
            "longitude":    lon,
            # Aliases for backward compatibility
            "lat":          lat,
            "lon":          lon,
            # Structured location
            "city":         city,
            "region":       region,
            "country":      country,
            "place_type":   place_type,
            # Legacy fields kept for backward compatibility
            "category":     category,
            "type":         osm_type,
            "address":      raw.get("display_name", ""),  # string, NOT dict
            "osm_id":       raw.get("osm_id"),
            "bbox":         raw.get("boundingbox", []),
        }


# Module-level singleton
geocoding_service = GeocodingService()
