"""
Nearby places service using OpenStreetMap Overpass API.
Falls back to SQLite-seeded places data when offline or unavailable.
"""
from __future__ import annotations

import math
import time
import logging
from typing import Optional

import requests

from app.config import OVERPASS_BASE, NOMINATIM_USER_AGENT
from app.database.repositories import destination_repo, place_repo

logger = logging.getLogger(__name__)

# Public Overpass mirrors for fast failover
OVERPASS_SERVERS = [
    OVERPASS_BASE,
    "https://overpass.kumi.systems/api/interpreter",
    "https://overpass.private.coffee/api/interpreter",
]

# Fast failure timeouts (seconds): connect fast, read fast, don't stall the app
OVERPASS_CONNECT_TIMEOUT = 2.0
OVERPASS_READ_TIMEOUT = 3.5
OVERPASS_QUERY_TIMEOUT = 4  # Server-side timeout directive in QL

# Short in-memory cache TTL (5 minutes) for successful queries
PLACES_CACHE_TTL = 300.0


def haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Calculate the great circle distance between two points in kilometers."""
    R = 6371.0  # Earth radius in kilometers
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = (math.sin(dlat / 2) ** 2 +
         math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) *
         math.sin(dlon / 2) ** 2)
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R * c


# Map UI category names to Overpass OSM tags
_CATEGORY_TAGS: dict[str, list[tuple[str, str]]] = {
    "Restaurants":    [("amenity", "restaurant"), ("amenity", "fast_food")],
    "Cafes":          [("amenity", "cafe")],
    "Hotels":         [("tourism", "hotel"), ("tourism", "guest_house")],
    "Museums":        [("tourism", "museum"), ("tourism", "gallery")],
    "Beaches":        [("natural", "beach")],
    "Parks":          [("leisure", "park"), ("leisure", "garden")],
    "Shopping":       [("shop", "mall"), ("shop", "supermarket")],
    "Fuel":           [("amenity", "fuel")],
    "Hospitals":      [("amenity", "hospital"), ("amenity", "clinic")],
    "ATMs":           [("amenity", "atm"), ("amenity", "bank")],
    "Entertainment":  [("amenity", "theatre"), ("amenity", "cinema"), ("leisure", "amusement_arcade")],
    "Attractions":    [("tourism", "attraction"), ("tourism", "viewpoint")],
    "Religious":      [("amenity", "place_of_worship")],
}

ALL_CATEGORIES = list(_CATEGORY_TAGS.keys())


class PlacesService:
    """Search nearby POIs using Overpass API with SQLite fallback, caching, and retry."""

    def __init__(self):
        self._cache: dict[tuple, tuple[float, list[dict]]] = {}
        self.last_query_error: Optional[str] = None

    def get_nearby(
        self,
        lat: float,
        lon: float,
        category: str = "Attractions",
        radius_m: int = 5000,
        limit: int = 12,
    ) -> list[dict]:
        """
        Return nearby places of a given category around (lat, lon).
        Checks cache first, queries Overpass API with fast timeout & retry,
        and falls back to SQLite seeded data when offline or unavailable.
        """
        self.last_query_error = None
        cache_key = (round(lat, 3), round(lon, 3), category, radius_m, limit)
        now = time.time()

        # 1. Check in-memory cache
        cached = self._cache.get(cache_key)
        if cached:
            ts, data = cached
            if now - ts < PLACES_CACHE_TTL:
                logger.debug("Places: returning cached result (%d items)", len(data))
                return data
            else:
                self._cache.pop(cache_key, None)

        # 2. Query Overpass with fast failure, mirror rotation, and retry
        result = self._overpass_query(lat, lon, category, radius_m, limit)
        if result is not None and len(result) > 0:
            self._cache[cache_key] = (now, result)
            return result

        # 3. Fallback: use SQLite seeded data near this location
        fallback = self._sqlite_fallback(lat, lon, category, limit)
        if fallback:
            logger.info("Places: using SQLite fallback (%d items)", len(fallback))
            return fallback

        # If Overpass returned an explicit empty list (valid search, but 0 matches in area)
        if result is not None:
            return []

        # If Overpass failed (error / timeout) and fallback had no data
        if not self.last_query_error:
            self.last_query_error = "Places couldn't be loaded right now."
        return []

    def get_popular(self, destination_name: str) -> list[dict]:
        """Return popular places for a named destination from the SQLite seed."""
        dests = destination_repo.search(destination_name)
        if not dests:
            return []
        dest_id = dests[0]["id"]
        places = place_repo.get_by_destination(dest_id)
        return [self._normalize_db_place(p) for p in places[:12]]

    def clear_cache(self) -> None:
        """Clear the in-memory places cache."""
        self._cache.clear()

    # ── Internal ──────────────────────────────────────────────────────────────

    def _overpass_query(
        self,
        lat: float,
        lon: float,
        category: str,
        radius_m: int,
        limit: int,
    ) -> Optional[list[dict]]:
        tags = _CATEGORY_TAGS.get(category, [("tourism", "attraction")])

        def _make_query(r_m: int) -> str:
            union_parts = []
            for k, v in tags:
                union_parts.append(f'node["{k}"="{v}"](around:{r_m},{lat},{lon});')
                union_parts.append(f'way["{k}"="{v}"](around:{r_m},{lat},{lon});')

            # [timeout:4] so Overpass itself fails fast rather than holding socket
            # out center qt: quadtree sort avoids expensive full-dataset sorting
            return f"""[out:json][timeout:{OVERPASS_QUERY_TIMEOUT}];
(
  {''.join(union_parts)}
);
out center qt {limit};
"""

        query = _make_query(radius_m)
        headers = {
            "User-Agent": NOMINATIM_USER_AGENT,
            "Accept": "application/json",
        }
        timeout = (OVERPASS_CONNECT_TIMEOUT, OVERPASS_READ_TIMEOUT)

        max_attempts = 2
        for attempt in range(max_attempts):
            server = OVERPASS_SERVERS[attempt % len(OVERPASS_SERVERS)]
            try:
                logger.debug("Places: Overpass attempt %d/%d to %s", attempt + 1, max_attempts, server)
                resp = requests.post(
                    server,
                    data={"data": query},
                    headers=headers,
                    timeout=timeout,
                )

                # Handle gateway timeout, rate-limiting, or server busy
                if resp.status_code in (429, 504, 502, 503, 408):
                    logger.warning(
                        "Places: Overpass %s returned HTTP %d on attempt %d/%d",
                        server, resp.status_code, attempt + 1, max_attempts
                    )
                    if attempt < max_attempts - 1:
                        time.sleep(0.3 * (attempt + 1))
                        # If radius was large (>3000m), reduce to 3000m on retry to lighten query
                        if radius_m > 3000 and attempt == 0:
                            query = _make_query(3000)
                        continue
                    else:
                        self.last_query_error = "Places couldn't be loaded right now."
                        return None

                resp.raise_for_status()
                data = resp.json()
                elements = data.get("elements", [])
                logger.debug("Places: Overpass returned %d elements", len(elements))
                return [
                    self._normalize_overpass(el, category, center_lat=lat, center_lon=lon)
                    for el in elements
                    if self._has_name(el)
                ]

            except (requests.exceptions.Timeout, requests.exceptions.ReadTimeout, requests.exceptions.ConnectTimeout) as exc:
                logger.warning(
                    "Places: Overpass timeout on attempt %d/%d (%s): %s",
                    attempt + 1, max_attempts, server, exc
                )
                if attempt < max_attempts - 1:
                    time.sleep(0.3 * (attempt + 1))
                    if radius_m > 3000 and attempt == 0:
                        query = _make_query(3000)
                    continue
                else:
                    self.last_query_error = "Places couldn't be loaded right now."

            except requests.exceptions.ConnectionError as exc:
                logger.info(
                    "Places: Connection error on attempt %d/%d (%s): %s",
                    attempt + 1, max_attempts, server, exc
                )
                if attempt < max_attempts - 1:
                    time.sleep(0.2)
                    continue
                else:
                    self.last_query_error = "Places couldn't be loaded right now."

            except Exception as exc:
                logger.error("Places: Overpass error on attempt %d: %s", attempt + 1, exc)
                self.last_query_error = "Places couldn't be loaded right now."
                break

        return None

    def _sqlite_fallback(
        self,
        lat: float,
        lon: float,
        category: str,
        limit: int,
    ) -> list[dict]:
        """Find nearest destination in DB and return its places."""
        all_dests = destination_repo.get_all()
        if not all_dests:
            return []

        # Find nearest destination by straight-line distance
        def dist(d):
            dlat = d["lat"] - lat
            dlon = d["lon"] - lon
            return dlat * dlat + dlon * dlon

        nearest = min(all_dests, key=dist)
        km_to_nearest = haversine_distance(lat, lon, nearest["lat"], nearest["lon"])

        # Only use fallback if destination is reasonably close (<= 200 km)
        if km_to_nearest > 200.0:
            logger.debug(
                "Places: nearest DB destination '%s' is %.1f km away (too far for fallback)",
                nearest.get("name"), km_to_nearest
            )
            return []

        places = place_repo.get_by_destination(nearest["id"])
        # Prefer places that match category if possible
        cat_lower = category.lower()
        matched = [p for p in places if cat_lower in p.get("category", "").lower()]
        selected = matched if matched else places

        result = [self._normalize_db_place(p, center_lat=lat, center_lon=lon) for p in selected]
        return result[:limit]

    @staticmethod
    def _has_name(element: dict) -> bool:
        tags = element.get("tags", {})
        return bool(tags.get("name"))

    @staticmethod
    def _normalize_overpass(el: dict, category: str, center_lat: float = 0.0, center_lon: float = 0.0) -> dict:
        tags = el.get("tags", {})
        if el.get("type") == "way":
            c = el.get("center", {})
            lat, lon = c.get("lat", 0), c.get("lon", 0)
        else:
            lat, lon = el.get("lat", 0), el.get("lon", 0)

        # Calculate actual straight-line distance if center is provided
        dist_km = None
        if center_lat and center_lon and lat and lon:
            dist_km = round(haversine_distance(center_lat, center_lon, lat, lon), 2)

        # Real address extraction
        addr_parts = [tags.get("addr:street", ""), tags.get("addr:city", "")]
        street_city = ", ".join([p for p in addr_parts if p.strip()])
        address = tags.get("addr:full") or street_city or ""

        place_dict = {
            "name":        tags.get("name", "Unnamed"),
            "category":    category,
            "lat":         lat,
            "lon":         lon,
            "address":     address,
            "description": tags.get("description", tags.get("tourism", tags.get("amenity", ""))),
            "rating":      0,  # 0 indicates rating unavailable (never fabricate)
            "source":      "osm",
        }
        if dist_km is not None:
            place_dict["distance_km"] = dist_km
        return place_dict

    @staticmethod
    def _normalize_db_place(p: dict, center_lat: float = 0.0, center_lon: float = 0.0) -> dict:
        lat = p.get("lat", 0)
        lon = p.get("lon", 0)
        dist_km = None
        if center_lat and center_lon and lat and lon:
            dist_km = round(haversine_distance(center_lat, center_lon, lat, lon), 2)

        place_dict = {
            "name":        p.get("name", ""),
            "category":    p.get("category", ""),
            "lat":         lat,
            "lon":         lon,
            "address":     p.get("address", ""),
            "description": p.get("description", ""),
            "rating":      p.get("rating", 0),
            "source":      "db",
        }
        if dist_km is not None:
            place_dict["distance_km"] = dist_km
        return place_dict


# Module-level singleton
places_service = PlacesService()
