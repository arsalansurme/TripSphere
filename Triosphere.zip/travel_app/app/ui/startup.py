"""
Realistic 3D Earth startup screen for TripSphere.
Wraps the interactive WebGL/Three.js globe in a QWebEngineView.
"""
from __future__ import annotations

import logging
from pathlib import Path

from PySide6.QtCore import QObject, QUrl, Qt, Signal, Slot, QThread
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtWebEngineCore import QWebEnginePage, QWebEngineNewWindowRequest
from PySide6.QtWebChannel import QWebChannel
from PySide6.QtWidgets import QWidget, QVBoxLayout

from app.api.geocoding import geocoding_service

logger = logging.getLogger(__name__)

_STARTUP_HTML = Path(__file__).parent / "startup.html"


class _StartupPage(QWebEnginePage):
    """
    Custom QWebEnginePage for the startup globe that blocks all new-window
    creation.  See _MapPage in map_view.py for the full explanation.

    In Qt 6.8+, newWindowRequested replaces createWindow() as the primary
    mechanism.  Both are handled here to cover all Qt versions.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        # Qt 6.8+: connect newWindowRequested to suppress native window creation.
        self.newWindowRequested.connect(self._block_new_window)

    @Slot(QWebEngineNewWindowRequest)
    def _block_new_window(self, request: QWebEngineNewWindowRequest) -> None:
        """Discard any new-window request — never create a second native window."""
        logger.debug(
            "StartupPage: blocked new-window request (destination=%s, url=%s).",
            request.destination(),
            request.requestedUrl().toString(),
        )
        # Intentionally do NOT call request.openIn().

    def createWindow(self, window_type: QWebEnginePage.WebWindowType) -> "QWebEnginePage | None":
        """Fallback for older Qt versions — return None to block window creation."""
        logger.debug(
            "StartupPage: blocked new-window request (type=%s).",
            window_type,
        )
        return None


# ── Geocode worker (QThread-based for thread-safe signal delivery) ────────────

class _StartupGeocodeWorker(QObject):
    """
    Runs geocoding in a Qt-managed worker thread.

    Uses QThread (not threading.Thread) so that signal emission crosses the
    thread boundary safely via Qt's queued-connection mechanism.
    Raw threading.Thread calling Qt signals is undefined behaviour and
    produces QObject::setParent errors and rogue blank windows.
    """
    finished = Signal(float, float)  # lat, lon

    def __init__(self, query: str, parent: QObject | None = None):
        super().__init__(parent)
        self._query = query

    @Slot()
    def run(self) -> None:
        query = self._query
        result = geocoding_service.geocode(query)
        if result:
            lat = float(result.get("lat", 0) or result.get("latitude", 0))
            lon = float(result.get("lon", 0) or result.get("longitude", 0))
            logger.info("Startup geocode success: %s -> (%.4f, %.4f)", query, lat, lon)
        else:
            logger.warning("Startup geocode fallback for: %s", query)
            q = query.lower()
            if "india" in q:
                lat, lon = 20.5937, 78.9629
            elif "japan" in q or "tokyo" in q:
                lat, lon = 35.6762, 139.6503
            elif "france" in q or "paris" in q:
                lat, lon = 48.8566, 2.3522
            elif "swiss" in q or "alps" in q:
                lat, lon = 46.8182, 8.2275
            elif "spain" in q or "madrid" in q:
                lat, lon = 40.4168, -3.7038
            elif "brazil" in q:
                lat, lon = -14.2350, -51.9253
            elif "usa" in q or "america" in q:
                lat, lon = 37.0902, -95.7129
            else:
                lat, lon = 20.5937, 78.9629
        self.finished.emit(lat, lon)


# ── Bridge ────────────────────────────────────────────────────────────────────

class StartupBridge(QObject):
    """Bridge for communication from HTML/JS startup screen to Python."""

    search_submitted = Signal(str)
    skip_clicked     = Signal()
    zoom_completed   = Signal(str, float, float)

    @Slot(str)
    def on_search(self, query: str) -> None:
        logger.info("Startup search submitted: %s", query)
        self.search_submitted.emit(query)

    @Slot()
    def on_skip(self) -> None:
        logger.info("Startup skipped by user.")
        self.skip_clicked.emit()

    @Slot(str, float, float)
    def on_zoom_complete(self, query: str, lat: float, lon: float) -> None:
        logger.info("Startup globe zoom complete for coordinate: %.4f, %.4f", lat, lon)
        self.zoom_completed.emit(query, lat, lon)


# ── Screen ────────────────────────────────────────────────────────────────────

class StartupScreen(QWidget):
    """
    Startup Screen hosting a WebGL/Three.js interactive 3D Globe.
    Provides draggable Earth rotation, Google Earth-like zoom transition,
    and a modern Apple-style UI.
    """

    ready = Signal(str, float, float)  # emitted when zoom animation completes
    skip  = Signal()                   # emitted when user skips startup

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)

        # QThread references — kept alive until each geocode finishes
        self._geocode_thread: QThread | None = None
        self._geocode_worker: _StartupGeocodeWorker | None = None

        # ── Build layout ──────────────────────────────────────────────────────
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # WebEngine View for Three.js Globe
        self._web = QWebEngineView(self)
        self._web.setStyleSheet("background: #091540;")

        # Block new-window creation before any content loads
        self._web.setPage(_StartupPage(self._web))

        # Allow local content to load remote URLs (CDN assets)
        self._web.settings().setAttribute(
            self._web.settings().WebAttribute.LocalContentCanAccessRemoteUrls, True
        )

        # ── WebChannel bridge ─────────────────────────────────────────────────
        self._bridge = StartupBridge(self)
        self._bridge.search_submitted.connect(self._handle_search)
        self._bridge.skip_clicked.connect(self.skip.emit)
        self._bridge.zoom_completed.connect(self.ready.emit)

        channel = QWebChannel(self)
        channel.registerObject("bridge", self._bridge)
        self._web.page().setWebChannel(channel)

        # Route JS console messages through Python logger for debugging
        self._web.page().javaScriptConsoleMessage = (
            lambda level, msg, line, sourceID:
                logger.info("JS Console [%s]: %s (line %d)", sourceID, msg, line)
        )

        layout.addWidget(self._web)

        # ── Load globe HTML ───────────────────────────────────────────────────
        if _STARTUP_HTML.exists():
            self._web.load(QUrl.fromLocalFile(str(_STARTUP_HTML)))
        else:
            logger.error("startup.html not found at %s", _STARTUP_HTML)

    # ── Geocoding ─────────────────────────────────────────────────────────────

    def _handle_search(self, query: str) -> None:
        """Geocode query asynchronously using a QThread (thread-safe)."""
        # Cancel any previous geocode still in flight
        if self._geocode_thread and self._geocode_thread.isRunning():
            self._geocode_thread.quit()
            self._geocode_thread.wait(500)

        self._geocode_thread = QThread(self)
        self._geocode_worker = _StartupGeocodeWorker(query)
        self._geocode_worker.moveToThread(self._geocode_thread)

        # QObject ↔ QObject connection: Qt auto-detects the thread boundary
        # and delivers the signal via a *queued* connection to the main thread.
        self._geocode_worker.finished.connect(self._on_geocode_complete)
        self._geocode_worker.finished.connect(self._geocode_thread.quit)
        self._geocode_worker.finished.connect(self._geocode_worker.deleteLater)
        self._geocode_thread.finished.connect(self._geocode_thread.deleteLater)
        self._geocode_thread.finished.connect(
            lambda: setattr(self, "_geocode_thread", None)
        )

        self._geocode_thread.started.connect(self._geocode_worker.run)
        self._geocode_thread.start()

    @Slot(float, float)
    def _on_geocode_complete(self, lat: float, lon: float) -> None:
        """Called on the main thread once geocoding finishes."""
        self._web.page().runJavaScript(f"animateZoomTo({lat}, {lon})")

    # ── Public API ────────────────────────────────────────────────────────────

    def reset_globe(self) -> None:
        """Reset the globe presentation view and input state in JS."""
        self._web.page().runJavaScript(
            "if (typeof resetStartup === 'function') resetStartup();"
        )
