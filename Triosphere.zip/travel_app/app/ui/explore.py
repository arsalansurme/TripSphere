"""
Explore screen — interactive map with place search, route tracker, and nearby places.
"""
from __future__ import annotations

import logging
from typing import Optional

from PySide6.QtCore    import QObject, QThread, Qt, Signal, Slot, QTimer
from PySide6.QtGui     import QColor, QFont
from PySide6.QtWidgets import (
    QComboBox, QFrame, QGridLayout, QHBoxLayout, QLabel, QPushButton,
    QScrollArea, QSizePolicy, QSplitter, QVBoxLayout, QWidget,
    QLineEdit, QStackedWidget, QGraphicsDropShadowEffect
)

from app.config import COLORS, FONT
from app.api.geocoding import geocoding_service
from app.api.routing   import routing_service
from app.api.places    import places_service, ALL_CATEGORIES
from app.map.map_view  import MapView
from app.ui.widgets.search_bar        import SearchBar, LocationSearchWidget
from app.ui.widgets.loading           import LoadingSpinner, EmptyStateWidget
from app.ui.widgets.cards             import PlaceCard
from app.ui.widgets.travel_mode_selector import InlineComboBox, TravelModeSelector
from app.ui.widgets.route_summary     import RouteSummaryWidget
from app.database.repositories import favorites_repo, trip_repo

logger = logging.getLogger(__name__)


def get_lat_lon(loc: dict) -> tuple[float, float]:
    """Extract lat/lon from a location dict, supporting both key conventions."""
    lat = loc.get("latitude") or loc.get("lat") or 0.0
    lon = loc.get("longitude") or loc.get("lon") or 0.0
    return float(lat), float(lon)


# ── Workers ──────────────────────────────────────────────────────────────────

class GeoWorker(QObject):
    finished = Signal(list)
    def __init__(self, query: str):
        super().__init__()
        self.query = query
    def run(self):
        self.finished.emit(geocoding_service.search(self.query, limit=6))


class RouteWorker(QObject):
    finished = Signal(dict)
    error    = Signal(str)
    def __init__(self, o_lat, o_lon, d_lat, d_lon, mode):
        super().__init__()
        self.args = (o_lat, o_lon, d_lat, d_lon, mode)
    def run(self):
        try:
            self.finished.emit(routing_service.get_route(*self.args))
        except Exception as exc:
            logger.error("RouteWorker exception: %s", exc)
            self.finished.emit({
                "supported": True, "mode": self.args[4],
                "mode_name": self.args[4], "mode_icon": "",
                "distance_km": 0, "duration_min": 0, "duration_str": "—",
                "geometry": [], "steps": [], "fallback": False,
                "error": str(exc), "error_type": "exception",
                "unsupported_message": None,
            })


class RouteResolveAndCalculateWorker(QObject):
    """
    Worker that resolves origin/destination locations (geocoding text if
    they were not already selected from autocomplete) and then calculates
    the route.
    """
    finished = Signal(dict)

    def __init__(self, origin_place: dict | None, origin_text: str,
                 dest_place: dict | None, dest_text: str, mode: str):
        super().__init__()
        self.origin_place = origin_place
        self.origin_text  = origin_text
        self.dest_place   = dest_place
        self.dest_text    = dest_text
        self.mode         = mode

    def run(self):
        from app.ui.widgets.search_bar import _make_location_dict
        try:
            # 1. Resolve origin if needed
            o_place = self.origin_place
            if not o_place and self.origin_text:
                res = geocoding_service.search(self.origin_text, limit=1)
                if res:
                    o_place = _make_location_dict(res[0])
                else:
                    self.finished.emit({
                        "supported": False,
                        "error": f"Could not find origin '{self.origin_text}'.",
                        "unsupported_message": f"Could not find origin '{self.origin_text}'. Please check the spelling or select from dropdown.",
                        "resolve_error": "origin",
                    })
                    return

            # 2. Resolve destination if needed
            d_place = self.dest_place
            if not d_place and self.dest_text:
                res = geocoding_service.search(self.dest_text, limit=1)
                if res:
                    d_place = _make_location_dict(res[0])
                else:
                    self.finished.emit({
                        "supported": False,
                        "error": f"Could not find destination '{self.dest_text}'.",
                        "unsupported_message": f"Could not find destination '{self.dest_text}'. Please check the spelling or select from dropdown.",
                        "resolve_error": "destination",
                    })
                    return

            o_lat, o_lon = get_lat_lon(o_place)
            d_lat, d_lon = get_lat_lon(d_place)

            if o_lat == 0 and o_lon == 0:
                self.finished.emit({
                    "supported": False,
                    "error": "Origin coordinates are missing.",
                    "unsupported_message": "Origin coordinates are missing. Please re-select the origin.",
                    "resolve_error": "origin",
                })
                return

            if d_lat == 0 and d_lon == 0:
                self.finished.emit({
                    "supported": False,
                    "error": "Destination coordinates are missing.",
                    "unsupported_message": "Destination coordinates are missing. Please re-select the destination.",
                    "resolve_error": "destination",
                })
                return

            from app.api.routing import routing_service as rs
            if rs.haversine(o_lat, o_lon, d_lat, d_lon) < 0.1:
                self.finished.emit({
                    "supported": False,
                    "error": "Origin and destination cannot be the same location.",
                    "unsupported_message": "Origin and destination cannot be the same location.",
                    "resolve_error": "same",
                })
                return

            # 3. Calculate route
            route = routing_service.get_route(o_lat, o_lon, d_lat, d_lon, self.mode)
            route["resolved_origin"] = o_place
            route["resolved_dest"]   = d_place
            self.finished.emit(route)

        except Exception as exc:
            logger.error("Route calculation error: %s", exc)
            self.finished.emit({
                "supported": False,
                "error": str(exc),
                "unsupported_message": f"Route calculation failed: {exc}",
                "resolve_error": "exception",
                "mode": self.mode,
                "distance_km": 0,
                "duration_min": 0,
                "duration_str": "—",
                "geometry": [],
                "steps": [],
            })


class NearbyWorker(QObject):
    finished = Signal(object)
    error = Signal(object)

    def __init__(
        self,
        lat: float = 0.0,
        lon: float = 0.0,
        category: str = "Attractions",
        radius: int = 5000,
        request_id: int = 0,
        loc_name: str = "",
        location_text: str = "",
    ):
        super().__init__()
        self.lat = lat
        self.lon = lon
        self.category = category
        self.radius = radius
        self.request_id = request_id
        self.loc_name = loc_name
        self.location_text = location_text

    def run(self):
        try:
            lat, lon, name = self.lat, self.lon, self.loc_name
            # If coordinates are missing but text was provided, resolve in worker thread (never blocks UI)
            if (not lat or not lon) and self.location_text:
                matches = geocoding_service.search(self.location_text, limit=1)
                if matches:
                    lat, lon = get_lat_lon(matches[0])
                    name = matches[0].get("name", self.location_text)
                else:
                    self.error.emit({
                        "message": "Location not found. Please try another search.",
                        "request_id": self.request_id,
                        "can_retry": False,
                    })
                    return

            if not lat or not lon:
                self.error.emit({
                    "message": "Please select or search for a location first.",
                    "request_id": self.request_id,
                    "can_retry": False,
                })
                return

            places = places_service.get_nearby(lat, lon, self.category, radius_m=self.radius)
            if places_service.last_query_error and not places:
                self.error.emit({
                    "message": places_service.last_query_error,
                    "request_id": self.request_id,
                    "can_retry": True,
                })
                return

            self.finished.emit({
                "places": places or [],
                "lat": lat,
                "lon": lon,
                "name": name or self.category,
                "request_id": self.request_id,
            })
        except Exception as exc:
            logger.error("Nearby places request failed: %s", exc)
            self.error.emit({
                "message": "Places couldn't be loaded right now.",
                "request_id": self.request_id,
                "can_retry": True,
            })


class _ThreadSafeRelay(QObject):
    """
    Thin QObject that lives on the *main* thread and wraps a plain callable
    slot.  Because it is a QObject, Qt uses an auto-connection between the
    worker signal (worker-thread) and this slot (main-thread), which Qt
    automatically upgrades to a queued connection.  This guarantees the
    callable always executes on the UI thread.

    Without this wrapper, ``worker.finished.connect(lambda: ...)`` creates a
    direct connection that fires on the worker thread, causing
    ``QObject::setParent: Cannot set parent, new parent is in a different
    thread`` errors and potential crashes when UI widgets are touched.
    """
    _relay = Signal(object)   # carries the result value back to the main thread

    def __init__(self, slot, parent: QObject | None = None):
        super().__init__(parent)
        self._slot = slot
        self._relay.connect(self._dispatch)

    @Slot(object)
    def _dispatch(self, result) -> None:
        """Always called on the main thread."""
        self._slot(result)

    def receive(self, result) -> None:
        """Called by the worker signal (worker-thread); re-emits via the queue."""
        self._relay.emit(result)


_ACTIVE_THREADS: set[QThread] = set()


def cleanup_active_threads() -> None:
    """Safely stop and wait for any background threads in Explore."""
    for t in list(_ACTIVE_THREADS):
        try:
            if t and t.isRunning():
                t.quit()
                if not t.wait(200):
                    t.terminate()
                    t.wait(100)
        except Exception:
            pass


def _run_in_thread(worker: QObject, slot, error_slot=None) -> QThread:
    """
    Run *worker* in a background QThread and deliver its ``finished`` result
    to *slot* safely on the UI thread.
    If *error_slot* is provided, delivers worker's ``error`` signal safely to
    *error_slot* on the UI thread.
    """
    thread  = QThread()
    _ACTIVE_THREADS.add(thread)
    relay   = _ThreadSafeRelay(slot)       # lives on main thread
    thread._worker = worker
    thread._relay  = relay                 # keep alive until thread finishes

    if error_slot is not None:
        err_relay = _ThreadSafeRelay(error_slot)
        thread._err_relay = err_relay
        if hasattr(worker, "error"):
            worker.error.connect(err_relay.receive)

    worker.moveToThread(thread)
    thread.started.connect(worker.run)
    # worker → relay: auto→queued (different threads, relay is a QObject)
    worker.finished.connect(relay.receive)
    worker.finished.connect(thread.quit)
    if hasattr(worker, "error"):
        worker.error.connect(thread.quit)
    worker.finished.connect(worker.deleteLater)
    thread.finished.connect(relay.deleteLater)
    if error_slot is not None:
        thread.finished.connect(err_relay.deleteLater)
    thread.finished.connect(lambda: _ACTIVE_THREADS.discard(thread))
    thread.finished.connect(thread.deleteLater)
    thread.start()
    return thread


# ── Helpers ─────────────────────────────────────────────────────────────────

def _section_label(text: str) -> QLabel:
    lbl = QLabel(text.upper())
    lbl.setStyleSheet("""
        color: rgba(118,146,255,0.45);
        font-size: 9px;
        font-weight: 700;
        letter-spacing: 1.2px;
        background: transparent;
        padding: 0 2px;
    """)
    return lbl


def _glass_frame(radius: int = 12) -> QFrame:
    f = QFrame()
    f.setStyleSheet(f"""
        QFrame {{
            background: rgba(17,35,110,0.50);
            border: 1px solid rgba(118,146,255,0.16);
            border-radius: {radius}px;
        }}
    """)
    return f


def _pill_input(placeholder: str) -> QLineEdit:
    le = QLineEdit()
    le.setPlaceholderText(placeholder)
    le.setFixedHeight(36)
    le.setStyleSheet("""
        QLineEdit {
            background: rgba(9,21,64,0.65);
            color: #F0F4FF;
            border: 1px solid rgba(118,146,255,0.18);
            border-radius: 9px;
            padding: 0 12px;
            font-size: 13px;
        }
        QLineEdit:focus {
            border: 1.5px solid rgba(118,146,255,0.55);
            background: rgba(27,44,193,0.15);
        }
    """)
    return le


# ── Tab button ───────────────────────────────────────────────────────────────

class PanelTabBtn(QPushButton):
    def __init__(self, text: str, parent=None):
        super().__init__(text, parent)
        self._active = False
        self.setFixedHeight(30)
        self.setCursor(Qt.PointingHandCursor)
        self._apply()

    def set_active(self, active: bool):
        self._active = active
        self._apply()

    def _apply(self):
        if self._active:
            self.setStyleSheet("""
                QPushButton {
                    background: rgba(216, 177, 90, 0.15);
                    color: #D8B15A;
                    border: 1px solid rgba(216, 177, 90, 0.25);
                    border-radius: 8px;
                    font-size: 12px;
                    font-weight: 700;
                    padding: 0 16px;
                }
            """)
        else:
            self.setStyleSheet("""
                QPushButton {
                    background: transparent;
                    color: #AAB7C5;
                    border: none;
                    border-radius: 8px;
                    font-size: 12px;
                    font-weight: 500;
                    padding: 0 16px;
                }
                QPushButton:hover {
                    background: rgba(255,255,255,0.05);
                    color: #F5F1E8;
                }
            """)


# ── Explore Screen ────────────────────────────────────────────────────────────

class ExploreScreen(QWidget):
    """
    Full-window map exploration with three left-panel tabs:
      Search · Route · Nearby
    """

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self._selected_place: Optional[dict] = None
        self._nearby_location_place: Optional[dict] = None
        self._origin_lat  = 19.0760
        self._origin_lon  = 72.8777
        self._threads: list[QThread] = []
        # Route state — full location dicts with lat/lon
        self._route_origin_place: Optional[dict] = None
        self._route_dest_place:   Optional[dict] = None
        # Marker IDs for origin/dest (so we can remove/replace them)
        self._origin_marker_id: Optional[int] = None
        self._dest_marker_id:   Optional[int] = None
        self._popular_request_id = 0
        self._nearby_request_id = 0
        # Route thread reference to avoid GC
        self._route_thread: Optional[QThread] = None
        self._build_ui()

    # ── Build ────────────────────────────────────────────────────────────────

    def _build_ui(self) -> None:
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        splitter = QSplitter(Qt.Horizontal)
        splitter.setStyleSheet("QSplitter::handle { background: transparent; width: 0; }")

        # ── Left panel ────────────────────────────────────────────────────
        left = QWidget()
        left.setMinimumWidth(300)
        left.setMaximumWidth(480)
        left.setStyleSheet(
            f"background: #111923;"
            f"border-right: 1px solid #263646;"
        )
        lv = QVBoxLayout(left)
        lv.setContentsMargins(0, 0, 0, 0)
        lv.setSpacing(0)

        # Tab bar: Search | Route | Nearby
        tab_row = QHBoxLayout()
        tab_row.setContentsMargins(16, 14, 16, 0)
        tab_row.setSpacing(4)
        self._tab_search = PanelTabBtn("Search")
        self._tab_route  = PanelTabBtn("Route")
        self._tab_nearby = PanelTabBtn("Nearby")
        for btn in (self._tab_search, self._tab_route, self._tab_nearby):
            tab_row.addWidget(btn)
        tab_row.addStretch()
        lv.addLayout(tab_row)

        # Tab separator line
        tab_sep = QFrame()
        tab_sep.setFixedHeight(1)
        tab_sep.setStyleSheet("background: #263646; border: none;")
        tab_sep.setContentsMargins(0, 0, 0, 0)
        lv.addSpacing(10)
        lv.addWidget(tab_sep)
        lv.addSpacing(0)

        self._tab_search.clicked.connect(lambda: self._switch_tab(0))
        self._tab_route.clicked.connect(lambda:  self._switch_tab(1))
        self._tab_nearby.clicked.connect(lambda: self._switch_tab(2))
        self._tab_search.set_active(True)

        # Stacked panels
        self._stack = QStackedWidget()
        self._stack.setStyleSheet("background: transparent;")
        lv.addWidget(self._stack, 1)

        self._stack.addWidget(self._build_search_panel())
        self._stack.addWidget(self._build_route_panel())
        self._stack.addWidget(self._build_nearby_panel())

        splitter.addWidget(left)

        # ── Map ──────────────────────────────────────────────────────────────
        self._map = MapView()
        self._map.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self._map.location_clicked.connect(self._on_map_click)
        splitter.addWidget(self._map)
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)
        splitter.setHandleWidth(0)
        splitter.setSizes([420, 9999])

        layout.addWidget(splitter)

    # ── Panel builders ────────────────────────────────────────────────────────

    def _build_search_panel(self) -> QWidget:
        w = QWidget()
        w.setStyleSheet("background: transparent;")
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 4, 0, 0)
        v.setSpacing(10)

        # Search bar
        self._search = SearchBar("Search cities, landmarks, addresses…")
        self._search.search_submitted.connect(self._on_search)
        self._search.location_selected.connect(self._on_location_selected)
        v.addWidget(self._search)

        # Suggestions layout
        sug_v = QVBoxLayout()
        sug_v.setContentsMargins(0, 8, 0, 8)
        sug_v.setSpacing(10)

        self._popular_label = QLabel("POPULAR NEAR YOU")
        self._popular_label.setStyleSheet(
            "color: rgba(171,210,250,0.45); font-size: 9px; font-weight: 800; "
            "letter-spacing: 1.2px; background: transparent;"
        )
        sug_v.addWidget(self._popular_label)

        self._popular_layout = QHBoxLayout()
        self._popular_layout.setSpacing(6)
        self._popular_layout.addStretch()
        sug_v.addLayout(self._popular_layout)

        mood_lbl = QLabel("EXPLORE BY MOOD")
        mood_lbl.setStyleSheet(
            "color: rgba(171,210,250,0.45); font-size: 9px; font-weight: 800; "
            "letter-spacing: 1.2px; background: transparent;"
        )
        sug_v.addWidget(mood_lbl)

        mood_grid = QGridLayout()
        mood_grid.setHorizontalSpacing(6)
        mood_grid.setVerticalSpacing(6)
        mood_labels = [
            "Beach destinations", "Mountain escapes", "Historical cities",
            "City breaks", "Nature escapes",
        ]
        MOOD_COLS = 3
        for i, label in enumerate(mood_labels):
            btn = QPushButton(label)
            btn.setFixedHeight(28)
            btn.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setToolTip(label)
            btn.setStyleSheet("""
                QPushButton { background: rgba(255,255,255,0.05); color: #E4E4E7;
                    border: 1px solid rgba(255,255,255,0.08); border-radius: 14px;
                    font-size: 11px; font-weight: 600; padding: 0 12px; }
                QPushButton:hover { background: rgba(255,255,255,0.12); color: #FFF; }
            """)
            btn.clicked.connect(
                lambda checked=False, mood=label: self._on_mood_selected(mood)
            )
            mood_grid.addWidget(btn, i // MOOD_COLS, i % MOOD_COLS)
        sug_v.addLayout(mood_grid)

        v.addLayout(sug_v)

        self._spinner = LoadingSpinner(size=34)
        self._spinner.hide()
        v.addWidget(self._spinner, alignment=Qt.AlignCenter)

        # Scrollable results
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("background: transparent; border: none;")
        self._scroll_content = QWidget()
        self._scroll_content.setStyleSheet("background: transparent;")
        self._scroll_layout = QVBoxLayout(self._scroll_content)
        self._scroll_layout.setContentsMargins(0, 0, 4, 0)
        self._scroll_layout.setSpacing(8)
        self._scroll_layout.addStretch(1)
        scroll.setWidget(self._scroll_content)
        v.addWidget(scroll)

        return w

    def _build_route_panel(self) -> QWidget:
        """Premium redesigned route panel with elegant dark theme."""
        w = QWidget()
        w.setStyleSheet("background: transparent;")
        v = QVBoxLayout(w)
        v.setContentsMargins(16, 16, 16, 16)
        v.setSpacing(14)

        # ── Header ──────────────────────────────────────────────────────────────
        header_lbl = QLabel("Plan Your Route")
        header_lbl.setStyleSheet("""
            color: #F5F1E8;
            font-size: 18px;
            font-weight: 700;
            background: transparent;
            letter-spacing: -0.3px;
        """)
        v.addWidget(header_lbl)

        subtitle_lbl = QLabel("Choose your starting point and destination")
        subtitle_lbl.setStyleSheet("""
            color: #6B7A8A;
            font-size: 12px;
            background: transparent;
            letter-spacing: 0.1px;
        """)
        v.addWidget(subtitle_lbl)

        v.addSpacing(4)

        # ── Location Inputs Card ────────────────────────────────────────────────
        loc_card = QFrame()
        loc_card.setStyleSheet("""
            QFrame {
                background: #172332;
                border: 1px solid #263646;
                border-radius: 14px;
            }
        """)
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(20)
        shadow.setColor(QColor(0, 0, 0, 80))
        shadow.setOffset(0, 4)
        loc_card.setGraphicsEffect(shadow)

        loc_v = QVBoxLayout(loc_card)
        loc_v.setContentsMargins(14, 14, 14, 14)
        loc_v.setSpacing(0)

        # ── Origin row ──────────────────────────────────────────────────────────
        orig_row = QHBoxLayout()
        orig_row.setSpacing(10)
        orig_row.setContentsMargins(0, 0, 0, 0)

        orig_dot = QLabel("●")
        orig_dot.setFixedWidth(14)
        orig_dot.setAlignment(Qt.AlignTop)
        orig_dot.setStyleSheet("color: #69C99A; font-size: 16px; background: transparent; margin-top: 10px;")
        orig_row.addWidget(orig_dot)

        self._route_origin_input = LocationSearchWidget("Search starting location...")
        self._route_origin_input.location_selected.connect(self._on_route_origin_selected)
        orig_row.addWidget(self._route_origin_input, 1)
        loc_v.addLayout(orig_row)

        # ── Vertical connector + swap button ────────────────────────────────────
        connector_row = QHBoxLayout()
        connector_row.setContentsMargins(0, 0, 0, 0)
        connector_row.setSpacing(8)

        conn_line = QFrame()
        conn_line.setFixedWidth(1)
        conn_line.setFixedHeight(26)
        conn_line.setStyleSheet("background: #263646; border: none; margin-left: 6px;")
        connector_row.addWidget(conn_line, alignment=Qt.AlignCenter)

        swap_container = QVBoxLayout()
        swap_container.setContentsMargins(0, 0, 0, 0)
        swap_container.setSpacing(0)

        self._swap_btn = QPushButton("⇅")
        self._swap_btn.setFixedSize(28, 28)
        self._swap_btn.setCursor(Qt.PointingHandCursor)
        self._swap_btn.setToolTip("Swap origin and destination")
        self._swap_btn.setStyleSheet("""
            QPushButton {
                background: #121A25;
                color: #AAB7C5;
                border: 1px solid #263646;
                border-radius: 14px;
                font-size: 14px;
                font-weight: 700;
            }
            QPushButton:hover {
                background: #172332;
                color: #D8B15A;
                border-color: rgba(216, 177, 90, 0.4);
            }
        """)
        self._swap_btn.clicked.connect(self._on_swap_route)
        swap_container.addWidget(self._swap_btn, alignment=Qt.AlignCenter)

        connector_row.addLayout(swap_container, 1)
        connector_row.addSpacing(16)
        loc_v.addLayout(connector_row)

        # ── Destination row ─────────────────────────────────────────────────────
        dest_row = QHBoxLayout()
        dest_row.setSpacing(10)
        dest_row.setContentsMargins(0, 0, 0, 0)

        dest_dot = QLabel("●")
        dest_dot.setFixedWidth(14)
        dest_dot.setAlignment(Qt.AlignTop)
        dest_dot.setStyleSheet("color: #E97878; font-size: 16px; background: transparent; margin-top: 10px;")
        dest_row.addWidget(dest_dot)

        self._route_dest_input = LocationSearchWidget("Search destination...")
        self._route_dest_input.location_selected.connect(self._on_route_dest_selected)
        dest_row.addWidget(self._route_dest_input, 1)
        loc_v.addLayout(dest_row)

        v.addWidget(loc_card)

        # ── Travel Mode Section ──────────────────────────────────────────────────
        mode_label = QLabel("Travel mode")
        mode_label.setStyleSheet("""
            color: #AAB7C5;
            font-size: 11px;
            font-weight: 600;
            background: transparent;
            letter-spacing: 0.5px;
        """)
        v.addWidget(mode_label)

        self._mode_selector = TravelModeSelector()
        self._mode_selector.mode_changed.connect(self._on_mode_changed)
        v.addWidget(self._mode_selector)

        v.addSpacing(2)

        # ── Get Route Button ────────────────────────────────────────────────────
        self._get_route_btn = QPushButton("Get Route")
        self._get_route_btn.setFixedHeight(46)
        self._get_route_btn.setCursor(Qt.PointingHandCursor)
        self._get_route_btn.setStyleSheet("""
            QPushButton {
                background: #D8B15A;
                color: #080D14;
                border: none;
                border-radius: 12px;
                font-size: 15px;
                font-weight: 700;
                letter-spacing: 0.3px;
            }
            QPushButton:hover {
                background: #E2C06A;
            }
            QPushButton:pressed {
                background: #C4A04E;
            }
            QPushButton:disabled {
                background: rgba(216, 177, 90, 0.3);
                color: rgba(8, 13, 20, 0.5);
            }
        """)
        self._get_route_btn.clicked.connect(self._on_get_route)
        v.addWidget(self._get_route_btn)

        # ── Clear Route (subtle) ────────────────────────────────────────────────
        clear_container = QHBoxLayout()
        clear_container.setContentsMargins(0, 0, 0, 0)
        clear_container.setSpacing(0)

        self._clear_route_btn = QPushButton("Clear Route")
        self._clear_route_btn.setCursor(Qt.PointingHandCursor)
        self._clear_route_btn.setStyleSheet("""
            QPushButton {
                background: transparent;
                color: #6B7A8A;
                border: none;
                border-radius: 0;
                font-size: 12px;
                font-weight: 500;
                padding: 6px 0;
            }
            QPushButton:hover {
                color: #E97878;
            }
        """)
        self._clear_route_btn.clicked.connect(self._clear_route)
        clear_container.addWidget(self._clear_route_btn)
        clear_container.addStretch()
        v.addLayout(clear_container)

        # ── Route Summary ───────────────────────────────────────────────────────
        self._route_summary = RouteSummaryWidget()
        v.addWidget(self._route_summary)

        v.addStretch()
        return w

    def _build_nearby_panel(self) -> QWidget:
        w = QWidget()
        w.setStyleSheet("background: transparent;")
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 4, 0, 0)
        v.setSpacing(10)

        nf = _glass_frame(14)
        nv = QVBoxLayout(nf)
        nv.setContentsMargins(12, 12, 12, 12)
        nv.setSpacing(10)

        # Center Location Selector
        nv.addWidget(_section_label("Center Location"))
        self._nearby_location_input = LocationSearchWidget("Search location or use selected...")
        self._nearby_location_input.location_selected.connect(self._on_nearby_location_selected)
        nv.addWidget(self._nearby_location_input)

        # Category
        nv.addWidget(_section_label("Category"))
        self._cat_combo = InlineComboBox()
        clean_categories = [
            "Restaurants", "Cafes", "Hotels", "Museums", "Beaches", "Parks",
            "Shopping", "Fuel", "Hospitals", "ATMs", "Entertainment", "Attractions", "Religious"
        ]
        self._cat_combo.addItems([c for c in clean_categories if c in ALL_CATEGORIES])
        nv.addWidget(self._cat_combo)

        # Radius Selector
        nv.addWidget(_section_label("Search Radius"))
        self._radius_combo = InlineComboBox()
        self._radius_combo.addItems(["1 km", "2 km", "5 km", "10 km"])
        self._radius_combo.setCurrentText("5 km")
        nv.addWidget(self._radius_combo)

        near_btn = QPushButton("Search Nearby")
        near_btn.setFixedHeight(36)
        near_btn.setCursor(Qt.PointingHandCursor)
        near_btn.setStyleSheet("""
            QPushButton { background: rgba(46,189,107,0.18); color: #2EBD6B;
                border: 1px solid rgba(46,189,107,0.30); border-radius: 9px;
                font-size: 13px; font-weight: 600; }
            QPushButton:hover { background: rgba(46,189,107,0.30); }
        """)
        near_btn.clicked.connect(self._on_nearby)
        nv.addWidget(near_btn)
        v.addWidget(nf)

        self._near_spinner = LoadingSpinner(size=32)
        self._near_spinner.hide()
        v.addWidget(self._near_spinner, alignment=Qt.AlignCenter)

        near_scroll = QScrollArea()
        near_scroll.setWidgetResizable(True)
        near_scroll.setStyleSheet("background: transparent; border: none;")
        self._near_content = QWidget()
        self._near_content.setStyleSheet("background: transparent;")
        self._near_layout = QVBoxLayout(self._near_content)
        self._near_layout.setContentsMargins(0, 0, 4, 0)
        self._near_layout.setSpacing(8)
        self._near_layout.addStretch(1)
        near_scroll.setWidget(self._near_content)
        v.addWidget(near_scroll)

        return w

    # ── Tab switching ─────────────────────────────────────────────────────────

    def _switch_tab(self, idx: int):
        self._stack.setCurrentIndex(idx)
        self._tab_search.set_active(idx == 0)
        self._tab_route.set_active(idx == 1)
        self._tab_nearby.set_active(idx == 2)

    # ── Mode change ───────────────────────────────────────────────────────────

    def _on_mode_changed(self, mode_key: str):
        """Mode changed; hide any existing result so the user re-requests."""
        self._route_summary.hide_summary()

    # ── Public API ────────────────────────────────────────────────────────────

    def go_to(self, query: str, lat: float, lon: float) -> None:
        self._switch_tab(0)
        self._search.set_text(query)
        self._map.center(lat, lon, zoom=12)
        self._map.add_marker(lat, lon, query, "Location", "", 0, "main")
        self._selected_place = {"lat": lat, "lon": lon, "name": query,
                                "latitude": lat, "longitude": lon}
        self._nearby_location_place = self._selected_place
        if hasattr(self, "_nearby_location_input"):
            self._nearby_location_input.set_selected_location(self._selected_place)
        self._show_place_info({"name": query, "lat": lat, "lon": lon,
                               "latitude": lat, "longitude": lon,
                               "category": "Location", "description": ""})
        self._load_popular_places()

    def go_to_place(self, place: dict) -> None:
        lat, lon = get_lat_lon(place)
        if lat and lon:
            self.go_to(place.get("name", ""), lat, lon)

    # ── Search tab ────────────────────────────────────────────────────────────

    def _on_search(self, query: str) -> None:
        self._spinner.start()
        self._clear_results()
        t = _run_in_thread(GeoWorker(query), self._on_search_results)
        self._threads.append(t)

    def _on_search_results(self, results: list) -> None:
        self._spinner.stop()
        self._clear_results()
        if not results:
            lbl = QLabel("No results found.")
            lbl.setStyleSheet(
                "color: rgba(171,210,250,0.40); font-size: 13px; padding: 12px;"
            )
            self._add_to_scroll(lbl)
            return
        for r in results:
            self._add_result_row(r)
        first = results[0]
        lat, lon = get_lat_lon(first)
        if lat and lon:
            self._map.clear_markers()
            for r in results[:5]:
                rlat, rlon = get_lat_lon(r)
                self._map.add_marker(
                    rlat, rlon, r["name"], r.get("category", ""),
                    r.get("display_name", ""), 0, "place"
                )
            self._map.center(lat, lon, zoom=12)

    def _add_result_row(self, place: dict) -> None:
        row = QFrame()
        row.setStyleSheet("""
            QFrame {
                background: rgba(17,35,110,0.45);
                border: 1px solid rgba(118,146,255,0.14);
                border-radius: 10px;
            }
            QFrame:hover {
                background: rgba(27,44,193,0.25);
                border-color: rgba(118,146,255,0.30);
            }
        """)
        row.setCursor(Qt.PointingHandCursor)
        rl = QVBoxLayout(row)
        rl.setContentsMargins(12, 10, 12, 10)
        rl.setSpacing(2)

        name = QLabel(place.get("name", "Unknown"))
        name.setStyleSheet(
            "color: #F0F4FF; font-size: 13px; font-weight: 600; background: transparent;"
        )
        rl.addWidget(name)

        addr = place.get("display_name", "")
        if len(addr) > 58:
            addr = addr[:58] + "…"
        a_lbl = QLabel(addr)
        a_lbl.setStyleSheet(
            "color: rgba(171,210,250,0.50); font-size: 11px; background: transparent;"
        )
        rl.addWidget(a_lbl)

        def _select(p=place):
            lat, lon = get_lat_lon(p)
            self._map.center(lat, lon, zoom=14)
            self._selected_place = p
            self._nearby_request_id += 1
            self._nearby_location_place = p
            if hasattr(self, "_nearby_location_input"):
                self._nearby_location_input.set_selected_location(p)
            self._show_place_info(p)

        row.mousePressEvent = lambda e, fn=_select: fn()
        self._add_to_scroll(row)

    def _on_location_selected(self, loc: dict) -> None:
        lat, lon = get_lat_lon(loc)
        name     = loc["name"]
        display  = loc.get("display_name", name)
        self._nearby_request_id += 1
        self._map.clear_markers()
        self._map.center(lat, lon, zoom=12)
        self._map.add_marker(lat, lon, name, "Location", display, 0, "main")
        self._selected_place = {**loc, "lat": lat, "lon": lon}
        self._nearby_location_place = self._selected_place
        if hasattr(self, "_nearby_location_input"):
            self._nearby_location_input.set_selected_location(self._selected_place)
        self._show_place_info({
            "name":         name,
            "lat":          lat, "lon": lon,
            "latitude":     lat, "longitude": lon,
            "display_name": display,
            "category":     loc.get("place_type", "Location"),
            "description":  "",
        })
        self._load_popular_places()

    def _on_mood_selected(self, mood: str) -> None:
        """Filter places around the current selected destination."""
        if not self._selected_place:
            self._popular_label.setText("Select a destination to find popular places")
            return
        category = {
            "Beach destinations": "Beaches",
            "Mountain escapes": "Attractions",
            "Historical cities": "Museums",
            "City breaks": "Attractions",
            "Nature escapes": "Parks",
        }.get(mood, "Attractions")
        self._load_popular_places(category)

    def _clear_popular_places(self) -> None:
        while self._popular_layout.count() > 1:
            item = self._popular_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

    def _load_popular_places(self, category: str = "Attractions") -> None:
        if not self._selected_place:
            self._popular_label.setText("Select a destination to find popular places")
            self._clear_popular_places()
            return

        lat, lon = get_lat_lon(self._selected_place)
        if not lat and not lon:
            self._popular_label.setText("No popular places found for this destination.")
            self._clear_popular_places()
            return

        self._popular_request_id += 1
        request_id = self._popular_request_id
        destination = (
            self._selected_place.get("name")
            or self._selected_place.get("display_name", "this destination")
        )
        self._clear_popular_places()
        self._popular_label.setText(f"Finding places in {destination}...")

        worker = NearbyWorker(lat, lon, category, request_id=request_id, loc_name=destination)
        thread = _run_in_thread(
            worker,
            slot=self._on_popular_places_results,
            error_slot=self._on_popular_places_error,
        )
        self._threads.append(thread)

    def _on_popular_places_results(self, data: object, *args) -> None:
        if isinstance(data, dict):
            request_id = data.get("request_id", 0)
            destination = data.get("name", "")
            results = data.get("places", [])
        elif args:
            request_id = data
            destination = args[0]
            results = args[1]
        else:
            request_id = self._popular_request_id
            destination = ""
            results = data or []

        if request_id != self._popular_request_id:
            return
        self._clear_popular_places()
        self._popular_label.setText(f"Popular places near {destination}")
        if not results:
            self._popular_label.setText("No popular places found for this destination.")
            return

        for place in results:
            name = place.get("name", "Unnamed place")
            button = QPushButton(name)
            button.setFixedHeight(28)
            button.setCursor(Qt.PointingHandCursor)
            button.setToolTip(place.get("address", ""))
            button.setStyleSheet("""
                QPushButton { background: rgba(255,255,255,0.05); color: #E4E4E7;
                    border: 1px solid rgba(255,255,255,0.08); border-radius: 14px;
                    font-size: 11px; font-weight: 600; padding: 0 12px; }
                QPushButton:hover { background: rgba(255,255,255,0.12); color: #FFF; }
            """)
            button.clicked.connect(lambda checked=False, p=place: self._show_place_info(p))
            self._popular_layout.insertWidget(self._popular_layout.count() - 1, button)

    def _on_popular_places_error(self, data: object, *args) -> None:
        if isinstance(data, dict):
            request_id = data.get("request_id", 0)
            message = data.get("message", "")
        elif args:
            request_id = data
            message = args[0]
        else:
            request_id = self._popular_request_id
            message = str(data)

        if request_id != self._popular_request_id:
            return
        logger.error("Popular places error: %s", message)
        self._clear_popular_places()
        self._popular_label.setText("Couldn't load nearby places. Try again.")

    def _show_place_info(self, place: dict) -> None:
        self._clear_results()
        card = PlaceCard(place)
        card.view_on_map.connect(lambda lat, lon, name: self._map.center(lat, lon, zoom=14))
        card.favorited.connect(self._save_favorite)
        card.route_to.connect(self._on_route_to)
        card.explore_nearby.connect(self._on_explore_nearby)
        card.add_to_trip.connect(self._on_add_to_trip)
        self._add_to_scroll(card)

    def _on_route_to(self, place: dict):
        self._switch_tab(1)
        self._route_dest_place = place
        self._route_dest_input.set_text(place.get("name", ""))

    def _on_explore_nearby(self, place: dict):
        self._switch_tab(2)
        self._selected_place = place
        self._on_nearby()

    def _on_add_to_trip(self, place: dict):
        trips = trip_repo.get_all()
        if not trips:
            return
        trip = trips[0]
        from app.database.repositories import trip_stop_repo
        stops = trip_stop_repo.get_by_trip(trip["id"])
        order = len(stops)
        trip_stop_repo.insert({
            "trip_id":    trip["id"],
            "stop_order": order,
            "place_name": place.get("name", "Stop"),
            "lat":        place.get("lat") or place.get("latitude"),
            "lon":        place.get("lon") or place.get("longitude"),
            "address":    place.get("display_name", ""),
            "nights":     1,
            "notes":      "",
        })

    # ── Route tab ─────────────────────────────────────────────────────────────

    def _on_swap_route(self):
        """Swap origin and destination locations."""
        # Swap the stored place data
        self._route_origin_place, self._route_dest_place = \
            self._route_dest_place, self._route_origin_place

        # Swap the text in the inputs
        orig_text = self._route_origin_input.text()
        dest_text = self._route_dest_input.text()
        self._route_origin_input.set_text(dest_text)
        self._route_dest_input.set_text(orig_text)

        # Swap map markers
        self._origin_marker_id, self._dest_marker_id = \
            self._dest_marker_id, self._origin_marker_id

        # Hide any existing summary
        self._route_summary.hide_summary()

    def _on_route_origin_selected(self, loc: dict):
        """Called when user picks an origin from the LocationSearchWidget."""
        self._route_origin_place = loc
        if self._route_origin_input.get_selected_location() != loc:
            self._route_origin_input.set_selected_location(loc)
        lat, lon = get_lat_lon(loc)
        # Replace old origin marker
        if self._origin_marker_id is not None:
            self._map.remove_marker(self._origin_marker_id)
        self._origin_marker_id = self._map.add_marker(
            lat, lon, loc.get("name", "Origin"), "Origin", "", 0, "origin"
        )
        self._map.center(lat, lon, zoom=11)
        # Reset summary if visible
        self._route_summary.hide_summary()

    def _on_route_dest_selected(self, loc: dict):
        """Called when user picks a destination from the LocationSearchWidget."""
        self._route_dest_place = loc
        if self._route_dest_input.get_selected_location() != loc:
            self._route_dest_input.set_selected_location(loc)
        lat, lon = get_lat_lon(loc)
        if self._dest_marker_id is not None:
            self._map.remove_marker(self._dest_marker_id)
        self._dest_marker_id = self._map.add_marker(
            lat, lon, loc.get("name", "Destination"), "Destination", "", 0, "dest"
        )
        self._map.center(lat, lon, zoom=11)
        self._route_summary.hide_summary()

    def _on_get_route(self):
        """Validate inputs then request a route in a background thread."""
        origin_text = self._route_origin_input.text().strip()
        dest_text   = self._route_dest_input.text().strip()

        if not origin_text:
            self._route_summary.show_validation_error("Please enter an origin.")
            return

        if not dest_text:
            self._route_summary.show_validation_error("Please enter a destination.")
            return

        # Synchronize with search widgets' internal selected locations if available
        if self._route_origin_place is None:
            self._route_origin_place = self._route_origin_input.get_selected_location()
        if self._route_dest_place is None:
            self._route_dest_place = self._route_dest_input.get_selected_location()

        # If origin_place name doesn't match origin_text, clear it so it re-geocodes
        if self._route_origin_place:
            if self._route_origin_place.get("name", "").strip().lower() != origin_text.lower():
                self._route_origin_place = None

        if self._route_dest_place:
            if self._route_dest_place.get("name", "").strip().lower() != dest_text.lower():
                self._route_dest_place = None

        # ── Disable button during calculation ─────────────────────────────────
        self._get_route_btn.setEnabled(False)
        self._get_route_btn.setText("Calculating…")
        self._route_summary.show_loading()

        mode = self._mode_selector.get_mode()
        worker = RouteResolveAndCalculateWorker(
            self._route_origin_place, origin_text,
            self._route_dest_place, dest_text,
            mode
        )
        self._route_thread = _run_in_thread(worker, self._on_route_result)
        self._threads.append(self._route_thread)

    def _on_route_result(self, result: dict) -> None:
        """Handle route result — called from background thread signal, runs on UI thread."""
        # Re-enable button
        self._get_route_btn.setEnabled(True)
        self._get_route_btn.setText("Get Route")

        if result.get("resolve_error"):
            self._route_summary.show_validation_error(
                result.get("unsupported_message", result.get("error", "Validation error"))
            )
            return

        # Update resolved locations if resolved by worker
        if result.get("resolved_origin"):
            self._route_origin_place = result["resolved_origin"]
            self._route_origin_input.set_selected_location(result["resolved_origin"])
        if result.get("resolved_dest"):
            self._route_dest_place = result["resolved_dest"]
            self._route_dest_input.set_selected_location(result["resolved_dest"])

        # Show result summary (handles all states internally)
        self._route_summary.show_result(result)

        # Draw on map only for real successful routes
        if result.get("supported") and not result.get("error"):
            geo = result.get("geometry", [])
            if geo:
                self._map.clear_route()
                self._map.draw_route(geo)
                # Re-add markers (they may have been cleared)
                if self._route_origin_place:
                    o_lat, o_lon = get_lat_lon(self._route_origin_place)
                    if self._origin_marker_id is not None:
                        self._map.remove_marker(self._origin_marker_id)
                    self._origin_marker_id = self._map.add_marker(
                        o_lat, o_lon,
                        self._route_origin_place.get("name", "Origin"),
                        "Origin", "", 0, "origin"
                    )
                if self._route_dest_place:
                    d_lat, d_lon = get_lat_lon(self._route_dest_place)
                    if self._dest_marker_id is not None:
                        self._map.remove_marker(self._dest_marker_id)
                    self._dest_marker_id = self._map.add_marker(
                        d_lat, d_lon,
                        self._route_dest_place.get("name", "Destination"),
                        "Destination", "", 0, "dest"
                    )
                self._map.fit_bounds(geo)

    def _clear_route(self):
        """Reset all route state."""
        self._route_origin_place = None
        self._route_dest_place   = None
        self._origin_marker_id   = None
        self._dest_marker_id     = None
        self._route_origin_input.clear()
        self._route_dest_input.clear()
        self._route_summary.hide_summary()
        self._map.clear_all()

    # ── Nearby tab ─────────────────────────────────────────────────────────────

    def _on_nearby_location_selected(self, loc: dict) -> None:
        """Handle center location selection from the Nearby tab search input."""
        self._nearby_location_place = loc
        lat, lon = get_lat_lon(loc)
        if lat and lon:
            self._map.center(lat, lon, zoom=13)
            self._map.add_marker(lat, lon, loc.get("name", "Search Center"), "Center", "", 0, "main")

    def _clear_nearby_results_ui(self) -> None:
        while self._near_layout.count() > 1:
            item = self._near_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

    def _show_nearby_message(self, msg: str, is_error: bool = False, on_retry: callable | None = None) -> None:
        self._clear_nearby_results_ui()
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setContentsMargins(14, 16, 14, 16)
        layout.setSpacing(12)

        lbl = QLabel(msg)
        color = "#F87171" if is_error else "rgba(171,210,250,0.60)"
        lbl.setStyleSheet(f"color: {color}; font-size: 13px; font-weight: 500; background: transparent;")
        lbl.setWordWrap(True)
        layout.addWidget(lbl)

        if on_retry:
            btn_retry = QPushButton("↺ Retry")
            btn_retry.setCursor(Qt.PointingHandCursor)
            btn_retry.setFixedHeight(32)
            btn_retry.setStyleSheet("""
                QPushButton {
                    background: rgba(118, 146, 255, 0.15);
                    color: #93C5FD;
                    border: 1px solid rgba(118, 146, 255, 0.35);
                    border-radius: 7px;
                    padding: 0 16px;
                    font-size: 12px;
                    font-weight: 600;
                }
                QPushButton:hover {
                    background: rgba(118, 146, 255, 0.28);
                    color: #FFFFFF;
                }
                QPushButton:pressed {
                    background: rgba(118, 146, 255, 0.40);
                }
            """)
            btn_retry.clicked.connect(on_retry)
            layout.addWidget(btn_retry, alignment=Qt.AlignLeft)

        self._near_layout.insertWidget(0, container)

    def _on_nearby(self) -> None:
        """Execute real nearby search using selected location, category, and radius."""
        loc = self._nearby_location_place or self._selected_place
        loc_name = ""
        lat, lon = (0.0, 0.0)

        if loc:
            lat, lon = get_lat_lon(loc)
            loc_name = loc.get("name", "")

        location_text = ""
        if not lat or not lon:
            # Check if user typed into the nearby location search input without picking dropdown
            text = (self._nearby_location_input.text() if hasattr(self._nearby_location_input, "text") else "").strip()
            if text:
                location_text = text
            else:
                self._show_nearby_message("Please select or search for a location first.", is_error=True)
                return

        cat = self._cat_combo.currentText()
        radius_map = {"1 km": 1000, "2 km": 2000, "5 km": 5000, "10 km": 10000}
        radius_m = radius_map.get(self._radius_combo.currentText(), 5000)

        self._nearby_request_id += 1
        req_id = self._nearby_request_id

        self._near_spinner.start()
        self._clear_nearby_results_ui()

        worker = NearbyWorker(
            lat=lat,
            lon=lon,
            category=cat,
            radius=radius_m,
            request_id=req_id,
            loc_name=loc_name,
            location_text=location_text,
        )
        t = _run_in_thread(
            worker,
            slot=self._on_nearby_results,
            error_slot=self._on_nearby_error,
        )
        self._threads.append(t)

    def _on_nearby_results(self, data: object, *args) -> None:
        if isinstance(data, dict):
            req_id = data.get("request_id", 0)
            if req_id != self._nearby_request_id:
                return
            results = data.get("places", [])
            center_lat = data.get("lat", 0.0)
            center_lon = data.get("lon", 0.0)
            center_name = data.get("name", "Search Center")
        elif args:
            results = data
            center_lat = args[0] if len(args) > 0 else 0.0
            center_lon = args[1] if len(args) > 1 else 0.0
            center_name = args[2] if len(args) > 2 else "Search Center"
        else:
            results = data or []
            center_lat, center_lon, center_name = 0.0, 0.0, "Search Center"

        self._near_spinner.stop()
        self._clear_nearby_results_ui()
        self._map.clear_markers()

        if center_lat and center_lon:
            self._map.center(center_lat, center_lon, zoom=13)
            self._map.add_marker(center_lat, center_lon, center_name, "Center", "", 0, "main")

        if not results:
            self._show_nearby_message(
                "No nearby places found. Try expanding the search radius or choosing another category.",
                is_error=False,
                on_retry=self._on_nearby,
            )
            return

        # Header with result count and radius
        count_lbl = QLabel(f"Found {len(results)} {self._cat_combo.currentText().lower()} within {self._radius_combo.currentText()}:")
        count_lbl.setStyleSheet("color: rgba(171,210,250,0.50); font-size: 11px; font-weight: 600; padding: 4px 0;")
        self._near_layout.insertWidget(0, count_lbl)

        for p in results:
            card = PlaceCard(p)
            card.view_on_map.connect(
                lambda lat, lon, name, place=p: self._view_place_on_map(lat, lon, name, place)
            )
            card.route_to.connect(self._on_route_to_place)
            card.explore_nearby.connect(self._on_explore_nearby_card)
            card.favorited.connect(self._save_favorite)
            self._near_layout.insertWidget(self._near_layout.count() - 1, card)

            if p.get("lat") and p.get("lon"):
                self._map.add_marker(
                    p["lat"], p["lon"], p["name"],
                    p.get("category", ""), p.get("address", ""),
                    p.get("rating", 0), "place"
                )

    def _on_nearby_error(self, data: object, *args) -> None:
        if isinstance(data, dict):
            req_id = data.get("request_id", 0)
            if req_id != self._nearby_request_id:
                return
            msg = data.get("message", "Places couldn't be loaded right now.")
            can_retry = data.get("can_retry", True)
        else:
            msg = str(data)
            can_retry = True

        self._near_spinner.stop()
        self._clear_nearby_results_ui()
        self._show_nearby_message(
            msg,
            is_error=True,
            on_retry=self._on_nearby if can_retry else None,
        )

    def _view_place_on_map(self, lat: float, lon: float, name: str, place: dict | None = None) -> None:
        """Center and highlight place on the existing map."""
        if lat and lon:
            self._map.center(lat, lon, zoom=16)
            self._map.add_marker(lat, lon, name, place.get("category", "") if place else "", "", 0, "place")
            if place:
                self._show_place_info(place)

    def _on_route_to_place(self, place: dict) -> None:
        """Switch to Route tab and compute driving directions from center/origin to place."""
        if not place:
            return
        origin = self._nearby_location_place or self._selected_place
        if not origin:
            origin = {
                "name": "Current Location",
                "lat": self._origin_lat, "lon": self._origin_lon,
                "latitude": self._origin_lat, "longitude": self._origin_lon,
            }

        self._switch_tab(1)
        self._route_origin_place = origin
        self._route_origin_input.set_selected_location(origin)
        self._route_dest_place = place
        self._route_dest_input.set_selected_location(place)
        self._on_get_route()

    def _on_explore_nearby_card(self, place: dict) -> None:
        """Center the Nearby tab on this place and re-run search."""
        self._switch_tab(2)
        self._nearby_location_place = place
        self._nearby_location_input.set_selected_location(place)
        self._on_nearby()

    # ── Map click ─────────────────────────────────────────────────────────────

    def _on_map_click(self, lat: float, lon: float) -> None:
        self._selected_place = {
            "lat": lat, "lon": lon, "latitude": lat, "longitude": lon,
            "name": f"{lat:.4f}, {lon:.4f}",
        }
        self._nearby_location_place = self._selected_place
        if hasattr(self, "_nearby_location_input"):
            self._nearby_location_input.set_selected_location(self._selected_place)
        self._map.add_marker(lat, lon, "Selected", "Location", "", 0, "main")

    # ── Favorites ─────────────────────────────────────────────────────────────

    def _save_favorite(self, place: dict) -> None:
        favorites_repo.insert(place)
        logger.info("Saved favorite: %s", place.get("name"))

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _clear_results(self) -> None:
        while self._scroll_layout.count() > 1:
            item = self._scroll_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

    def _add_to_scroll(self, widget: QWidget) -> None:
        self._scroll_layout.insertWidget(self._scroll_layout.count() - 1, widget)

    def cleanup(self) -> None:
        if self._route_thread and self._route_thread.isRunning():
            self._route_thread.quit()
            if not self._route_thread.wait(200):
                self._route_thread.terminate()
                self._route_thread.wait(100)
        for t in list(self._threads):
            try:
                if t and t.isRunning():
                    t.quit()
                    if not t.wait(200):
                        t.terminate()
                        t.wait(100)
            except Exception:
                pass
        cleanup_active_threads()
        if hasattr(self, "_search") and hasattr(self._search, "cleanup"):
            self._search.cleanup()
        if hasattr(self, "_route_origin_input") and hasattr(self._route_origin_input, "cleanup"):
            self._route_origin_input.cleanup()
        if hasattr(self, "_route_dest_input") and hasattr(self._route_dest_input, "cleanup"):
            self._route_dest_input.cleanup()

    def closeEvent(self, event) -> None:
        self.cleanup()
        super().closeEvent(event)
