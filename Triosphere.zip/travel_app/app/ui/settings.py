"""
Settings screen — user profile, preferences, data management.
"""
from __future__ import annotations
import logging

from PySide6.QtCore    import Qt, Signal
from PySide6.QtWidgets import (
    QComboBox, QDoubleSpinBox, QFormLayout, QFrame, QGroupBox,
    QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QScrollArea, QVBoxLayout, QWidget, QMessageBox
)
from app.config import COLORS, FONT
from app.database.repositories import user_repo, cache_repo

logger = logging.getLogger(__name__)


class SettingsScreen(QWidget):
    settings_changed = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._build_ui()
        self._load_profile()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("background:transparent;border:none;")

        content = QWidget()
        content.setStyleSheet(f"background:{COLORS['bg_deep']};")
        c_layout = QVBoxLayout(content)
        c_layout.setContentsMargins(40, 36, 40, 36)
        c_layout.setSpacing(24)

        title = QLabel("Settings ⚙")
        title.setStyleSheet(f"color:{COLORS['text']};font-size:{FONT['2xl']};font-weight:900;background:transparent;")
        c_layout.addWidget(title)

        # ── Profile ────────────────────────────────────────────────────────────
        c_layout.addWidget(self._section("👤 Profile"))
        prof_card = self._card()
        pf = QFormLayout(); pf.setSpacing(12)
        self._name_input = QLineEdit(); self._name_input.setPlaceholderText("Your name")
        self._email_input = QLineEdit(); self._email_input.setPlaceholderText("your@email.com")
        self._home_city = QLineEdit(); self._home_city.setPlaceholderText("e.g. Mumbai")
        pf.addRow("Name", self._name_input)
        pf.addRow("Email", self._email_input)
        pf.addRow("Home City", self._home_city)
        prof_card.layout().addLayout(pf)
        c_layout.addWidget(prof_card)

        # ── Preferences ────────────────────────────────────────────────────────
        c_layout.addWidget(self._section("⚙ Preferences"))
        pref_card = self._card()
        pref_f = QFormLayout(); pref_f.setSpacing(12)
        self._currency = QComboBox()
        self._currency.addItems(["INR (₹)", "USD ($)", "EUR (€)", "GBP (£)", "JPY (¥)", "AED (د.إ)"])
        self._travel_mode = QComboBox()
        self._travel_mode.addItems(["driving", "walking", "cycling"])
        pref_f.addRow("Currency", self._currency)
        pref_f.addRow("Default Travel Mode", self._travel_mode)
        pref_card.layout().addLayout(pref_f)
        c_layout.addWidget(pref_card)

        # ── API configuration ─────────────────────────────────────────────────
        c_layout.addWidget(self._section("🔌 API Configuration"))
        api_card = self._card()
        api_f = QFormLayout(); api_f.setSpacing(12)
        self._ors_key = QLineEdit()
        self._ors_key.setPlaceholderText("Leave blank to use free OSRM routing")
        self._ors_key.setEchoMode(QLineEdit.Password)
        api_f.addRow("OpenRouteService API Key", self._ors_key)
        note = QLabel("ℹ️  All default APIs are free. ORS key is optional for enhanced routing.")
        note.setWordWrap(True)
        note.setStyleSheet(f"color:{COLORS['text_muted']};font-size:{FONT['sm']};background:transparent;")
        api_f.addRow("", note)
        api_card.layout().addLayout(api_f)
        c_layout.addWidget(api_card)

        # ── Data management ────────────────────────────────────────────────────
        c_layout.addWidget(self._section("🗄 Data Management"))
        data_card = self._card()
        dl = QVBoxLayout()
        dl.setSpacing(10)

        clear_cache_btn = self._action_btn("Clear Search Cache",
            f"background:{COLORS['warning_bg']};color:{COLORS['warning']};border:1px solid {COLORS['warning']};")
        clear_cache_btn.clicked.connect(self._clear_cache)
        dl.addWidget(clear_cache_btn)

        note2 = QLabel("Database: tripsphere.db  •  All data is stored locally on your machine.")
        note2.setStyleSheet(f"color:{COLORS['text_subtle']};font-size:{FONT['sm']};background:transparent;")
        dl.addWidget(note2)
        data_card.layout().addLayout(dl)
        c_layout.addWidget(data_card)

        # ── About ─────────────────────────────────────────────────────────────
        c_layout.addWidget(self._section("ℹ About"))
        about_card = self._card()
        about_card.layout().addWidget(QLabel(
            "TripSphere v1.0.0\n\nPersonal Travel Expense, Planner & Journal\n\n"
            "Built with PySide6 · SQLite · Leaflet · OpenStreetMap · OSRM\n"
            "All map data © OpenStreetMap contributors",
            styleSheet=f"color:{COLORS['text_muted']};font-size:{FONT['base']};line-height:1.7;background:transparent;"
        ))
        c_layout.addWidget(about_card)

        # Save button
        save_btn = QPushButton("Save Settings")
        save_btn.setMinimumHeight(46)
        save_btn.setStyleSheet(f"QPushButton{{background:{COLORS['accent']};color:#111111;border:none;border-radius:14px;padding:12px 36px;font-size:{FONT['base']};font-weight:800;}}QPushButton:hover{{background:{COLORS['accent_light']};}}")
        save_btn.clicked.connect(self._save)
        c_layout.addWidget(save_btn, alignment=Qt.AlignLeft)

        c_layout.addStretch()
        scroll.setWidget(content)
        layout.addWidget(scroll)

    def _section(self, title: str) -> QLabel:
        lbl = QLabel(title)
        lbl.setStyleSheet(f"color:{COLORS['text']};font-size:{FONT['lg']};font-weight:700;background:transparent;margin-top:8px;")
        return lbl

    def _card(self) -> QFrame:
        card = QFrame()
        card.setStyleSheet(f"QFrame{{background:{COLORS['bg_card']};border:1px solid {COLORS['border']};border-radius:14px;}}")
        layout = QVBoxLayout(card)
        layout.setContentsMargins(20, 18, 20, 18)
        layout.setSpacing(12)
        return card

    def _action_btn(self, text: str, style: str) -> QPushButton:
        btn = QPushButton(text)
        btn.setStyleSheet(f"QPushButton{{{style};border-radius:10px;padding:9px 20px;font-size:{FONT['base']};font-weight:600;}}QPushButton:hover{{opacity:0.8;}}")
        return btn

    def _load_profile(self) -> None:
        try:
            profile = user_repo.get_profile()
            self._name_input.setText(profile.get("name", ""))
            self._email_input.setText(profile.get("email", "") or "")
            self._home_city.setText(profile.get("home_city", "Mumbai") or "")
            # Currency
            currency_map = {"INR": 0, "USD": 1, "EUR": 2, "GBP": 3, "JPY": 4, "AED": 5}
            idx = currency_map.get(profile.get("currency", "INR"), 0)
            self._currency.setCurrentIndex(idx)
            # Travel mode
            mode_map = {"driving": 0, "walking": 1, "cycling": 2}
            midx = mode_map.get(profile.get("travel_mode", "driving"), 0)
            self._travel_mode.setCurrentIndex(midx)
        except Exception as exc:
            logger.error("Failed to load profile: %s", exc)

    def _save(self) -> None:
        try:
            currency_text = self._currency.currentText()
            code = currency_text.split("(")[0].strip()
            sym  = currency_text.split("(")[1].rstrip(")").strip() if "(" in currency_text else "₹"
            user_repo.update_profile({
                "name":         self._name_input.text().strip() or "Traveller",
                "email":        self._email_input.text().strip() or None,
                "home_city":    self._home_city.text().strip() or "Mumbai",
                "home_lat":     19.0760,
                "home_lon":     72.8777,
                "currency":     code,
                "currency_sym": sym,
                "travel_mode":  self._travel_mode.currentText(),
                "theme":        "dark",
            })
            QMessageBox.information(self, "Saved", "Settings saved successfully!")
            self.settings_changed.emit()
        except Exception as exc:
            logger.error("Failed to save settings: %s", exc)
            QMessageBox.warning(self, "Error", f"Failed to save settings: {exc}")

    def _clear_cache(self) -> None:
        cache_repo.clear()
        QMessageBox.information(self, "Cache Cleared", "Search cache has been cleared.")
