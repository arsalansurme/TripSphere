"""
Main application window — orchestrates sidebar, page stack, and startup flow.
Warm dark cinema aesthetic with smooth page transitions.
"""
from __future__ import annotations
import logging

from PySide6.QtCore    import Qt, QSize, Signal, QPropertyAnimation, QEasingCurve, QObject, QThread
from PySide6.QtGui     import QColor, QIcon
from PySide6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QMainWindow,
    QStackedWidget, QStatusBar, QVBoxLayout, QWidget, QGraphicsOpacityEffect
)

from app.config import COLORS, FONT, APP_NAME, get_app_stylesheet
from app.ui.widgets.sidebar import Sidebar
from app.database.repositories import user_repo
from app import session

logger = logging.getLogger(__name__)


class HomeGeocodeWorker(QObject):
    finished = Signal(object)

    def __init__(self, query: str):
        super().__init__()
        self.query = query

    def run(self):
        try:
            from app.api.geocoding import geocoding_service
            self.finished.emit(geocoding_service.geocode(self.query))
        except Exception as exc:
            logger.error("[API error] Home geocode failed: %s", exc)
            self.finished.emit(None)


class MainWindow(QMainWindow):
    """
    Root application window.
    """

    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} — Personal Travel Planner & Journal")
        self.setMinimumSize(1280, 760)
        self.resize(1440, 900)

        self._pages: dict[str, QWidget] = {}
        self._home_geocode_thread: QThread | None = None
        self._build_ui()
        self._connect_signals()

    def _build_ui(self) -> None:
        central = QWidget()
        central.setStyleSheet(f"background: {COLORS['bg_deep']};")
        self.setCentralWidget(central)

        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # Sidebar
        self._sidebar = Sidebar()
        self._sidebar.nav_clicked.connect(self._navigate)
        self._sidebar.switch_account_clicked.connect(self._open_account_switcher)
        self._refresh_sidebar_profile()
        root.addWidget(self._sidebar)

        # Page stack
        self._stack = QStackedWidget()
        self._stack.setStyleSheet(f"background: {COLORS['bg_deep']};")
        root.addWidget(self._stack, 1)

        # Status bar
        self._status = QStatusBar()
        self.setStatusBar(self._status)
        self._status.setStyleSheet(
            f"background: {COLORS['sidebar_bg']}; color: {COLORS['text_subtle']}; "
            f"font-size: {FONT['xs']}; border-top: 1px solid {COLORS['border']};"
        )
        self._offline_indicator = QLabel("  📡 Offline  ")
        self._offline_indicator.setStyleSheet(
            f"color: {COLORS['warning']}; font-size: {FONT['xs']}; font-weight: 700; "
            f"background: {COLORS['warning_bg']}; border-radius: 6px; padding: 2px 8px;"
        )
        self._offline_indicator.hide()
        self._status.addPermanentWidget(self._offline_indicator)
        self._status.showMessage("Ready", 3000)

        # Start on globe or home
        self._navigate("globe")

    def _connect_signals(self) -> None:
        pass

    def _navigate(self, key: str) -> None:
        if key == "globe":
            self._sidebar.hide()
            self._status.hide()
        else:
            self._sidebar.show()
            self._status.show()

        page = self._get_page(key)
        if page is None:
            logger.warning("Unknown page: %s", key)
            return

        if key == "globe" and hasattr(page, "reset_globe"):
            page.reset_globe()

        if hasattr(page, "refresh"):
            try:
                page.refresh()
            except Exception as exc:
                logger.error("Refresh failed for %s: %s", key, exc)

        self._stack.setCurrentWidget(page)

        self._sidebar.set_active_page(key)
        self._status.showMessage(f"  {key.capitalize()}", 2000)

    def _get_page(self, key: str) -> QWidget | None:
        if key in self._pages:
            return self._pages[key]

        page = self._create_page(key)
        if page is None:
            return None

        self._stack.addWidget(page)
        self._pages[key] = page
        return page

    def _create_page(self, key: str) -> QWidget | None:
        try:
            if key == "globe":
                from app.ui.startup import StartupScreen
                w = StartupScreen(self._stack)
                w.ready.connect(self.handle_startup_search)
                w.skip.connect(lambda: self._navigate("home"))
                return w

            elif key == "home":
                from app.ui.dashboard import DashboardScreen
                w = DashboardScreen()
                w.navigate.connect(self._navigate)
                w.open_trip.connect(self._open_trip_detail)
                w.explore_location.connect(self._explore_location)
                w.search_requested.connect(self._on_home_search_requested)
                return w

            elif key == "explore":
                from app.ui.explore import ExploreScreen
                return ExploreScreen()

            elif key == "places":
                from app.ui.explore import ExploreScreen
                return ExploreScreen()

            elif key == "trips":
                from app.ui.trips import TripsScreen
                w = TripsScreen()
                w.trip_selected.connect(lambda tid: self._open_trip_detail(tid))
                return w

            elif key == "expenses":
                from app.ui.expenses import ExpensesScreen
                return ExpensesScreen()

            elif key == "budget":
                from app.ui.budget import BudgetScreen
                return BudgetScreen()

            elif key == "journal":
                from app.ui.journal import JournalScreen
                return JournalScreen()

            elif key == "favorites":
                from app.ui.favorites import FavoritesScreen
                w = FavoritesScreen()
                w.navigate_map.connect(lambda lat, lon, name: self._explore_location(lat, lon, name))
                return w

            elif key == "random":
                from app.ui.random_dest import RandomDestinationScreen
                w = RandomDestinationScreen()
                w.explore.connect(self._explore_dest)
                w.add_to_trip.connect(lambda d: self._navigate("trips"))
                return w

            elif key == "chat":
                from app.ui.chat import ChatScreen
                return ChatScreen()

            elif key == "settings":
                from app.ui.settings import SettingsScreen
                w = SettingsScreen()
                w.settings_changed.connect(self._on_settings_changed)
                return w

        except Exception as exc:
            logger.error("Failed to create page '%s': %s", key, exc, exc_info=True)
            error_widget = QLabel(
                f"⚠️  Failed to load {key} screen.\n{exc}",
                alignment=Qt.AlignCenter,
            )
            error_widget.setStyleSheet(
                f"color: {COLORS['danger']}; font-size: {FONT['lg']}; padding: 40px;"
            )
            return error_widget

        return None

    def _open_trip_detail(self, trip_id: int) -> None:
        key = f"trip_detail_{trip_id}"
        if key not in self._pages:
            try:
                from app.ui.trip_detail import TripDetailScreen
                w = TripDetailScreen(trip_id)
                w.back_clicked.connect(lambda: self._close_trip_detail(key))
                self._stack.addWidget(w)
                self._pages[key] = w
            except Exception as exc:
                logger.error("Failed to open trip detail: %s", exc)
                return
        self._stack.setCurrentWidget(self._pages[key])

    def _close_trip_detail(self, key: str) -> None:
        if key in self._pages:
            widget = self._pages.pop(key)
            if hasattr(widget, "cleanup"):
                try:
                    widget.cleanup()
                except Exception as exc:
                    logger.warning("Cleanup error on %s: %s", key, exc)
            self._stack.removeWidget(widget)
            widget.deleteLater()
        if "trips" in self._pages:
            self._pages["trips"].refresh()
        self._navigate("trips")

    def _explore_location(self, lat: float, lon: float, name: str) -> None:
        self._navigate("explore")
        explore = self._pages.get("explore")
        if explore and hasattr(explore, "go_to"):
            explore.go_to(name, lat, lon)

    def _on_home_search_requested(self, query: str) -> None:
        """Navigate to Explore and geocode the query to center the map."""
        self._navigate("explore")
        explore = self._pages.get("explore")
        if not explore:
            return
        logger.info("[action started] Home search: %s", query)
        if self._home_geocode_thread and self._home_geocode_thread.isRunning():
            self._home_geocode_thread.quit()
            self._home_geocode_thread.wait(300)

        worker = HomeGeocodeWorker(query)
        thread = QThread(self)
        thread._worker = worker
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.finished.connect(lambda result: self._on_home_geocode_result(query, result))
        worker.finished.connect(thread.quit)
        worker.finished.connect(worker.deleteLater)
        thread.finished.connect(thread.deleteLater)
        thread.finished.connect(lambda: setattr(self, "_home_geocode_thread", None))
        self._home_geocode_thread = thread
        thread.start()

    def _on_home_geocode_result(self, query: str, result) -> None:
        logger.info("[action completed] Home search: %s", query)
        explore = self._pages.get("explore")
        if result and explore:
            lat = float(result.get("lat", 0))
            lon = float(result.get("lon", 0))
            if lat and lon:
                explore.go_to(result.get("name", query), lat, lon)
                return
        if explore and hasattr(explore, "_on_search"):
            explore._on_search(query)

    def _explore_dest(self, dest: dict) -> None:
        self._navigate("explore")
        explore = self._pages.get("explore")
        if explore and hasattr(explore, "go_to"):
            explore.go_to(dest.get("name", ""), dest.get("lat", 0), dest.get("lon", 0))

    def _on_settings_changed(self) -> None:
        if "home" in self._pages:
            self._pages["home"].refresh()
        self._refresh_sidebar_profile()

    def _refresh_sidebar_profile(self) -> None:
        try:
            profile = user_repo.get_profile()
            self._sidebar.set_user_name(profile.get("name") or "Traveller")
        except Exception as exc:
            logger.error("Failed to load active profile: %s", exc)

    def _open_account_switcher(self) -> None:
        from app.ui.widgets.account_switcher import AccountSwitcherDialog
        dlg = AccountSwitcherDialog(session.get_current_user_id(), self)
        if dlg.exec() == dlg.DialogCode.Accepted:
            picked = dlg.picked_user_id()
            if picked is not None and picked != session.get_current_user_id():
                self._switch_account(picked)

    def _switch_account(self, user_id: int) -> None:
        session.set_current_user_id(user_id)

        # Every cached page was built with the previous profile's data —
        # drop them all so the next visit rebuilds fresh from the DB.
        for key, widget in list(self._pages.items()):
            self._stack.removeWidget(widget)
            widget.deleteLater()
        self._pages.clear()

        self._refresh_sidebar_profile()
        self._navigate("home")

    def handle_startup_search(self, query: str, lat: float, lon: float) -> None:
        self.show()
        self.raise_()
        self.activateWindow()
        self._navigate("explore")
        from PySide6.QtCore import QTimer
        QTimer.singleShot(500, lambda: self._explore_location(lat, lon, query))

    def show_offline_indicator(self, offline: bool) -> None:
        self._offline_indicator.setVisible(offline)

    def refresh_all(self) -> None:
        for key, page in self._pages.items():
            if hasattr(page, "refresh"):
                try:
                    page.refresh()
                except Exception as exc:
                    logger.error("Refresh failed for %s: %s", key, exc)

    def closeEvent(self, event) -> None:
        if self._home_geocode_thread and self._home_geocode_thread.isRunning():
            self._home_geocode_thread.quit()
            self._home_geocode_thread.wait(300)
        for page in list(self._pages.values()):
            if hasattr(page, "cleanup"):
                try:
                    page.cleanup()
                except Exception:
                    pass
        super().closeEvent(event)
