"""
Matplotlib chart widgets embedded inside Qt frames.
All charts are styled to match the TripSphere warm dark cinema theme.
"""
from __future__ import annotations

from typing import Optional
import matplotlib
matplotlib.use("QtAgg")

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from matplotlib.figure import Figure
from PySide6.QtWidgets import QFrame, QVBoxLayout, QWidget, QLabel
from PySide6.QtCore import Qt

from app.config import COLORS

_BG_CARD = "#171717"
_TEXT    = "#F5F5F5"
_MUTED   = "#A1A1AA"
_ACCENT  = "#D4A96A"
_ALT     = "#E8D5B0"
_BORDER  = "rgba(255,255,255,0.07)"

CATEGORY_COLORS = {
    "Transport":       "#7B9EA3",
    "Accommodation":   "#C46E7B",
    "Food":            "#E8834A",
    "Activities":      "#6CA877",
    "Shopping":        "#A882C4",
    "Fuel":            "#D4B84A",
    "Local Transport": "#5C9EBF",
    "Other":           "#71717A",
}


def _apply_dark_theme(fig: Figure, ax) -> None:
    """Apply TripSphere warm dark theme to any matplotlib axes."""
    fig.patch.set_facecolor(_BG_CARD)
    ax.set_facecolor(_BG_CARD)
    ax.tick_params(colors=_MUTED, labelsize=9)
    for spine in ax.spines.values():
        spine.set_edgecolor("#222222")
    ax.xaxis.label.set_color(_MUTED)
    ax.yaxis.label.set_color(_MUTED)
    ax.title.set_color(_TEXT)


class ChartCard(QFrame):
    """Base card that hosts a matplotlib canvas."""

    def __init__(self, title: str = "", parent: QWidget | None = None):
        super().__init__(parent)
        self.setStyleSheet(f"""
            QFrame {{
                background: {COLORS['bg_card']};
                border: 1px solid {COLORS['border']};
                border-radius: 20px;
                padding: 4px;
            }}
        """)
        self._layout = QVBoxLayout(self)
        self._layout.setContentsMargins(20, 18, 20, 20)
        self._layout.setSpacing(12)

        if title:
            t = QLabel(title)
            t.setStyleSheet(
                f"color: {COLORS['text']}; font-size: 16px; font-weight: 700; background: transparent;"
            )
            self._layout.addWidget(t)

    def _add_canvas(self, fig: Figure) -> FigureCanvasQTAgg:
        canvas = FigureCanvasQTAgg(fig)
        canvas.setStyleSheet("background: transparent;")
        self._layout.addWidget(canvas)
        return canvas


class DonutChart(ChartCard):
    """Expense distribution donut chart."""

    def __init__(self, data: dict[str, float], title: str = "Expense Breakdown",
                 currency_sym: str = "₹", parent: QWidget | None = None):
        super().__init__(title, parent)
        if not data:
            self._layout.addWidget(QLabel("No expense data available"))
            return

        fig = Figure(figsize=(4, 3), dpi=100)
        ax  = fig.add_subplot(111)
        _apply_dark_theme(fig, ax)

        labels = list(data.keys())
        sizes  = list(data.values())
        colors = [CATEGORY_COLORS.get(l, "#71717A") for l in labels]

        wedges, texts, autotexts = ax.pie(
            sizes,
            labels=None,
            autopct="%1.0f%%",
            colors=colors,
            startangle=140,
            wedgeprops=dict(width=0.52, edgecolor=_BG_CARD, linewidth=2),
            pctdistance=0.75,
        )
        for at in autotexts:
            at.set_color(_TEXT)
            at.set_fontsize(8)

        ax.axis("equal")

        # Legend below
        legend = ax.legend(
            wedges, [f"{l} ({currency_sym}{v:,.0f})" for l, v in zip(labels, sizes)],
            loc="lower center", bbox_to_anchor=(0.5, -0.25),
            ncol=2, fontsize=8, frameon=False, labelcolor=_MUTED,
        )

        fig.tight_layout(pad=1.0)
        self._add_canvas(fig)


class BarChart(ChartCard):
    """Category spending bar chart."""

    def __init__(self, data: dict[str, float], title: str = "Spending by Category",
                 currency_sym: str = "₹", parent: QWidget | None = None):
        super().__init__(title, parent)
        if not data:
            self._layout.addWidget(QLabel("No expense data available"))
            return

        fig = Figure(figsize=(4.5, 3), dpi=100)
        ax  = fig.add_subplot(111)
        _apply_dark_theme(fig, ax)

        categories = list(data.keys())
        amounts    = list(data.values())
        colors     = [CATEGORY_COLORS.get(c, "#71717A") for c in categories]

        bars = ax.barh(categories, amounts, color=colors, height=0.55,
                       edgecolor="none", alpha=0.9)

        for bar, amt in zip(bars, amounts):
            ax.text(
                bar.get_width() + max(amounts) * 0.02,
                bar.get_y() + bar.get_height() / 2,
                f"{currency_sym}{amt:,.0f}",
                va="center", ha="left", color=_MUTED, fontsize=8,
            )

        ax.set_xlabel("Amount", color=_MUTED, fontsize=9)
        ax.invert_yaxis()
        ax.set_xlim(0, max(amounts) * 1.25 if amounts else 1)
        ax.grid(axis="x", color="white", linewidth=0.5, alpha=0.06)
        ax.tick_params(axis="y", labelsize=9)

        fig.tight_layout(pad=1.0)
        self._add_canvas(fig)


class LineChart(ChartCard):
    """Daily spending line chart."""

    def __init__(self, daily_data: list[dict], title: str = "Daily Spending",
                 currency_sym: str = "₹", parent: QWidget | None = None):
        super().__init__(title, parent)
        if not daily_data:
            self._layout.addWidget(QLabel("No daily data available"))
            return

        dates   = [d["date"][-5:] for d in daily_data]   # MM-DD
        amounts = [d["total"] for d in daily_data]

        fig = Figure(figsize=(4.5, 3), dpi=100)
        ax  = fig.add_subplot(111)
        _apply_dark_theme(fig, ax)

        x = range(len(dates))
        ax.fill_between(x, amounts, color=_ACCENT, alpha=0.15)
        ax.plot(x, amounts, color=_ACCENT, linewidth=2.5, marker="o",
                markersize=5, markerfacecolor=_ALT, markeredgecolor=_ACCENT)

        ax.set_xticks(list(x))
        ax.set_xticklabels(dates, rotation=30, ha="right", fontsize=8)
        ax.set_ylabel(f"Amount ({currency_sym})", color=_MUTED, fontsize=9)
        ax.grid(axis="y", color="white", linewidth=0.5, alpha=0.06)
        ax.set_xlim(-0.5, len(dates) - 0.5)

        fig.tight_layout(pad=1.0)
        self._add_canvas(fig)


class BudgetGaugeChart(ChartCard):
    """Circular budget gauge / progress ring."""

    def __init__(self, pct: float, spent: float, budget: float,
                 currency_sym: str = "₹", title: str = "Budget Used",
                 parent: QWidget | None = None):
        super().__init__(title, parent)
        pct = min(pct, 100)

        fig = Figure(figsize=(3, 3), dpi=100)
        ax  = fig.add_subplot(111)
        _apply_dark_theme(fig, ax)

        fill_color = _ACCENT if pct < 80 else ("#FBBF24" if pct < 100 else "#F87171")

        # Background ring
        ring_bg = mpatches.Wedge(
            (0.5, 0.5), 0.45, 0, 360,
            width=0.12, facecolor="#222222", edgecolor="none",
            transform=ax.transAxes
        )
        ax.add_patch(ring_bg)

        if pct > 0:
            fill_ring = mpatches.Wedge(
                (0.5, 0.5), 0.45, 90, 90 - (pct/100 * 360),
                width=0.12, facecolor=fill_color, edgecolor="none",
                transform=ax.transAxes
            )
            ax.add_patch(fill_ring)

        ax.text(0.5, 0.54, f"{pct:.0f}%", ha="center", va="center",
                fontsize=24, fontweight="bold", color=_TEXT, transform=ax.transAxes)
        ax.text(0.5, 0.36, f"spent", ha="center", va="center",
                fontsize=9, color=_MUTED, transform=ax.transAxes)

        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.axis("off")
        fig.tight_layout(pad=0.2)
        self._add_canvas(fig)

        # Text summary below chart
        summary = QLabel(
            f"Spent: {currency_sym}{spent:,.0f}  /  Budget: {currency_sym}{budget:,.0f}\n"
            f"Remaining: {currency_sym}{max(budget - spent, 0):,.0f}"
        )
        summary.setAlignment(Qt.AlignCenter)
        summary.setStyleSheet(
            f"color: {COLORS['text_muted']}; font-size: 13px; background: transparent; line-height: 1.6;"
        )
        self._layout.addWidget(summary)
