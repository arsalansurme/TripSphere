"""
Reusable card components for TripSphere.
All cards use native QSS hover states without runtime setStyleSheet calls.
"""
from __future__ import annotations

from PySide6.QtCore    import Qt, Signal
from PySide6.QtGui     import QColor, QCursor
from PySide6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QPushButton,
    QSizePolicy, QVBoxLayout, QWidget, QGraphicsDropShadowEffect
)
from app.config import COLORS, FONT, DEFAULT_CURRENCY


class GlassCard(QFrame):
    """Base card with native QSS hover state."""

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setStyleSheet(f"""
            GlassCard {{
                background: {COLORS['bg_card']};
                border: none;
                border-radius: 20px;
            }}
            GlassCard:hover {{
                background: {COLORS['bg_elevated']};
            }}
        """)


# ── Trip Card ─────────────────────────────────────────────────────────────────

class TripCard(GlassCard):
    """Trip summary card matching the design mockup layout."""

    clicked = Signal(int)  # trip_id

    def __init__(self, trip: dict, parent: QWidget | None = None):
        super().__init__(parent)
        self._trip_id = trip.get("id", -1)
        self.setCursor(QCursor(Qt.PointingHandCursor))
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.setFixedHeight(180)

        self.setStyleSheet(f"""
            TripCard {{
                background: #121216;
                border-radius: 24px;
                border: none;
            }}
            TripCard:hover {{
                background: #17171E;
            }}
        """)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(14, 14, 20, 14)
        layout.setSpacing(20)

        # ── Left Preview Image / Badge Container ────────────────────────────
        left_box = QFrame()
        left_box.setFixedSize(260, 152)
        left_box.setStyleSheet("""
            QFrame {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #1E1B2E, stop:1 #11101D);
                border-radius: 18px;
                border: none;
            }
        """)
        left_layout = QVBoxLayout(left_box)
        left_layout.setContentsMargins(14, 14, 14, 14)

        icon_lbl = QLabel("🖼")
        icon_lbl.setAlignment(Qt.AlignCenter)
        icon_lbl.setStyleSheet("font-size: 32px; color: rgba(255,255,255,0.25); background: transparent;")
        left_layout.addStretch()
        left_layout.addWidget(icon_lbl)
        left_layout.addStretch()

        badge_txt = trip.get("category", "BEACH ESCAPE").upper()
        badge_lbl = QLabel(badge_txt)
        badge_lbl.setStyleSheet(f"""
            color: {COLORS['sand']};
            font-size: 10px;
            font-weight: 800;
            letter-spacing: 1px;
            background: rgba(0, 0, 0, 0.45);
            border-radius: 12px;
            padding: 5px 12px;
            border: none;
        """)
        badge_row = QHBoxLayout()
        badge_row.setContentsMargins(0, 0, 0, 0)
        badge_row.addWidget(badge_lbl)
        badge_row.addStretch()
        left_layout.addLayout(badge_row)

        layout.addWidget(left_box)

        # ── Right Details Container ──────────────────────────────────────────
        right_layout = QVBoxLayout()
        right_layout.setContentsMargins(0, 8, 0, 8)
        right_layout.setSpacing(8)

        # Header with title & circular arrow button
        hdr_row = QHBoxLayout()
        title_lbl = QLabel(trip.get("name", "Goa Adventure 2026"))
        title_lbl.setStyleSheet(f"color: {COLORS['text']}; font-size: 18px; font-weight: 700; background: transparent;")
        hdr_row.addWidget(title_lbl, 1)

        arrow_btn = QPushButton("→")
        arrow_btn.setFixedSize(36, 36)
        arrow_btn.setStyleSheet(f"""
            QPushButton {{
                background: rgba(255,255,255,0.06);
                color: {COLORS['text']};
                border-radius: 18px;
                font-size: 16px;
                font-weight: 600;
                border: none;
            }}
            QPushButton:hover {{
                background: {COLORS['accent']};
                color: #111111;
            }}
        """)
        arrow_btn.clicked.connect(lambda: self.clicked.emit(self._trip_id))
        hdr_row.addWidget(arrow_btn)
        right_layout.addLayout(hdr_row)

        # Dates & Duration
        dest = trip.get("destination") or "Destination"
        date_str = ""
        if trip.get("start_date"):
            date_str = trip["start_date"]
            if trip.get("end_date"):
                date_str += f" — {trip['end_date']}"

        meta_txt = f"⏱  {date_str}" if date_str else f"📍  {dest}"
        meta_lbl = QLabel(meta_txt)
        meta_lbl.setStyleSheet(f"color: {COLORS['text_muted']}; font-size: 13px; background: transparent;")
        right_layout.addWidget(meta_lbl)

        right_layout.addStretch()

        # Budget Progress
        budget = trip.get("budget", 30000) or 30000
        spent = trip.get("spent", 18400) or 18400
        sym = trip.get("currency_sym", DEFAULT_CURRENCY)
        pct = min((spent / budget * 100) if budget > 0 else 0, 100)

        b_hdr = QHBoxLayout()
        b_lbl = QLabel("BUDGET PROGRESS")
        b_lbl.setStyleSheet(f"color: {COLORS['text_subtle']}; font-size: 10px; font-weight: 800; letter-spacing: 1px; background: transparent;")
        b_hdr.addWidget(b_lbl)
        b_hdr.addStretch()

        b_val = QLabel(f"{sym}{spent/1000:.1f}k / {sym}{budget/1000:.0f}k")
        b_val.setStyleSheet(f"color: {COLORS['sand']}; font-size: 12px; font-weight: 700; background: transparent;")
        b_hdr.addWidget(b_val)
        right_layout.addLayout(b_hdr)

        # Progress bar
        prog_bar = QFrame()
        prog_bar.setFixedHeight(8)
        prog_bar.setStyleSheet("background: rgba(255,255,255,0.08); border-radius: 4px; border: none;")

        if pct > 0:
            fill = QFrame(prog_bar)
            fill.setFixedHeight(8)
            fill.setStyleSheet(f"""
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 {COLORS['accent_dim']}, stop:1 {COLORS['accent_light']});
                border-radius: 4px;
                border: none;
            """)
            prog_bar.resizeEvent = lambda e, f=fill, p=pct: f.setFixedWidth(
                max(8, int(prog_bar.width() * p / 100))
            )

        right_layout.addWidget(prog_bar)

        layout.addLayout(right_layout, 1)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.clicked.emit(self._trip_id)
        super().mousePressEvent(event)



# ── Place Card ────────────────────────────────────────────────────────────────

class PlaceCard(GlassCard):
    """Card for a place/POI with name, category, rating and action buttons."""

    view_on_map    = Signal(float, float, str)
    add_to_trip    = Signal(dict)
    favorited      = Signal(dict)
    route_to       = Signal(dict)
    explore_nearby = Signal(dict)

    def __init__(self, place: dict, parent: QWidget | None = None):
        super().__init__(parent)
        self._place = place
        self.setStyleSheet(f"""
            PlaceCard {{
                background: {COLORS['bg_card']};
                border: none;
                border-radius: 20px;
            }}
            PlaceCard:hover {{
                background: {COLORS['bg_elevated']};
            }}
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 16, 18, 16)
        layout.setSpacing(10)

        # Header
        hdr = QHBoxLayout()
        name = QLabel(place.get("name", "Unknown"))
        name.setStyleSheet(
            f"color: {COLORS['text']}; font-size: {FONT['base']}; font-weight: 700; background: transparent; border: none;"
        )
        name.setWordWrap(True)
        hdr.addWidget(name, 1)

        cat = place.get("category", "")
        if cat:
            cat_lbl = QLabel(cat.upper())
            cat_lbl.setStyleSheet(
                f"color: {COLORS['accent']}; font-size: 10px; font-weight: 700; "
                f"border-radius: 6px; padding: 3px 8px; border: none; "
                f"letter-spacing: 0.5px; background: rgba(255,255,255,0.06);"
            )
            hdr.addWidget(cat_lbl)
        layout.addLayout(hdr)

        # Rating
        rating = place.get("rating", 0)
        if rating:
            r_lbl = QLabel(f"★ {rating:.1f} / 5")
            r_lbl.setStyleSheet(f"color: {COLORS['warning']}; font-size: {FONT['sm']}; background: transparent; font-weight: 600; border: none;")
            layout.addWidget(r_lbl)

        # Description
        desc = place.get("description", "")
        if desc:
            d_lbl = QLabel(desc[:120] + ("…" if len(desc) > 120 else ""))
            d_lbl.setWordWrap(True)
            d_lbl.setStyleSheet(f"color: {COLORS['text_muted']}; font-size: {FONT['sm']}; background: transparent; border: none;")
            layout.addWidget(d_lbl)

        # Actions — 2 rows to avoid overflow in the narrow panel
        act_row1 = QHBoxLayout()
        act_row1.setSpacing(6)

        map_btn = QPushButton("📍 Locate")
        map_btn.setFixedHeight(30)
        map_btn.setStyleSheet(f"QPushButton{{background:rgba(255,255,255,0.07);color:{COLORS['sand']};border:none;border-radius:8px;padding:0 10px;font-size:11px;font-weight:600;}}QPushButton:hover{{background:rgba(255,255,255,0.14);}}")
        map_btn.clicked.connect(lambda: self.view_on_map.emit(
            place.get("lat", 0), place.get("lon", 0), place.get("name", "")
        ))
        act_row1.addWidget(map_btn)

        fav_btn = QPushButton("♡ Save")
        fav_btn.setFixedHeight(30)
        fav_btn.setStyleSheet(f"QPushButton{{background:rgba(255,255,255,0.07);color:{COLORS['coral']};border:none;border-radius:8px;padding:0 10px;font-size:11px;font-weight:600;}}QPushButton:hover{{background:rgba(255,255,255,0.14);}}")
        fav_btn.clicked.connect(lambda: self.favorited.emit(place))
        act_row1.addWidget(fav_btn)

        trip_btn = QPushButton("+ Plan")
        trip_btn.setFixedHeight(30)
        trip_btn.setStyleSheet(f"QPushButton{{background:{COLORS['accent']};color:#111;border:none;border-radius:8px;padding:0 10px;font-size:11px;font-weight:700;}}QPushButton:hover{{background:{COLORS['accent_light']};}}")
        trip_btn.clicked.connect(lambda: self.add_to_trip.emit(place))
        act_row1.addWidget(trip_btn)
        act_row1.addStretch()
        layout.addLayout(act_row1)

        act_row2 = QHBoxLayout()
        act_row2.setSpacing(6)

        route_btn = QPushButton("🗺 Route")
        route_btn.setFixedHeight(30)
        route_btn.setStyleSheet(f"QPushButton{{background:rgba(255,255,255,0.07);color:{COLORS['accent']};border:none;border-radius:8px;padding:0 10px;font-size:11px;font-weight:600;}}QPushButton:hover{{background:rgba(255,255,255,0.14);}}")
        route_btn.clicked.connect(lambda: self.route_to.emit(place))
        act_row2.addWidget(route_btn)

        near_btn = QPushButton("🔍 Nearby")
        near_btn.setFixedHeight(30)
        near_btn.setStyleSheet(f"QPushButton{{background:rgba(255,255,255,0.07);color:{COLORS['sand']};border:none;border-radius:8px;padding:0 10px;font-size:11px;font-weight:600;}}QPushButton:hover{{background:rgba(255,255,255,0.14);}}")
        near_btn.clicked.connect(lambda: self.explore_nearby.emit(place))
        act_row2.addWidget(near_btn)
        act_row2.addStretch()
        layout.addLayout(act_row2)



# ── Expense Card ──────────────────────────────────────────────────────────────

class ExpenseCard(GlassCard):
    """Single expense line item card."""

    delete_requested = Signal(int)

    def __init__(self, expense: dict, parent: QWidget | None = None):
        super().__init__(parent)
        self._id = expense.get("id", -1)
        self.setStyleSheet(f"""
            ExpenseCard {{
                background: {COLORS['bg_card']};
                border: none;
                border-radius: 16px;
            }}
            ExpenseCard:hover {{
                background: {COLORS['bg_elevated']};
            }}
        """)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(18, 14, 18, 14)
        layout.setSpacing(14)

        from app.config import EXPENSE_CATEGORY_ICONS

        cat = expense.get("category", "")
        icon = EXPENSE_CATEGORY_ICONS.get(cat, "•")
        icon_lbl = QLabel(icon)
        icon_lbl.setFixedSize(36, 36)
        icon_lbl.setAlignment(Qt.AlignCenter)
        icon_lbl.setStyleSheet(f"""
            font-size: 16px;
            color: {COLORS['accent']};
            background: rgba(255,255,255,0.06);
            border-radius: 10px;
            border: none;
        """)
        layout.addWidget(icon_lbl)

        info = QVBoxLayout()
        info.setSpacing(3)
        desc = expense.get("description") or cat or "Expense"
        desc_lbl = QLabel(desc)
        desc_lbl.setStyleSheet(f"color: {COLORS['text']}; font-size: {FONT['base']}; font-weight: 600; background: transparent; border: none;")
        info.addWidget(desc_lbl)

        meta = f"{cat}  •  {expense.get('date', '')}"
        meta_lbl = QLabel(meta)
        meta_lbl.setStyleSheet(f"color: {COLORS['text_subtle']}; font-size: {FONT['sm']}; background: transparent; border: none;")
        info.addWidget(meta_lbl)
        layout.addLayout(info, 1)

        sym    = expense.get("currency_sym", DEFAULT_CURRENCY)
        amount = expense.get("amount", 0)
        amt_lbl = QLabel(f"{sym}{amount:,.2f}")
        amt_lbl.setStyleSheet(f"color: {COLORS['sand']}; font-size: {FONT['md']}; font-weight: 700; background: transparent; border: none;")
        layout.addWidget(amt_lbl)

        del_btn = QPushButton("✕")
        del_btn.setFixedSize(28, 28)
        del_btn.setStyleSheet(f"""
            QPushButton {{ background: rgba(248, 113, 113, 0.10); color: {COLORS['danger']};
                border: none; border-radius: 8px; font-size: 12px; font-weight: 600; }}
            QPushButton:hover {{ background: {COLORS['danger']}; color: #fff; }}
        """)
        del_btn.clicked.connect(lambda: self.delete_requested.emit(self._id))
        layout.addWidget(del_btn)


# ── Journal Card ──────────────────────────────────────────────────────────────

class JournalCard(GlassCard):
    """Journal entry preview card."""

    clicked = Signal(int)  # entry_id

    def __init__(self, entry: dict, parent: QWidget | None = None):
        super().__init__(parent)
        self._id = entry.get("id", -1)
        self.setCursor(QCursor(Qt.PointingHandCursor))
        self.setStyleSheet(f"""
            JournalCard {{
                background: {COLORS['bg_card']};
                border: none;
                border-radius: 20px;
            }}
            JournalCard:hover {{
                background: {COLORS['bg_elevated']};
            }}
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 18, 20, 18)
        layout.setSpacing(10)

        # Header row
        hdr = QHBoxLayout()
        title = QLabel(entry.get("title", "Untitled"))
        title.setStyleSheet(f"color: {COLORS['text']}; font-size: {FONT['lg']}; font-weight: 700; background: transparent; border: none;")
        hdr.addWidget(title, 1)

        mood = entry.get("mood", "")
        if mood:
            mood_lbl = QLabel(mood.upper())
            mood_lbl.setStyleSheet(f"""
                color: {COLORS['sand']};
                font-size: 10px;
                font-weight: 800;
                letter-spacing: 0.8px;
                background: rgba(255,255,255,0.05);
                border-radius: 6px;
                padding: 4px 8px;
                border: none;
            """)
            hdr.addWidget(mood_lbl)
        layout.addLayout(hdr)

        # Meta row
        meta_parts = []
        if entry.get("date"):
            meta_parts.append(entry['date'])
        if entry.get("location"):
            meta_parts.append(f"📍 {entry['location']}")
        if meta_parts:
            meta_lbl = QLabel("   •   ".join(meta_parts))
            meta_lbl.setStyleSheet(f"color: {COLORS['text_subtle']}; font-size: {FONT['sm']}; background: transparent; border: none;")
            layout.addWidget(meta_lbl)

        # Preview text
        desc = entry.get("description", "")
        if desc:
            preview = desc[:140] + ("…" if len(desc) > 140 else "")
            d_lbl = QLabel(preview)
            d_lbl.setWordWrap(True)
            d_lbl.setStyleSheet(f"color: {COLORS['text_muted']}; font-size: {FONT['sm']}; background: transparent; line-height: 1.5; border: none;")
            layout.addWidget(d_lbl)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.clicked.emit(self._id)
        super().mousePressEvent(event)


# ── Destination Card ──────────────────────────────────────────────────────────

class DestinationCard(GlassCard):
    """Featured destination image-first card."""

    explore_clicked = Signal(dict)

    def __init__(self, dest: dict, parent: QWidget | None = None):
        super().__init__(parent)
        self._dest = dest
        self.setCursor(QCursor(Qt.PointingHandCursor))
        self.setMinimumWidth(220)
        self.setMinimumHeight(240)
        self.setStyleSheet(f"""
            DestinationCard {{
                background: {COLORS['bg_card']};
                border: none;
                border-radius: 20px;
            }}
            DestinationCard:hover {{
                background: {COLORS['bg_elevated']};
            }}
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(10)

        cat = dest.get("category", "DEST")
        img_lbl = QLabel(f"✦  {cat.upper()}")
        img_lbl.setAlignment(Qt.AlignCenter)
        img_lbl.setFixedHeight(110)
        img_lbl.setStyleSheet(f"""
            color: {COLORS['sand']};
            font-size: 13px;
            font-weight: 700;
            letter-spacing: 1.5px;
            background: {COLORS['bg_dark']};
            border-radius: 12px;
            border: none;
        """)
        layout.addWidget(img_lbl)

        name_lbl = QLabel(dest.get("name", ""))
        name_lbl.setStyleSheet(f"color: {COLORS['text']}; font-size: {FONT['lg']}; font-weight: 700; background: transparent; border: none;")
        layout.addWidget(name_lbl)

        country_lbl = QLabel(dest.get('country', ''))
        country_lbl.setStyleSheet(f"color: {COLORS['text_muted']}; font-size: {FONT['sm']}; background: transparent; border: none;")
        layout.addWidget(country_lbl)

        layout.addStretch()

        explore_btn = QPushButton("Explore →")
        explore_btn.setFixedHeight(34)
        explore_btn.setStyleSheet(f"""
            QPushButton {{
                background: rgba(255,255,255,0.07);
                color: {COLORS['accent']};
                border: none;
                border-radius: 10px;
                font-size: 13px;
                font-weight: 600;
            }}
            QPushButton:hover {{
                background: {COLORS['accent']};
                color: #111111;
            }}
        """)
        explore_btn.clicked.connect(lambda: self.explore_clicked.emit(dest))
        layout.addWidget(explore_btn)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.explore_clicked.emit(self._dest)
        super().mousePressEvent(event)
