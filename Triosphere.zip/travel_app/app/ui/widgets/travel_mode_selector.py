"""Travel mode selector used by the Explore route panel."""
from __future__ import annotations

from PySide6.QtCore import QPoint, Qt, Signal
from PySide6.QtWidgets import QComboBox, QVBoxLayout, QWidget

from app.api.routing import TRAVEL_MODES


class InlineComboBox(QComboBox):
    """Combo box whose option list stays inside the application window."""

    def __init__(self, parent=None):
        super().__init__(parent)

    def showPopup(self) -> None:
        view = self.view()
        window = self.window()
        view.setParent(window, Qt.Widget)
        view.setWindowFlags(Qt.Widget)
        origin = self.mapTo(window, QPoint(0, self.height() + 2))
        row_height = max(view.sizeHintForRow(0), 28)
        view.setGeometry(origin.x(), origin.y(), self.width(), min(row_height * self.count() + 4, 240))
        view.show()
        view.raise_()

    def hidePopup(self) -> None:
        self.view().hide()


class TravelModeSelector(QWidget):
    """Compact selector exposing the route mode key selected by the user."""

    mode_changed = Signal(str)

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self._combo = InlineComboBox(self)
        self._combo.setFixedHeight(38)
        self._combo.setStyleSheet("""
            QComboBox {
                background: rgba(9,21,64,0.65);
                color: #F0F4FF;
                border: 1px solid rgba(118,146,255,0.18);
                border-radius: 9px;
                padding: 0 12px;
                font-size: 13px;
            }
            QComboBox:hover, QComboBox:focus {
                border: 1px solid rgba(118,146,255,0.55);
            }
            QComboBox QAbstractItemView {
                background: #111923;
                color: #F0F4FF;
                selection-background-color: #263646;
                selection-color: #F0F4FF;
            }
        """)
        for mode_key, (name, _icon, _profile, _speed) in TRAVEL_MODES.items():
            self._combo.addItem(name, mode_key)
        driving_index = self._combo.findData("driving")
        if driving_index >= 0:
            self._combo.setCurrentIndex(driving_index)
        self._combo.currentIndexChanged.connect(self._emit_mode_changed)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self._combo)

    def _emit_mode_changed(self, _index: int) -> None:
        self.mode_changed.emit(self.get_mode())

    def get_mode(self) -> str:
        """Return the routing key for the currently selected travel mode."""
        return str(self._combo.currentData())
