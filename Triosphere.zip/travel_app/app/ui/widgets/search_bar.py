"""
Reusable LocationSearchWidget with Google Maps-style autocomplete dropdown,
keyboard navigation, debouncing, threaded geocoding, and default suggestions.

Emits a consistent location dict:
    {name, display_name, latitude, longitude, city, region, country, place_type}
"""
from __future__ import annotations

import logging
from PySide6.QtCore import Qt, Signal, QTimer, QThread, QObject, QEvent, QPoint, QSize, Slot
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem,
    QPushButton, QWidget, QVBoxLayout, QGraphicsDropShadowEffect, QSizePolicy
)
from app.config import COLORS, FONT, SEARCH_DEBOUNCE_MS, SEARCH_RESULT_LIMIT

logger = logging.getLogger(__name__)

# ── Default popular suggestions ───────────────────────────────────────────────
DEFAULT_SUGGESTIONS = [
    {"name": "Paris",       "region": "Île-de-France, France",     "lat": 48.8566,  "lon": 2.3522},
    {"name": "Goa",         "region": "India",                     "lat": 15.2993,  "lon": 74.1240},
    {"name": "Tokyo",       "region": "Kanto, Japan",              "lat": 35.6762,  "lon": 139.6503},
    {"name": "Dubai",       "region": "United Arab Emirates",      "lat": 25.2048,  "lon": 55.2708},
    {"name": "Bali",        "region": "Indonesia",                 "lat": -8.3405,  "lon": 115.0920},
    {"name": "Mumbai",      "region": "Maharashtra, India",        "lat": 19.0760,  "lon": 72.8777},
    {"name": "Pune",        "region": "Maharashtra, India",        "lat": 18.5204,  "lon": 73.8567},
    {"name": "Jaipur",      "region": "Rajasthan, India",          "lat": 26.9124,  "lon": 75.7873},
    {"name": "Manali",      "region": "Himachal Pradesh, India",   "lat": 32.2396,  "lon": 77.1887},
    {"name": "Eiffel Tower","region": "Paris, France",             "lat": 48.8584,  "lon": 2.2945},
    {"name": "Taj Mahal",   "region": "Agra, India",               "lat": 27.1751,  "lon": 78.0421},
]

DEFAULT_CATEGORIES = [
    ("🏖 Beach destinations", 15.2993,  74.1240,  "Goa Beaches"),
    ("🏔 Mountain escapes",   46.8182,   8.2275,  "Swiss Alps"),
    ("🏛 Historical cities",  41.9028,  12.4964,  "Rome, Italy"),
    ("🌆 City breaks",        35.6762, 139.6503,  "Tokyo, Japan"),
    ("🌿 Nature escapes",     -8.3405, 115.0920,  "Bali, Indonesia"),
]


def _make_location_dict(r: dict) -> dict:
    """
    Normalise a geocoding result into the canonical location dict.
    Works with both the new geocoding.py output and any legacy callers.
    """
    # Prefer the explicit lat/lon keys, fall back to latitude/longitude aliases
    lat = float(r.get("latitude") or r.get("lat") or 0.0)
    lon = float(r.get("longitude") or r.get("lon") or 0.0)
    name = r.get("name") or r.get("display_name", "").split(",")[0].strip() or "Unknown"
    return {
        "name":         name,
        "display_name": r.get("display_name", name),
        "latitude":     lat,
        "longitude":    lon,
        # aliases
        "lat":          lat,
        "lon":          lon,
        "city":         r.get("city", ""),
        "region":       r.get("region", ""),
        "country":      r.get("country", ""),
        "place_type":   r.get("place_type", r.get("type", "place")),
    }


# ── Worker ────────────────────────────────────────────────────────────────────

class SearchWorker(QObject):
    finished = Signal(list)
    error    = Signal(str)

    def __init__(self, query: str):
        super().__init__()
        self.query = query

    def run(self):
        from app.api.geocoding import geocoding_service
        try:
            results = geocoding_service.search(self.query, limit=SEARCH_RESULT_LIMIT)
            self.finished.emit(results or [])
        except Exception as exc:
            logger.error("Search worker error: %s", exc)
            self.finished.emit([])
            self.error.emit(str(exc))


# ── Thread-safe result receiver ───────────────────────────────────────────────

class _SearchResultReceiver(QObject):
    """
    Lives on the main thread. Receives the worker's finished/error signals via
    an *auto* connection that Qt automatically promotes to a *queued* connection
    because this QObject lives in a different thread to the worker.

    This guarantees all UI callbacks run on the UI thread, preventing the
    blank-rogue-window and QObject::setParent-in-wrong-thread errors that
    occur when a plain lambda (with no thread affinity) is used instead.
    """
    # Re-emitted on the main thread once the queued delivery lands.
    results_ready = Signal(str, list)   # (requested_query, results)

    def __init__(self, requested_query: str, slot, parent: QObject | None = None):
        super().__init__(parent)
        self._requested_query = requested_query
        self._slot = slot

    @Slot(list)
    def on_worker_finished(self, results: list) -> None:
        """Called on the main thread via queued connection from the worker."""
        self.results_ready.emit(self._requested_query, results)

    @Slot(str)
    def on_worker_error(self, msg: str) -> None:
        """Called on the main thread via queued connection from the worker."""
        # Relay: the actual error handler is on LocationSearchWidget
        # — we emit results_ready with an empty list so _handle_search_results
        # can still clean up loading state.
        pass  # The error signal is connected separately to self._on_search_error

    @property
    def slot(self):
        return self._slot


# ── Suggestion row ────────────────────────────────────────────────────────────

class SuggestionRowWidget(QWidget):
    """Custom row widget for location suggestions."""

    def __init__(self, name: str, region: str, place_type: str = "", parent=None):
        super().__init__(parent)
        self.setFixedHeight(48)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(12, 2, 12, 2)
        lay.setSpacing(10)

        # Icon based on place type
        icon_map = {
            "airport":       "✈️",
            "train_station": "🚉",
            "city":          "🏙",
            "country":       "🌍",
            "landmark":      "🗿",
            "attraction":    "🎯",
            "park":          "🌳",
            "beach":         "🏖",
            "hotel":         "🏨",
            "museum":        "🏛",
        }
        icon_ch = icon_map.get(place_type, "📍")
        icon = QLabel(icon_ch)
        icon.setStyleSheet(
            "font-size: 14px; background: transparent; border: none; "
            "padding: 0px; margin: 0px;"
        )
        lay.addWidget(icon, 0, Qt.AlignVCenter)

        text_v = QVBoxLayout()
        text_v.setSpacing(1)
        text_v.setContentsMargins(0, 2, 0, 2)

        name_lbl = QLabel(name)
        name_lbl.setStyleSheet(
            "color: #FFFFFF; font-size: 13px; font-weight: 700; "
            "background: transparent; border: none; padding: 0;"
        )
        text_v.addWidget(name_lbl)

        sub_lbl = QLabel(region or "Location")
        sub_lbl.setStyleSheet(
            "color: #A1A1AA; font-size: 10px; font-weight: 500; "
            "background: transparent; border: none; padding: 0;"
        )
        text_v.addWidget(sub_lbl)

        lay.addLayout(text_v, 1)


# ── Dropdown ──────────────────────────────────────────────────────────────────

class LocationDropdown(QFrame):
    """Floating borderless dropdown displaying location suggestions."""
    item_selected = Signal(dict)

    def __init__(self, parent_widget: QWidget):
        super().__init__(parent_widget)
        # NOTE: Do NOT call setWindowFlags() here.
        # setWindowFlags() on a child widget triggers an internal Qt setParent()
        # re-call that forces the widget to become visible at position (0, 0),
        # producing a black ghost rectangle overlaid on the search input.
        # Qt.Widget is the default for child widgets — no flag call is needed.
        self.setObjectName("TSDropdown")
        self.setStyleSheet("""
            QFrame#TSDropdown {
                background: rgba(15, 15, 20, 0.97);
                border: 1px solid rgba(255, 255, 255, 0.12);
                border-radius: 14px;
            }
        """)
        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(24)
        shadow.setColor(QColor(0, 0, 0, 200))
        shadow.setOffset(0, 8)
        self.setGraphicsEffect(shadow)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(4)

        self._list = QListWidget()
        self._list.setFrameShape(QFrame.NoFrame)
        self._list.setStyleSheet("""
            QListWidget {
                background: transparent;
                outline: none;
            }
            QListWidget::item {
                border-radius: 8px;
                background: transparent;
            }
            QListWidget::item:hover {
                background: rgba(255, 255, 255, 0.06);
            }
            QListWidget::item:selected {
                background: rgba(255, 255, 255, 0.10);
                border: 1px solid rgba(255, 255, 255, 0.18);
            }
        """)
        self._list.itemClicked.connect(self._on_item_clicked)
        layout.addWidget(self._list)

        self._items: list[dict] = []

        # Explicitly hide so the dropdown is never visible until show_below() is called.
        # Child widgets become visible when their parent is shown; hide() prevents that.
        self.hide()

    def populate(self, items: list[dict]):
        self._list.clear()
        self._items = items

        for item in items:
            list_item = QListWidgetItem(self._list)
            list_item.setSizeHint(QSize(240, 52))
            # Build sub-label: region + country
            region  = item.get("region", "")
            country = item.get("country", "")
            sub     = ", ".join(filter(None, [region, country])) or "Location"
            row = SuggestionRowWidget(
                item["name"], sub, item.get("place_type", "")
            )
            self._list.addItem(list_item)
            self._list.setItemWidget(list_item, row)

        self.adjust_size()

    def show_below(self, target: QWidget):
        container = self.parentWidget()
        pos = target.mapTo(container, QPoint(0, target.height() + 4))
        self.setFixedWidth(max(target.width(), 300))
        self.move(pos)
        self.show()
        self.raise_()

    def adjust_size(self):
        h = min(340, self._list.count() * 52 + 18)
        self.setFixedHeight(max(h, 60))

    def move_selection(self, step: int):
        curr  = self._list.currentRow()
        count = self._list.count()
        if count == 0:
            return
        self._list.setCurrentRow((curr + step) % count)

    def select_current(self):
        curr = self._list.currentRow()
        if 0 <= curr < len(self._items):
            self.item_selected.emit(self._items[curr])
            self.hide()

    def _on_item_clicked(self, item: QListWidgetItem):
        idx = self._list.row(item)
        if 0 <= idx < len(self._items):
            self.item_selected.emit(self._items[idx])
            self.hide()


# ── Main Search Widget ────────────────────────────────────────────────────────

class LocationSearchWidget(QWidget):
    """
    Unified location search widget.

    Signals:
        location_selected(dict): emitted when a result is chosen.
            dict keys: name, display_name, latitude, longitude,
                       city, region, country, place_type
        search_submitted(str): emitted when user presses Search/Enter
    """
    location_selected = Signal(dict)
    search_submitted  = Signal(str)

    def __init__(
        self,
        placeholder: str = "Search cities, destinations or places...",
        parent=None,
    ):
        super().__init__(parent)
        self._search_thread: QThread | None = None
        self._worker:        SearchWorker | None = None
        self._last_query:    str = ""
        self._selected_location: dict | None = None

        self._debounce = QTimer(self)
        self._debounce.setSingleShot(True)
        self._debounce.timeout.connect(self._on_debounce)

        self._build_ui(placeholder)

        self._dropdown = LocationDropdown(self)
        self._dropdown.item_selected.connect(self._on_dropdown_selection)

        self._input.installEventFilter(self)

    def _build_ui(self, placeholder: str):
        # Ensure the widget itself expands horizontally to fill its parent container
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self._frame = QFrame()
        self._frame.setFixedHeight(48)
        # Allow the frame to expand horizontally so the input is never collapsed
        self._frame.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self._frame.setStyleSheet("""
            QFrame {
                background: rgba(15, 15, 20, 0.78);
                border: 1px solid rgba(255, 255, 255, 0.10);
                border-radius: 24px;
            }
            QFrame:focus-within {
                border-color: rgba(255, 255, 255, 0.35);
            }
        """)

        fl = QHBoxLayout(self._frame)
        fl.setContentsMargins(18, 0, 6, 0)
        fl.setSpacing(10)

        self._icon = QLabel("🔍")
        self._icon.setStyleSheet(
            "font-size: 14px; background: transparent; color: #71717A;"
        )
        fl.addWidget(self._icon)

        self._input = QLineEdit()
        self._input.setPlaceholderText(placeholder)
        self._input.setStyleSheet("""
            QLineEdit {
                background: transparent;
                border: none;
                color: #F5F5F5;
                font-size: 13px;
                font-weight: 500;
            }
            QLineEdit::placeholder { color: #71717A; }
        """)
        self._input.textChanged.connect(self._on_text_changed)
        self._input.returnPressed.connect(self._submit_entered)
        fl.addWidget(self._input, 1)

        # Loading indicator
        self._loader = QLabel("…")
        self._loader.setStyleSheet(
            "color: #71717A; font-size: 14px; font-weight: 700; background: transparent;"
        )
        self._loader.hide()
        fl.addWidget(self._loader)

        # Error indicator
        self._error_icon = QLabel("⚠")
        self._error_icon.setStyleSheet(
            f"color: {COLORS['danger']}; font-size: 13px; background: transparent;"
        )
        self._error_icon.hide()
        self._error_icon.setToolTip("Search failed — check your internet connection")
        fl.addWidget(self._error_icon)

        self._clear_btn = QPushButton("✕")
        self._clear_btn.setFixedSize(24, 24)
        self._clear_btn.setCursor(Qt.PointingHandCursor)
        self._clear_btn.setStyleSheet("""
            QPushButton {
                background: transparent;
                color: #71717A;
                border: none;
                font-size: 11px;
            }
            QPushButton:hover { color: #FFF; }
        """)
        self._clear_btn.hide()
        self._clear_btn.clicked.connect(self.clear)
        fl.addWidget(self._clear_btn)

        sbtn = QPushButton("Search")
        sbtn.setFixedSize(80, 36)
        sbtn.setCursor(Qt.PointingHandCursor)
        sbtn.setStyleSheet(f"""
            QPushButton {{
                background: {COLORS['sand']};
                color: #111111;
                border-radius: 18px;
                font-size: 12px;
                font-weight: 800;
                border: none;
            }}
            QPushButton:hover {{ background: {COLORS['accent_light']}; }}
        """)
        sbtn.clicked.connect(self._submit_entered)
        fl.addWidget(sbtn)

        layout.addWidget(self._frame)

    # ── Event filter ─────────────────────────────────────────────────────────

    def eventFilter(self, obj, event) -> bool:
        if obj is self._input and event.type() == QEvent.KeyPress:
            key = event.key()
            if self._dropdown.isVisible():
                if key == Qt.Key_Down:
                    self._dropdown.move_selection(1)
                    return True
                elif key == Qt.Key_Up:
                    self._dropdown.move_selection(-1)
                    return True
                elif key in (Qt.Key_Return, Qt.Key_Enter):
                    self._dropdown.select_current()
                    return True
                elif key == Qt.Key_Escape:
                    self._dropdown.hide()
                    return True
        return super().eventFilter(obj, event)

    # ── Text change handling ──────────────────────────────────────────────────

    def _on_text_changed(self, text: str):
        self._clear_btn.setVisible(bool(text))
        self._error_icon.hide()
        if self._selected_location:
            if text.strip().lower() != self._selected_location.get("name", "").strip().lower():
                self._selected_location = None
        if not text.strip():
            self._debounce.stop()
            self._show_default_suggestions()
            return
        self._debounce.start(SEARCH_DEBOUNCE_MS)

    def _on_debounce(self):
        query = self._input.text().strip()
        if not query or query == self._last_query:
            return
        self._last_query = query
        self._set_loading(True)
        self._run_search(query, self._on_search_results)

    # ── Search execution ──────────────────────────────────────────────────────

    def _run_search(self, query: str, slot):
        """Cancel any running search and start a new one.

        IMPORTANT: worker.finished must not connect to a plain lambda because
        lambdas have no QObject thread affinity in PySide6.  Qt would therefore
        fire the connection *directly* on the worker thread, causing UI widgets
        to be touched from a non-main thread (blank rogue window, setParent
        errors, crashes).

        We use _SearchResultReceiver — a QObject that lives on the main thread.
        Qt automatically uses a queued connection between the worker thread's
        signal and the receiver's slot, so all UI work runs safely on the UI
        thread.
        """
        if self._search_thread and self._search_thread.isRunning():
            logger.info("[action started] Replacing search request: %s", query)
            self._search_thread.quit()
            self._search_thread.wait(300)

        thread = QThread(self)
        self._search_thread = thread
        self._worker        = SearchWorker(query)
        thread._worker      = self._worker
        self._worker.moveToThread(thread)

        # Build a main-thread receiver for this request.
        # Keeping a reference so it isn't GC'd before the thread finishes.
        # The receiver IS a QObject so Qt correctly uses an auto-connection that
        # becomes *queued* (worker thread → main thread).  A plain lambda would
        # have no thread affinity and would fire directly on the worker thread.
        receiver = _SearchResultReceiver(query, slot, parent=self)
        thread._receiver = receiver

        # worker → receiver: auto-connection → queued because receiver lives in
        # main thread and worker lives in worker-thread.
        self._worker.finished.connect(receiver.on_worker_finished)
        self._worker.error.connect(self._on_search_error)

        # receiver → handle results: direct (both in main thread)
        receiver.results_ready.connect(
            lambda rq, results: self._handle_search_results(rq, results, receiver.slot)
        )

        # Clean-up chain
        self._worker.finished.connect(thread.quit)
        self._worker.finished.connect(self._worker.deleteLater)
        thread.finished.connect(thread.deleteLater)
        thread.finished.connect(receiver.deleteLater)
        # Null out the reference so we never call isRunning() on a deleted C++ object
        thread.finished.connect(
            lambda: setattr(self, "_search_thread", None) if self._search_thread is thread else None
        )

        thread.started.connect(self._worker.run)
        thread.start()

    def _handle_search_results(self, query: str, results: list, slot) -> None:
        if query != self._input.text().strip():
            logger.info("[action completed] Ignoring outdated search: %s", query)
            return
        slot(results)

    def _on_search_results(self, results: list):
        self._set_loading(False)
        if not results:
            self._show_empty_state()
            return
        items = [_make_location_dict(r) for r in results]
        self._dropdown.populate(items)
        self._dropdown.show_below(self._frame)

    def _on_search_error(self, msg: str):
        self._set_loading(False)
        self._error_icon.show()
        self._dropdown.hide()

    def _show_empty_state(self):
        query = self._input.text().strip()
        # Show an empty-state item in the dropdown
        items = [{"name": f'No results for "{query}"',
                  "display_name": "Try a different spelling or search term.",
                  "latitude": 0.0, "longitude": 0.0,
                  "lat": 0.0, "lon": 0.0,
                  "city": "", "region": "", "country": "",
                  "place_type": "empty"}]
        self._dropdown.populate(items)
        self._dropdown.show_below(self._frame)

    def _show_default_suggestions(self):
        items = []
        for ds in DEFAULT_SUGGESTIONS:
            region  = ds["region"]
            country = region.split(",")[-1].strip()
            reg     = region.split(",")[0].strip()
            items.append({
                "name":         ds["name"],
                "display_name": f"{ds['name']}, {region}",
                "latitude":     ds["lat"],
                "longitude":    ds["lon"],
                "lat":          ds["lat"],
                "lon":          ds["lon"],
                "city":         ds["name"],
                "region":       reg,
                "country":      country,
                "place_type":   "city",
            })
        self._dropdown.populate(items)
        self._dropdown.show_below(self._frame)

    # ── Selection handling ────────────────────────────────────────────────────

    def _on_dropdown_selection(self, loc: dict):
        # Don't select the empty-state sentinel
        if loc.get("place_type") == "empty":
            return
        self._selected_location = loc
        self._input.blockSignals(True)
        self._input.setText(loc["name"])
        self._input.blockSignals(False)
        self._clear_btn.show()
        self.location_selected.emit(loc)

    def _submit_entered(self):
        """User pressed Search button or Enter key."""
        q = self._input.text().strip()
        if not q:
            return
        self._dropdown.hide()
        self.search_submitted.emit(q)
        self._set_loading(True)
        self._run_search(q, self._on_geocode_select_result)

    def _on_geocode_select_result(self, results: list):
        self._set_loading(False)
        if not results:
            self._show_empty_state()
            return
        loc = _make_location_dict(results[0])
        self._selected_location = loc
        self._input.blockSignals(True)
        self._input.setText(loc["name"])
        self._input.blockSignals(False)
        self._clear_btn.show()
        self.location_selected.emit(loc)

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _set_loading(self, loading: bool):
        self._loader.setVisible(loading)
        self._error_icon.setVisible(False)

    # ── Public API ────────────────────────────────────────────────────────────

    def get_selected_location(self) -> dict | None:
        """Return the resolved location dict if currently selected, or None."""
        if self._selected_location:
            curr = self._input.text().strip().lower()
            sel_name = self._selected_location.get("name", "").strip().lower()
            if curr == sel_name:
                return self._selected_location
        return None

    def set_selected_location(self, loc: dict | None):
        """Set the selected location dict and update input text."""
        self._selected_location = loc
        if loc:
            self.set_text(loc.get("name", ""))
        else:
            self.clear()

    def set_text(self, text: str):
        self._input.blockSignals(True)
        self._input.setText(text)
        self._input.blockSignals(False)
        self._clear_btn.setVisible(bool(text))
        if self._selected_location:
            if text.strip().lower() != self._selected_location.get("name", "").strip().lower():
                self._selected_location = None

    def text(self) -> str:
        return self._input.text()

    def get_text(self) -> str:
        return self._input.text()

    def clear(self):
        self._selected_location = None
        self._input.clear()
        self._dropdown.hide()
        self._clear_btn.hide()
        self._error_icon.hide()
        self._loader.hide()
        self._last_query = ""


# Alias for backward compatibility
SearchBar = LocationSearchWidget
