"""
Loading / error state widgets for TripSphere.
"""
from __future__ import annotations

import math
from PySide6.QtCore    import QPointF, QRectF, Qt, QTimer, Property, QPropertyAnimation, QEasingCurve
from PySide6.QtGui     import QColor, QPainter, QPen
from PySide6.QtWidgets import (
    QLabel, QPushButton, QSizePolicy, QVBoxLayout, QWidget
)
from app.config import COLORS, FONT


class LoadingSpinner(QWidget):
    """
    Animated arc spinner that matches the warm gold theme.
    """

    def __init__(self, size: int = 48, parent: QWidget | None = None):
        super().__init__(parent)
        self._size  = size
        self._angle = 0.0
        self._color = QColor(COLORS["accent"])
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self.setFixedSize(size, size)
        self.setAttribute(Qt.WA_TranslucentBackground)

    def start(self) -> None:
        self._timer.start(16)
        self.show()

    def stop(self) -> None:
        self._timer.stop()
        self.hide()

    def _tick(self) -> None:
        self._angle = (self._angle + 6) % 360
        self.update()

    def paintEvent(self, _event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        s      = self._size
        w      = max(3, s // 10)
        margin = w
        rect   = QRectF(margin, margin, s - 2*margin, s - 2*margin)

        # Background arc (faint)
        pen = QPen(QColor("rgba(255,255,255,0.06)"), w, Qt.SolidLine, Qt.RoundCap)
        painter.setPen(pen)
        painter.drawArc(rect, 0, 360 * 16)

        # Spinning arc
        pen.setColor(self._color)
        painter.setPen(pen)
        start = int((90 - self._angle) * 16)
        painter.drawArc(rect, start, -270 * 16)


class LoadingOverlay(QWidget):
    """
    Semi-transparent overlay with spinner + message.
    Shown while network/DB operations are in progress.
    """

    def __init__(self, parent: QWidget):
        super().__init__(parent)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_StyledBackground, False)
        self.setStyleSheet("background: transparent;")

        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignCenter)
        layout.setSpacing(16)

        self._spinner = LoadingSpinner(size=52, parent=self)
        layout.addWidget(self._spinner, alignment=Qt.AlignCenter)

        self._label = QLabel("Loading…")
        self._label.setAlignment(Qt.AlignCenter)
        self._label.setStyleSheet(
            f"color: {COLORS['text_muted']}; font-size: {FONT['base']}; background: transparent;"
        )
        layout.addWidget(self._label)
        self.hide()

    def show_loading(self, message: str = "Loading…") -> None:
        self._label.setText(message)
        self.resize(self.parent().size())
        self._spinner.start()
        self.show()
        self.raise_()

    def hide_loading(self) -> None:
        self._spinner.stop()
        self.hide()

    def resizeEvent(self, event) -> None:
        if self.parent():
            self.resize(self.parent().size())


class EmptyStateWidget(QWidget):
    """
    Beautiful empty-state with icon, title, subtitle, and optional CTA button.
    """

    def __init__(
        self,
        icon: str = "✦",
        title: str = "Nothing here yet",
        subtitle: str = "",
        button_text: str = "",
        parent: QWidget | None = None,
    ):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignCenter)
        layout.setSpacing(14)
        layout.setContentsMargins(40, 50, 40, 50)

        icon_lbl = QLabel(icon)
        icon_lbl.setAlignment(Qt.AlignCenter)
        icon_lbl.setStyleSheet(f"font-size: 48px; color: {COLORS['accent']}; background: transparent;")
        layout.addWidget(icon_lbl)

        title_lbl = QLabel(title)
        title_lbl.setAlignment(Qt.AlignCenter)
        title_lbl.setStyleSheet(
            f"color: {COLORS['text']}; font-size: {FONT['xl']}; font-weight: 700; background: transparent;"
        )
        layout.addWidget(title_lbl)

        if subtitle:
            sub_lbl = QLabel(subtitle)
            sub_lbl.setAlignment(Qt.AlignCenter)
            sub_lbl.setWordWrap(True)
            sub_lbl.setStyleSheet(
                f"color: {COLORS['text_muted']}; font-size: {FONT['base']}; background: transparent;"
            )
            layout.addWidget(sub_lbl)

        if button_text:
            btn = QPushButton(button_text)
            btn.setObjectName("cta_button")
            btn.setStyleSheet(f"""
                QPushButton {{
                    background: {COLORS['accent']};
                    color: #111111;
                    border: none;
                    border-radius: 12px;
                    padding: 12px 28px;
                    font-size: {FONT['base']};
                    font-weight: 700;
                }}
                QPushButton:hover {{ background: {COLORS['accent_light']}; }}
            """)
            btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
            layout.addWidget(btn, alignment=Qt.AlignCenter)
            self.cta_button = btn
        else:
            self.cta_button = None


class ErrorWidget(QWidget):
    """Error state with retry capability."""

    retry_clicked = None  # set by owner

    def __init__(
        self,
        message: str = "Something went wrong",
        parent: QWidget | None = None,
    ):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignCenter)
        layout.setSpacing(14)

        icon_lbl = QLabel("⚠️")
        icon_lbl.setAlignment(Qt.AlignCenter)
        icon_lbl.setStyleSheet("font-size: 44px; background: transparent;")
        layout.addWidget(icon_lbl)

        msg_lbl = QLabel(message)
        msg_lbl.setAlignment(Qt.AlignCenter)
        msg_lbl.setWordWrap(True)
        msg_lbl.setStyleSheet(
            f"color: {COLORS['warning']}; font-size: {FONT['base']}; background: transparent;"
        )
        layout.addWidget(msg_lbl)

        retry_btn = QPushButton("Try Again")
        retry_btn.setStyleSheet(f"""
            QPushButton {{
                background: {COLORS['warning_bg']};
                color: {COLORS['warning']};
                border: 1px solid {COLORS['warning']};
                border-radius: 12px;
                padding: 10px 24px;
                font-size: {FONT['base']};
                font-weight: 700;
            }}
            QPushButton:hover {{ background: {COLORS['warning']}; color: #000; }}
        """)
        retry_btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        layout.addWidget(retry_btn, alignment=Qt.AlignCenter)
        self.retry_button = retry_btn
