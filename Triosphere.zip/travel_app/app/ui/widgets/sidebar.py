"""
Sidebar navigation — premium floating dark nav with warm gold accents.
Collapsible with smooth animation. No blue tones.
"""
from __future__ import annotations

from PySide6.QtCore    import Qt, Signal, QPropertyAnimation, QEasingCurve, QSize
from PySide6.QtGui     import QColor, QFont
from PySide6.QtWidgets import (
    QFrame, QLabel, QPushButton, QScrollArea,
    QSizePolicy, QSpacerItem, QVBoxLayout, QHBoxLayout, QWidget,
    QGraphicsDropShadowEffect
)
from app.config import COLORS, FONT

SIDEBAR_EXPANDED  = 220
SIDEBAR_COLLAPSED = 72

# (key, icon, label)
NAV_ITEMS = [
    ("home",        "⌂",  "Home"),
    ("explore",     "◈",  "Explore"),
    ("trips",       "✈",  "Itineraries"),
    ("expenses",    "₹",  "Expenses"),
    ("chat",        "✧",  "AI Assistant"),
    ("settings",    "⚙",  "Settings"),
]

# Warm accent per page
_ITEM_ACCENTS = {
    "globe":     COLORS["accent"],
    "home":      COLORS["accent"],
    "explore":   COLORS["olive"],
    "places":    COLORS["olive"],
    "trips":     COLORS["accent"],
    "expenses":  COLORS["coral"],
    "budget":    COLORS["sand"],
    "journal":   COLORS["coral"],
    "favorites": COLORS["accent"],
    "random":    COLORS["accent_light"],
    "chat":      "#B8A4E8",  # soft violet for AI
    "settings":  COLORS["text_muted"],
}


class NavButton(QFrame):
    """Single sidebar nav item — pill style with warm gold active state."""

    nav_clicked = Signal(str)

    def __init__(self, key: str, icon: str, label: str, parent: QWidget | None = None):
        super().__init__(parent)
        self._key     = key
        self._icon    = icon
        self._label   = label
        self._active  = False
        self._expanded = True
        self._accent  = _ITEM_ACCENTS.get(key, COLORS["accent"])

        self.setCursor(Qt.PointingHandCursor)
        self.setFixedHeight(44)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

        self._layout = QHBoxLayout(self)
        self._layout.setContentsMargins(12, 0, 12, 0)
        self._layout.setSpacing(12)

        # Icon
        self._icon_lbl = QLabel(icon)
        self._icon_lbl.setFixedWidth(24)
        self._icon_lbl.setAlignment(Qt.AlignCenter)
        self._layout.addWidget(self._icon_lbl)

        # Label
        self._text_lbl = QLabel(label)
        self._layout.addWidget(self._text_lbl)
        self._layout.addStretch()

        self._apply_style()

    def set_active(self, active: bool):
        self._active = active
        self._apply_style()

    def set_expanded(self, expanded: bool):
        self._expanded = expanded
        self._text_lbl.setVisible(expanded)

    def _apply_style(self):
        if self._active:
            bg          = "rgba(255, 255, 255, 0.08)"
            text_color  = "#F5F5F5"
            icon_color  = COLORS["accent"]
            weight      = "700"
        else:
            bg          = "transparent"
            text_color  = COLORS["text_subtle"]
            icon_color  = COLORS["text_dim"]
            weight      = "500"

        self.setStyleSheet(f"""
            NavButton {{
                background: {bg};
                border-radius: 12px;
                border: none;
            }}
            NavButton:hover {{
                background: rgba(255,255,255,0.05);
            }}
        """)
        self._text_lbl.setStyleSheet(
            f"color:{text_color};font-size:14px;font-weight:{weight};"
            f"background:transparent;letter-spacing:0.1px;"
        )
        self._icon_lbl.setStyleSheet(
            f"color:{icon_color};font-size:17px;font-weight:700;background:transparent;"
        )

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.nav_clicked.emit(self._key)
        super().mousePressEvent(e)


class Sidebar(QWidget):
    """Collapsible left-hand sidebar with premium warm design."""

    nav_clicked = Signal(str)
    switch_account_clicked = Signal()

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self._expanded = True
        self._buttons: dict[str, NavButton] = {}
        self._active_key = "home"

        self.setFixedWidth(SIDEBAR_EXPANDED)
        self._build_ui()

    def _build_ui(self):
        c = COLORS
        self.setStyleSheet(f"""
            Sidebar {{
                background: {c['sidebar_bg']};
                border-right: 1px solid {c['border']};
            }}
        """)

        root = QVBoxLayout(self)
        root.setContentsMargins(10, 0, 10, 20)
        root.setSpacing(2)

        # ── Logo / header ──────────────────────────────────────────────────
        self._logo_bar = QWidget()
        self._logo_bar.setFixedHeight(72)
        self._logo_bar.setStyleSheet("QWidget { border-radius: 10px; } QWidget:hover { background: rgba(212,169,106,0.06); }")
        self._logo_bar.setToolTip("Return to 3D Globe")
        logo_row = QHBoxLayout(self._logo_bar)
        logo_row.setContentsMargins(6, 0, 4, 0)
        logo_row.setSpacing(10)

        # Globe logo mark
        dot = QLabel("◎")
        dot.setFixedSize(36, 36)
        dot.setAlignment(Qt.AlignCenter)
        dot.setStyleSheet(f"""
            color: {c['accent']};
            font-size: 22px;
            font-weight: 700;
            background: {c['accent_glow']};
            border-radius: 10px;
            border: 1px solid {c['border_accent']};
        """)
        logo_row.addWidget(dot)

        self._wordmark = QLabel("TripSphere")
        self._wordmark.setStyleSheet(
            f"color: {c['text']}; font-size: 16px; font-weight: 800; "
            f"letter-spacing: -0.5px; background: transparent;"
        )
        logo_row.addWidget(self._wordmark)
        logo_row.addStretch()

        # Collapse toggle
        self._toggle_btn = QPushButton("‹")
        self._toggle_btn.setFixedSize(28, 28)
        self._toggle_btn.setStyleSheet(f"""
            QPushButton {{
                background: rgba(255,255,255,0.05);
                color: {c['text_muted']};
                border: 1px solid {c['border']};
                border-radius: 8px;
                font-size: 14px;
                font-weight: 600;
                padding: 0;
            }}
            QPushButton:hover {{
                background: {c['accent_glow']};
                color: {c['accent']};
                border-color: {c['border_accent']};
            }}
        """)
        self._toggle_btn.clicked.connect(self.toggle_expand)
        logo_row.addWidget(self._toggle_btn)

        self._logo_bar.setCursor(Qt.PointingHandCursor)
        self._logo_bar.mouseReleaseEvent = lambda e: self.nav_clicked.emit("globe")
        root.addWidget(self._logo_bar)

        # Thin separator
        sep = QFrame()
        sep.setFrameShape(QFrame.HLine)
        sep.setStyleSheet(f"color: {c['border']};")
        sep.setFixedHeight(1)
        root.addWidget(sep)
        root.addSpacing(10)

        # Section label
        self._nav_label = QLabel("NAVIGATE")
        self._nav_label.setStyleSheet(f"""
            color: {c['text_dim']};
            font-size: 10px;
            font-weight: 700;
            letter-spacing: 1.5px;
            background: transparent;
            padding: 0 8px;
        """)
        root.addWidget(self._nav_label)
        root.addSpacing(4)

        # ── Nav items ──────────────────────────────────────────────────────
        for key, icon, label in NAV_ITEMS:
            btn = NavButton(key, icon, label)
            btn.nav_clicked.connect(self._on_nav)
            self._buttons[key] = btn
            root.addWidget(btn)
            root.addSpacing(1)

        root.addStretch()

        # ── Bottom: User Avatar Badge ──────────────────────────────────────────
        self._user_frame = QFrame()
        self._user_frame.setFixedHeight(48)
        self._user_frame.setCursor(Qt.PointingHandCursor)
        self._user_frame.setStyleSheet(f"""
            QFrame {{
                background: rgba(255, 255, 255, 0.04);
                border-radius: 24px;
                border: none;
            }}
            QFrame:hover {{
                background: rgba(255, 255, 255, 0.08);
            }}
        """)
        self._user_frame.setToolTip("Switch profile")
        u_layout = QHBoxLayout(self._user_frame)
        u_layout.setContentsMargins(6, 4, 12, 4)
        u_layout.setSpacing(10)

        # Avatar circle
        avatar_lbl = QLabel("👤")
        avatar_lbl.setFixedSize(36, 36)
        avatar_lbl.setAlignment(Qt.AlignCenter)
        avatar_lbl.setStyleSheet(f"""
            background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #D4A96A, stop:1 #A07840);
            color: #111111;
            font-size: 16px;
            border-radius: 18px;
            border: none;
        """)
        u_layout.addWidget(avatar_lbl)

        self._user_name_lbl = QLabel("Traveller")
        self._user_name_lbl.setStyleSheet(f"""
            color: {c['text']};
            font-size: 13px;
            font-weight: 700;
            background: transparent;
        """)
        u_layout.addWidget(self._user_name_lbl)
        u_layout.addStretch()

        root.addWidget(self._user_frame)
        self._user_frame.mouseReleaseEvent = lambda e: self.switch_account_clicked.emit()

        # Mark home active
        self._buttons["home"].set_active(True)

    # ── slots ─────────────────────────────────────────────────────────────────

    def _on_nav(self, key: str):
        if key == self._active_key:
            return
        if self._active_key in self._buttons:
            self._buttons[self._active_key].set_active(False)
        self._active_key = key
        if key in self._buttons:
            self._buttons[key].set_active(True)
        self.nav_clicked.emit(key)

    def set_active_page(self, key: str):
        if key in self._buttons and key != self._active_key:
            if self._active_key in self._buttons:
                self._buttons[self._active_key].set_active(False)
            self._active_key = key
            self._buttons[key].set_active(True)

    def set_user_name(self, name: str) -> None:
        self._user_name_lbl.setText(name or "Traveller")

    def toggle_expand(self):
        self._expanded = not self._expanded
        target = SIDEBAR_EXPANDED if self._expanded else SIDEBAR_COLLAPSED

        for prop in (b"minimumWidth", b"maximumWidth"):
            anim = QPropertyAnimation(self, prop, self)
            anim.setDuration(220)
            anim.setEasingCurve(QEasingCurve.OutCubic)
            anim.setStartValue(self.width())
            anim.setEndValue(target)
            anim.start()

        for btn in self._buttons.values():
            btn.set_expanded(self._expanded)

        self._wordmark.setVisible(self._expanded)
        self._nav_label.setVisible(self._expanded)
        self._user_name_lbl.setVisible(self._expanded)
        self._toggle_btn.setText("‹" if self._expanded else "›")

