"""Route result summary used by the Explore route panel."""
from __future__ import annotations

from PySide6.QtWidgets import QFrame, QLabel, QVBoxLayout


class RouteSummaryWidget(QFrame):
    """Display route status and the essential details returned by routing."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._layout = QVBoxLayout(self)
        self._layout.setContentsMargins(14, 12, 14, 12)
        self._layout.setSpacing(6)
        self._build_ui()
        self.hide()

    def _build_ui(self):
        self.setStyleSheet("""
            QFrame {
                background: #172332;
                border: 1px solid #263646;
                border-radius: 14px;
            }
        """)
        self._title = QLabel()
        self._title.setStyleSheet(
            "color: #F5F1E8; font-size: 13px; font-weight: 700; background: transparent;"
        )
        self._details = QLabel()
        self._details.setWordWrap(True)
        self._details.setStyleSheet(
            "color: #AAB7C5; font-size: 12px; background: transparent;"
        )
        self._layout.addWidget(self._title)
        self._layout.addWidget(self._details)

    def _show_message(self, title: str, message: str) -> None:
        self._title.setText(title)
        self._details.setText(message)
        self.show()

    def hide_summary(self) -> None:
        self.hide()

    def show_loading(self) -> None:
        self._show_message("Calculating route", "Finding the best route...")

    def show_validation_error(self, message: str) -> None:
        self._show_message("Route unavailable", message)

    def show_result(self, result: dict) -> None:
        if not result.get("supported", True):
            self._show_message(
                "Route unavailable",
                result.get("unsupported_message") or "This travel mode is unavailable.",
            )
            return

        if result.get("error"):
            self._show_message("Route error", str(result["error"]))
            return

        mode_name = result.get("mode_name") or "Route"
        distance = result.get("distance_km", 0)
        duration = result.get("duration_str") or "—"
        suffix = " (estimated)" if result.get("fallback") else ""
        self._show_message(
            mode_name,
            f"{distance:.2f} km  ·  {duration}{suffix}",
        )