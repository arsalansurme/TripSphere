"""
Account switcher — pick an existing local profile or create a new one.
No passwords; profiles are just a name used to keep each person's trips,
expenses, journal, and favorites separate on a shared install.
"""
from __future__ import annotations

from PySide6.QtCore    import Qt
from PySide6.QtWidgets import (
    QDialog, QFrame, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QScrollArea, QSizePolicy, QVBoxLayout, QWidget
)
from app.config import COLORS, FONT
from app.database.repositories import user_repo


class _ProfileRow(QFrame):
    """One selectable profile in the list."""

    def __init__(self, profile: dict, is_active: bool, on_pick, parent=None):
        super().__init__(parent)
        self._on_pick = on_pick
        self._user_id = profile["id"]

        self.setCursor(Qt.PointingHandCursor)
        self.setFixedHeight(56)
        bg = "rgba(212,169,106,0.10)" if is_active else "rgba(255,255,255,0.04)"
        border = COLORS["accent"] if is_active else "transparent"
        self.setStyleSheet(f"""
            QFrame {{ background: {bg}; border-radius: 14px; border: 1px solid {border}; }}
            QFrame:hover {{ background: rgba(255,255,255,0.08); }}
        """)

        row = QHBoxLayout(self)
        row.setContentsMargins(12, 6, 14, 6)
        row.setSpacing(12)

        avatar = QLabel("👤")
        avatar.setFixedSize(38, 38)
        avatar.setAlignment(Qt.AlignCenter)
        avatar.setStyleSheet("""
            background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #D4A96A, stop:1 #A07840);
            color: #111111; font-size: 17px; border-radius: 19px; border: none;
        """)
        row.addWidget(avatar)

        text_col = QVBoxLayout()
        text_col.setSpacing(1)
        name_lbl = QLabel(profile.get("name") or "Traveller")
        name_lbl.setStyleSheet(f"color:{COLORS['text']}; font-size:14px; font-weight:700; background:transparent;")
        text_col.addWidget(name_lbl)
        sub = QLabel("Active profile" if is_active else (profile.get("home_city") or "Local profile"))
        sub.setStyleSheet(f"color:{COLORS['text_subtle']}; font-size:11px; background:transparent;")
        text_col.addWidget(sub)
        row.addLayout(text_col)
        row.addStretch()

        if is_active:
            check = QLabel("✓")
            check.setStyleSheet(f"color:{COLORS['accent']}; font-size:16px; font-weight:800; background:transparent;")
            row.addWidget(check)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._on_pick(self._user_id)
        super().mousePressEvent(e)


class AccountSwitcherDialog(QDialog):
    """Modal listing all local profiles, with a form to add a new one."""

    def __init__(self, current_user_id: int, parent=None):
        super().__init__(parent)
        self._current_user_id = current_user_id
        self._picked_user_id: int | None = None

        self.setWindowTitle("Switch Profile")
        self.setModal(True)
        self.setMinimumWidth(380)
        self.setStyleSheet(f"QDialog {{ background: {COLORS['bg_dark']}; border: 1px solid {COLORS['border_hover']}; border-radius: 14px; }}")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(22, 22, 22, 20)
        layout.setSpacing(14)

        title = QLabel("Switch Profile")
        title.setStyleSheet(f"color:{COLORS['text']}; font-size:{FONT['lg']}; font-weight:800; background:transparent;")
        layout.addWidget(title)

        subtitle = QLabel("Pick a profile, or add a new one. Each profile keeps its own trips, expenses, journal, and favorites.")
        subtitle.setWordWrap(True)
        subtitle.setStyleSheet(f"color:{COLORS['text_subtle']}; font-size:11px; background:transparent;")
        layout.addWidget(subtitle)

        # Scrollable profile list
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setMaximumHeight(260)
        scroll.setStyleSheet("QScrollArea { background: transparent; border: none; }")

        list_widget = QWidget()
        list_widget.setStyleSheet("background: transparent;")
        self._list_layout = QVBoxLayout(list_widget)
        self._list_layout.setContentsMargins(0, 4, 0, 4)
        self._list_layout.setSpacing(8)

        for profile in user_repo.get_all_profiles():
            row = _ProfileRow(profile, profile["id"] == current_user_id, self._on_pick_existing)
            self._list_layout.addWidget(row)
        self._list_layout.addStretch()

        scroll.setWidget(list_widget)
        layout.addWidget(scroll)

        # Add-new-profile row
        add_row = QHBoxLayout()
        add_row.setSpacing(8)
        self._new_name = QLineEdit()
        self._new_name.setPlaceholderText("New profile name…")
        self._new_name.setFixedHeight(38)
        self._new_name.setStyleSheet(f"""
            QLineEdit {{ background: rgba(255,255,255,0.05); color: {COLORS['text']};
                border: 1px solid {COLORS['border_hover']}; border-radius: 10px; padding: 0 12px; font-size: 13px; }}
            QLineEdit:focus {{ border-color: {COLORS['accent']}; }}
        """)
        self._new_name.returnPressed.connect(self._on_add_profile)
        add_row.addWidget(self._new_name, 1)

        add_btn = QPushButton("+ Add")
        add_btn.setFixedHeight(38)
        add_btn.setCursor(Qt.PointingHandCursor)
        add_btn.setStyleSheet(f"""
            QPushButton {{ background: {COLORS['accent']}; color: #1a1200; border: none;
                border-radius: 10px; padding: 0 16px; font-weight: 700; font-size: 13px; }}
            QPushButton:hover {{ background: {COLORS['accent_light']}; }}
        """)
        add_btn.clicked.connect(self._on_add_profile)
        add_row.addWidget(add_btn)
        layout.addLayout(add_row)

        cancel_btn = QPushButton("Cancel")
        cancel_btn.setCursor(Qt.PointingHandCursor)
        cancel_btn.setStyleSheet(f"""
            QPushButton {{ background: transparent; color: {COLORS['text_muted']};
                border: 1px solid {COLORS['border_hover']}; border-radius: 10px; padding: 8px 0; font-size: 12px; }}
            QPushButton:hover {{ color: {COLORS['text']}; }}
        """)
        cancel_btn.clicked.connect(self.reject)
        layout.addWidget(cancel_btn)

    def _on_pick_existing(self, user_id: int) -> None:
        self._picked_user_id = user_id
        self.accept()

    def _on_add_profile(self) -> None:
        name = self._new_name.text().strip()
        if not name:
            self._new_name.setFocus()
            return
        new_id = user_repo.create_profile(name)
        self._picked_user_id = new_id
        self.accept()

    def picked_user_id(self) -> int | None:
        return self._picked_user_id
