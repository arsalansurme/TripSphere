"""
Favorites screen — "Your Saved World" collection with embedded map.
"""
from __future__ import annotations
import logging

from PySide6.QtCore    import Qt, Signal
from PySide6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QPushButton,
    QScrollArea, QSplitter, QVBoxLayout, QWidget
)
from app.config import COLORS, FONT
from app.database.repositories import favorites_repo
from app.map.map_view import MapView
from app.ui.widgets.loading import EmptyStateWidget

logger = logging.getLogger(__name__)


class FavoriteCard(QFrame):
    """Single saved place card."""

    delete_clicked   = Signal(int)
    view_map_clicked = Signal(float, float, str)

    def __init__(self, fav: dict, parent=None):
        super().__init__(parent)
        self._id = fav.get("id", -1)
        self.setStyleSheet(f"""
            FavoriteCard {{
                background: {COLORS['bg_card']};
                border: none;
                border-radius: 16px;
            }}
            FavoriteCard:hover {{
                background: {COLORS['bg_elevated']};
            }}
        """)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 16, 18, 16)
        layout.setSpacing(10)

        hdr = QHBoxLayout()
        name = QLabel(fav.get("name", "Unknown"))
        name.setStyleSheet(f"color:{COLORS['text']};font-size:{FONT['base']};font-weight:700;background:transparent;border:none;")
        hdr.addWidget(name, 1)

        cat = fav.get("category", "")
        if cat:
            cat_lbl = QLabel(cat)
            cat_lbl.setStyleSheet(f"color:{COLORS['accent']};font-size:10px;font-weight:700;border-radius:6px;padding:2px 8px;background:rgba(255,255,255,0.06);border:none;")
            hdr.addWidget(cat_lbl)
        layout.addLayout(hdr)

        desc = fav.get("description", "")
        if desc:
            d = QLabel(desc[:120] + ("…" if len(desc) > 120 else ""))
            d.setWordWrap(True)
            d.setStyleSheet(f"color:{COLORS['text_muted']};font-size:{FONT['sm']};background:transparent;border:none;")
            layout.addWidget(d)

        coords = fav.get("lat"), fav.get("lon")
        if coords[0]:
            coord_lbl = QLabel(f"📍 {coords[0]:.4f}, {coords[1]:.4f}")
            coord_lbl.setStyleSheet(f"color:{COLORS['text_subtle']};font-size:11px;background:transparent;border:none;")
            layout.addWidget(coord_lbl)

        actions = QHBoxLayout()
        actions.setSpacing(8)
        
        map_btn = QPushButton("Locate")
        map_btn.setFixedHeight(30)
        map_btn.setStyleSheet(f"""
            QPushButton {{
                background: rgba(255,255,255,0.07);
                color: {COLORS['sand']};
                border: none;
                border-radius: 8px;
                padding: 0 14px;
                font-size: 12px;
                font-weight: 600;
            }}
            QPushButton:hover {{
                background: rgba(255,255,255,0.14);
            }}
        """)
        lat, lon = fav.get("lat", 0), fav.get("lon", 0)
        name_text = fav.get("name", "")
        map_btn.clicked.connect(lambda: self.view_map_clicked.emit(lat, lon, name_text))
        actions.addWidget(map_btn)

        del_btn = QPushButton("Remove")
        del_btn.setFixedHeight(30)
        del_btn.setStyleSheet(f"""
            QPushButton {{
                background: rgba(248,113,113,0.10);
                color: {COLORS['danger']};
                border: none;
                border-radius: 8px;
                padding: 0 14px;
                font-size: 12px;
                font-weight: 600;
            }}
            QPushButton:hover {{
                background: {COLORS['danger']};
                color: #ffffff;
            }}
        """)
        del_btn.clicked.connect(lambda: self.delete_clicked.emit(self._id))
        actions.addWidget(del_btn)
        actions.addStretch()
        layout.addLayout(actions)


class FavoritesScreen(QWidget):
    """Favorites screen — "Your Saved World" collection."""

    navigate_map = Signal(float, float, str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._build_ui()
        self.refresh()

    def _build_ui(self) -> None:
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        splitter = QSplitter(Qt.Horizontal)
        splitter.setStyleSheet("QSplitter::handle{background:transparent;}")

        # Left list panel
        left = QWidget()
        left.setStyleSheet(f"background:{COLORS['bg_deep']};")
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(28, 28, 28, 28)
        left_layout.setSpacing(20)

        hdr = QHBoxLayout()
        title_v = QVBoxLayout()
        title_v.setSpacing(4)
        title = QLabel("Your Saved World")
        title.setStyleSheet(f"color:{COLORS['text']};font-size:{FONT['2xl']};font-weight:900;letter-spacing:-1px;background:transparent;border:none;")
        title_v.addWidget(title)

        self._count_lbl = QLabel("0 saved places")
        self._count_lbl.setStyleSheet(f"color:{COLORS['text_muted']};font-size:{FONT['base']};background:transparent;border:none;")
        title_v.addWidget(self._count_lbl)
        hdr.addLayout(title_v)
        left_layout.addLayout(hdr)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setStyleSheet("background:transparent;")
        self._list_w = QWidget()
        self._list_w.setStyleSheet("background:transparent;")
        self._list_layout = QVBoxLayout(self._list_w)
        self._list_layout.setContentsMargins(0, 0, 0, 0)
        self._list_layout.setSpacing(12)
        scroll.setWidget(self._list_w)
        left_layout.addWidget(scroll, 1)

        splitter.addWidget(left)

        # Right map view
        self._map = MapView()
        splitter.addWidget(self._map)
        splitter.setSizes([450, 550])

        layout.addWidget(splitter)

    def refresh(self) -> None:
        while self._list_layout.count():
            item = self._list_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        favs = favorites_repo.get_all()
        self._count_lbl.setText(f"{len(favs)} saved place{'s' if len(favs) != 1 else ''}")
        self._map.clear_all()

        if not favs:
            empty = EmptyStateWidget("♡", "No saved places yet",
                                     "Explore the map or places and click Save to build your personal collection.")
            self._list_layout.addWidget(empty)
            return

        coords = []
        for fav in favs:
            card = FavoriteCard(fav)
            card.delete_clicked.connect(self._delete)
            card.view_map_clicked.connect(self._on_view_map)
            self._list_layout.addWidget(card)
            if fav.get("lat") and fav.get("lon"):
                self._map.add_marker(fav["lat"], fav["lon"], fav["name"],
                                     fav.get("category", ""), fav.get("description", ""),
                                     0, "main")
                coords.append([fav["lat"], fav["lon"]])

        self._list_layout.addStretch()

        if len(coords) > 1:
            self._map.fit_bounds(coords)
        elif len(coords) == 1:
            self._map.center(coords[0][0], coords[0][1], 12)

    def _delete(self, fav_id: int) -> None:
        favorites_repo.delete(fav_id)
        self.refresh()

    def _on_view_map(self, lat: float, lon: float, name: str) -> None:
        self._map.center(lat, lon, 14)
        self.navigate_map.emit(lat, lon, name)
