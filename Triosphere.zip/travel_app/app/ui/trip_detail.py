"""
Trip Detail screen — map route, stops, itinerary, expense summary.
"""
from __future__ import annotations
import logging
from datetime import date

from PySide6.QtCore    import Qt, Signal, Slot, QThread, QObject
from PySide6.QtWidgets import (
    QDialog, QDialogButtonBox, QFormLayout, QHBoxLayout, QLabel,
    QLineEdit, QPushButton, QScrollArea, QSizePolicy, QSplitter,
    QTimeEdit, QVBoxLayout, QWidget, QTextEdit, QDoubleSpinBox, QDateEdit, QFrame
)
from app.config import COLORS, FONT, DEFAULT_CURRENCY
from app.services.trip_service  import trip_service
from app.services.expense_service import expense_service
from app.map.map_view import MapView
from app.ui.widgets.cards import ExpenseCard

logger = logging.getLogger(__name__)


class _TripRouteRelay(QObject):
    """Main-thread relay to safely deliver route calculation results to the UI thread."""
    route_ready = Signal(dict)

    def __init__(self, parent=None):
        super().__init__(parent)

    @Slot(dict)
    def on_worker_finished(self, result: dict):
        self.route_ready.emit(result)


class TripRouteWorker(QObject):
    finished = Signal(object)

    def __init__(self, coords: list[list[float]]):
        super().__init__()
        self.coords = coords

    def run(self):
        try:
            from app.api.routing import routing_service
            logger.info("[API request started] Trip route with %d stops", len(self.coords))
            result = routing_service.get_multi_route(
                [(coord[0], coord[1]) for coord in self.coords]
            )
            logger.info("[API response received] Trip route completed")
            self.finished.emit(result)
        except Exception as exc:
            logger.error("[API error] Trip route failed: %s", exc)
            self.finished.emit({"error": str(exc), "geometry": [], "distance_km": 0, "duration_str": "—"})


def _lbl(text, style=""):
    l = QLabel(text)
    l.setStyleSheet(style or f"color: {COLORS['text_muted']}; font-size: {FONT['sm']}; background: transparent;")
    return l


class AddStopDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Add Stop")
        self.setModal(True)
        self.setMinimumWidth(380)
        self.setStyleSheet(f"QDialog {{ background: {COLORS['bg_dark']}; border: 1px solid {COLORS['border']}; border-radius: 14px; }}")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(14)
        layout.addWidget(QLabel("Add a Stop", styleSheet=f"color:{COLORS['text']}; font-size:{FONT['lg']}; font-weight:800;"))
        form = QFormLayout()
        self._place = QLineEdit(); self._place.setPlaceholderText("City or place name")
        self._lat   = QLineEdit(); self._lat.setPlaceholderText("Latitude (optional)")
        self._lon   = QLineEdit(); self._lon.setPlaceholderText("Longitude (optional)")
        self._nights= QDoubleSpinBox(); self._nights.setMinimum(0); self._nights.setMaximum(30); self._nights.setValue(1)
        form.addRow("Place *", self._place)
        form.addRow("Latitude", self._lat)
        form.addRow("Longitude", self._lon)
        form.addRow("Nights", self._nights)
        layout.addLayout(form)
        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btns.button(QDialogButtonBox.Ok).setText("Add Stop")
        btns.button(QDialogButtonBox.Ok).setStyleSheet(f"background:{COLORS['accent']};color:#fff;border-radius:8px;padding:7px 18px;font-weight:700;")
        btns.button(QDialogButtonBox.Cancel).setStyleSheet(f"background:{COLORS['bg_card']};color:{COLORS['text_muted']};border:1px solid {COLORS['border']};border-radius:8px;padding:7px 18px;")
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)

    def get_data(self):
        try: lat = float(self._lat.text()) if self._lat.text().strip() else None
        except: lat = None
        try: lon = float(self._lon.text()) if self._lon.text().strip() else None
        except: lon = None
        return {"place_name": self._place.text().strip(), "lat": lat, "lon": lon,
                "nights": int(self._nights.value())}


class AddExpenseDialog(QDialog):
    def __init__(self, trip_id: int, parent=None):
        super().__init__(parent)
        self._trip_id = trip_id
        self.setWindowTitle("Add Expense")
        self.setModal(True)
        self.setMinimumWidth(380)
        self.setStyleSheet(f"QDialog {{ background: {COLORS['bg_dark']}; border: 1px solid {COLORS['border']}; border-radius: 14px; }}")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(14)
        layout.addWidget(QLabel("Add Expense 💳", styleSheet=f"color:{COLORS['text']}; font-size:{FONT['lg']}; font-weight:800;"))
        from PySide6.QtWidgets import QComboBox
        form = QFormLayout()
        self._cat   = QComboBox()
        from app.config import EXPENSE_CATEGORIES
        self._cat.addItems(EXPENSE_CATEGORIES)
        self._amount= QDoubleSpinBox(); self._amount.setMinimum(0); self._amount.setMaximum(10_000_000)
        self._amount.setPrefix("₹ "); self._amount.setGroupSeparatorShown(True)
        self._desc  = QLineEdit(); self._desc.setPlaceholderText("Description")
        self._date  = QDateEdit(); self._date.setDate(date.today()); self._date.setCalendarPopup(True)
        self._pay   = QComboBox()
        self._pay.addItems(["Cash", "Card", "UPI", "Net Banking", "Other"])
        form.addRow("Category", self._cat)
        form.addRow("Amount", self._amount)
        form.addRow("Description", self._desc)
        form.addRow("Date", self._date)
        form.addRow("Payment", self._pay)
        layout.addLayout(form)
        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btns.button(QDialogButtonBox.Ok).setText("Add Expense")
        btns.button(QDialogButtonBox.Ok).setStyleSheet(f"background:{COLORS['accent']};color:#fff;border-radius:8px;padding:7px 18px;font-weight:700;")
        btns.button(QDialogButtonBox.Cancel).setStyleSheet(f"background:{COLORS['bg_card']};color:{COLORS['text_muted']};border:1px solid {COLORS['border']};border-radius:8px;padding:7px 18px;")
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)

    def get_data(self):
        return {
            "trip_id":        self._trip_id,
            "category":       self._cat.currentText(),
            "amount":         self._amount.value(),
            "description":    self._desc.text().strip(),
            "date":           self._date.date().toString("yyyy-MM-dd"),
            "payment_method": self._pay.currentText(),
            "currency":       "INR",
            "currency_sym":   "₹",
        }


class TripDetailScreen(QWidget):
    """Full trip detail: map + stops + expenses + itinerary."""

    back_clicked = Signal()

    def __init__(self, trip_id: int, parent=None):
        super().__init__(parent)
        self._trip_id = trip_id
        self._route_thread: QThread | None = None
        self._build_ui()
        self.refresh()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Top bar
        bar = QFrame()
        bar.setStyleSheet(f"background: {COLORS['bg_dark']}; border-bottom: 1px solid {COLORS['border']};")
        bar_layout = QHBoxLayout(bar)
        bar_layout.setContentsMargins(20, 12, 20, 12)

        back = QPushButton("← Back")
        back.setStyleSheet(f"background:transparent;color:{COLORS['accent_alt']};border:none;font-size:{FONT['base']};font-weight:600;")
        back.clicked.connect(self.back_clicked)
        bar_layout.addWidget(back)

        self._trip_title = QLabel("Trip Detail")
        self._trip_title.setStyleSheet(f"color:{COLORS['text']};font-size:{FONT['xl']};font-weight:800;background:transparent;")
        bar_layout.addWidget(self._trip_title, 1)

        self._add_expense_btn = QPushButton("+ Add Expense")
        self._add_expense_btn.setStyleSheet(f"background:{COLORS['accent']};color:#fff;border:none;border-radius:10px;padding:8px 18px;font-weight:700;")
        self._add_expense_btn.clicked.connect(self._add_expense)
        bar_layout.addWidget(self._add_expense_btn)

        add_stop_btn = QPushButton("+ Stop")
        add_stop_btn.setStyleSheet(f"background:{COLORS['success_bg']};color:{COLORS['success']};border:1px solid {COLORS['success']};border-radius:10px;padding:8px 16px;font-weight:700;")
        add_stop_btn.clicked.connect(self._add_stop)
        bar_layout.addWidget(add_stop_btn)

        self._complete_btn = QPushButton("✓ Complete")
        self._complete_btn.setStyleSheet(
            "background: rgba(34,197,94,0.15); color: #22c55e;"
            "border: 1px solid rgba(34,197,94,0.40); border-radius: 10px;"
            "padding: 8px 16px; font-weight: 700;"
        )
        self._complete_btn.clicked.connect(self._complete_journey)
        bar_layout.addWidget(self._complete_btn)

        remove_btn = QPushButton("🗑 Remove")
        remove_btn.setStyleSheet(
            "background: rgba(239,68,68,0.12); color: #ef4444;"
            "border: 1px solid rgba(239,68,68,0.35); border-radius: 10px;"
            "padding: 8px 16px; font-weight: 700;"
        )
        remove_btn.clicked.connect(self._remove_journey)
        bar_layout.addWidget(remove_btn)

        layout.addWidget(bar)

        # Content: splitter with map + details
        splitter = QSplitter(Qt.Horizontal)
        splitter.setStyleSheet("QSplitter::handle{background:transparent;}")

        # Left: route + expenses + stats
        left = QWidget()
        left.setStyleSheet(f"background:{COLORS['bg_dark']};")
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(20, 20, 20, 20)
        left_layout.setSpacing(16)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("background:transparent;border:none;")
        self._content = QWidget()
        self._content.setStyleSheet("background:transparent;")
        self._content_layout = QVBoxLayout(self._content)
        self._content_layout.setContentsMargins(0,0,0,0)
        self._content_layout.setSpacing(14)
        self._content_layout.addStretch()
        scroll.setWidget(self._content)
        left_layout.addWidget(scroll)

        splitter.addWidget(left)

        # Right: map
        self._map = MapView()
        splitter.addWidget(self._map)
        splitter.setSizes([400, 600])

        layout.addWidget(splitter, 1)

    def refresh(self) -> None:
        trip = trip_service.get_trip(self._trip_id)
        if not trip:
            return

        self._trip_title.setText(trip.get("name", "Trip"))

        # Clear content
        while self._content_layout.count() > 1:
            item = self._content_layout.takeAt(0)
            if item.widget(): item.widget().deleteLater()

        self._map.clear_all()
        sym = trip.get("currency_sym", DEFAULT_CURRENCY)

        # ── Budget overview ────────────────────────────────────────────────
        budget  = trip.get("budget", 0) or 0
        spent   = trip.get("spent", 0) or 0
        remain  = budget - spent
        pct     = min((spent / budget * 100) if budget > 0 else 0, 100)
        fill_color = COLORS["success"] if pct < 70 else (COLORS["warning"] if pct < 90 else COLORS["danger"])

        budget_card = self._section_card("💰 Budget")
        bc_layout   = budget_card.layout()

        brow = QHBoxLayout()
        for label, value, color in [
            ("Budget", f"{sym}{budget:,.0f}", COLORS["text"]),
            ("Spent",  f"{sym}{spent:,.0f}",  fill_color),
            ("Left",   f"{sym}{remain:,.0f}",  COLORS["success"]),
        ]:
            col = QVBoxLayout()
            col.addWidget(QLabel(label, styleSheet=f"color:{COLORS['text_muted']};font-size:{FONT['xs']};background:transparent;"))
            col.addWidget(QLabel(value, styleSheet=f"color:{color};font-size:{FONT['lg']};font-weight:800;background:transparent;"))
            brow.addLayout(col)
            if label != "Left":
                brow.addWidget(QFrame(frameShape=QFrame.VLine, styleSheet=f"color:{COLORS['border']};"))
        bc_layout.addLayout(brow)

        # Progress bar
        prog_bg = QFrame()
        prog_bg.setFixedHeight(8)
        prog_bg.setStyleSheet(f"background:{COLORS['bg_dark']};border-radius:4px;border:none;")
        if pct > 0:
            fill = QFrame(prog_bg)
            fill.setFixedHeight(8)
            fill.setStyleSheet(f"background:{fill_color};border-radius:4px;border:none;")
            fill.setFixedWidth(max(6, int(prog_bg.width() * pct / 100)))
            prog_bg.resizeEvent = lambda e, f=fill, p=pct: f.setFixedWidth(
                max(6, int(prog_bg.width() * p / 100)))
        bc_layout.addWidget(prog_bg)
        pct_lbl = QLabel(f"{pct:.1f}% used")
        pct_lbl.setStyleSheet(f"color:{fill_color};font-size:{FONT['xs']};font-weight:600;background:transparent;")
        bc_layout.addWidget(pct_lbl)
        self._insert(budget_card)

        # ── Stops & route ─────────────────────────────────────────────────
        stops = trip.get("stops", [])
        route_card = self._section_card("🗺 Route & Stops")
        rc_layout  = route_card.layout()

        coords = []
        for i, stop in enumerate(stops):
            stop_row = QHBoxLayout()
            idx_lbl = QLabel(f"{i+1}")
            idx_lbl.setFixedSize(28, 28)
            idx_lbl.setAlignment(Qt.AlignCenter)
            idx_lbl.setStyleSheet(f"background:{COLORS['accent']};color:#fff;border-radius:14px;font-weight:700;font-size:12px;")
            stop_row.addWidget(idx_lbl)
            name_lbl = QLabel(stop.get("place_name", ""))
            name_lbl.setStyleSheet(f"color:{COLORS['text']};font-size:{FONT['base']};font-weight:600;background:transparent;")
            stop_row.addWidget(name_lbl, 1)
            nights = stop.get("nights", 0)
            if nights:
                n_lbl = QLabel(f"{nights}n")
                n_lbl.setStyleSheet(f"color:{COLORS['text_muted']};font-size:{FONT['sm']};background:transparent;")
                stop_row.addWidget(n_lbl)
            del_btn = QPushButton("✕")
            del_btn.setFixedSize(24, 24)
            del_btn.setStyleSheet(f"background:{COLORS['danger_bg']};color:{COLORS['danger']};border:none;border-radius:12px;font-size:11px;")
            del_btn.clicked.connect(lambda _, sid=stop["id"]: self._delete_stop(sid))
            stop_row.addWidget(del_btn)
            rc_layout.addLayout(stop_row)

            lat, lon = stop.get("lat"), stop.get("lon")
            if lat and lon:
                coords.append([lat, lon])
                self._map.add_stop_marker(lat, lon, stop.get("place_name",""), i)

            if i < len(stops) - 1:
                arrow = QLabel("↓")
                arrow.setAlignment(Qt.AlignCenter)
                arrow.setStyleSheet(f"color:{COLORS['accent_alt']};font-size:18px;background:transparent;")
                rc_layout.addWidget(arrow)

        if len(coords) >= 2:
            self._start_route_request(coords, rc_layout)
        self._insert(route_card)

        # ── Expenses ──────────────────────────────────────────────────────
        expenses = trip.get("expenses", [])
        if expenses:
            exp_card = self._section_card(f"💳 Expenses ({len(expenses)})")
            for exp in expenses[-5:]:  # show latest 5
                ec = ExpenseCard(exp)
                ec.delete_requested.connect(self._delete_expense)
                exp_card.layout().addWidget(ec)
            self._insert(exp_card)

        # ── Category breakdown ────────────────────────────────────────────
        breakdown = trip.get("category_breakdown", {})
        if breakdown:
            bk_card = self._section_card("📊 By Category")
            bl = bk_card.layout()
            for cat, amt in sorted(breakdown.items(), key=lambda x: -x[1]):
                row = QHBoxLayout()
                from app.services.expense_service import CATEGORY_COLORS
                color = CATEGORY_COLORS.get(cat, "#94A3B8")
                dot = QLabel("●")
                dot.setStyleSheet(f"color:{color};font-size:14px;background:transparent;")
                row.addWidget(dot)
                c_lbl = QLabel(cat)
                c_lbl.setStyleSheet(f"color:{COLORS['text']};font-size:{FONT['sm']};background:transparent;")
                row.addWidget(c_lbl, 1)
                a_lbl = QLabel(f"{sym}{amt:,.0f}")
                a_lbl.setStyleSheet(f"color:{COLORS['accent_alt']};font-size:{FONT['sm']};font-weight:700;background:transparent;")
                row.addWidget(a_lbl)
                bl.addLayout(row)
            self._insert(bk_card)

    def _start_route_request(self, coords: list[list[float]], layout: QVBoxLayout) -> None:
        if self._route_thread and self._route_thread.isRunning():
            logger.info("[action started] Replacing trip route request")
            self._route_thread.quit()
            self._route_thread.wait(500)

        worker = TripRouteWorker(coords)
        thread = QThread(self)
        thread._worker = worker
        worker.moveToThread(thread)

        relay = _TripRouteRelay(self)
        thread._relay = relay

        thread.started.connect(worker.run)
        worker.finished.connect(relay.on_worker_finished)
        relay.route_ready.connect(lambda result: self._on_route_result(result, coords, layout))

        worker.finished.connect(thread.quit)
        worker.finished.connect(worker.deleteLater)
        thread.finished.connect(relay.deleteLater)
        thread.finished.connect(thread.deleteLater)
        thread.finished.connect(lambda: setattr(self, "_route_thread", None))
        self._route_thread = thread
        thread.start()

    def _on_route_result(self, result: dict, coords: list[list[float]], layout: QVBoxLayout) -> None:
        if result.get("error"):
            logger.error("[API error] Trip route response: %s", result["error"])
            return
        self._map.draw_route(result.get("geometry", coords))
        dist_lbl = QLabel(f"📏 Total: {result.get('distance_km', 0):.1f} km  •  ⏱ {result.get('duration_str', '—')}")
        dist_lbl.setStyleSheet(f"color:{COLORS['accent_alt']};font-size:{FONT['sm']};font-weight:600;background:transparent;")
        layout.addWidget(dist_lbl)
        self._map.fit_bounds(coords)

    def cleanup(self) -> None:
        """Safely wait for any running route calculation thread before closing."""
        if self._route_thread and self._route_thread.isRunning():
            self._route_thread.quit()
            self._route_thread.wait(500)

    def closeEvent(self, event) -> None:
        self.cleanup()
        super().closeEvent(event)

    def _section_card(self, title: str) -> QFrame:
        card = QFrame()
        card.setStyleSheet(f"QFrame{{background:{COLORS['bg_card']};border:1px solid {COLORS['border']};border-radius:14px;}}")
        layout = QVBoxLayout(card)
        layout.setContentsMargins(16, 14, 16, 14)
        layout.setSpacing(10)
        t = QLabel(title)
        t.setStyleSheet(f"color:{COLORS['text']};font-size:{FONT['base']};font-weight:700;background:transparent;")
        layout.addWidget(t)
        return card

    def _insert(self, widget: QWidget) -> None:
        self._content_layout.insertWidget(self._content_layout.count() - 1, widget)

    def _add_stop(self) -> None:
        dlg = AddStopDialog(self)
        if dlg.exec() == QDialog.Accepted:
            data = dlg.get_data()
            if data.get("place_name"):
                trip_service.add_stop(self._trip_id, data)
                self.refresh()

    def _delete_stop(self, stop_id: int) -> None:
        from app.database.repositories import trip_stop_repo
        trip_stop_repo.delete(stop_id)
        self.refresh()

    def _add_expense(self) -> None:
        dlg = AddExpenseDialog(self._trip_id, self)
        if dlg.exec() == QDialog.Accepted:
            data = dlg.get_data()
            if data.get("amount", 0) > 0:
                expense_service.add_expense(data)
                self.refresh()

    def _delete_expense(self, expense_id: int) -> None:
        expense_service.delete_expense(expense_id)
        self.refresh()

    def _complete_journey(self) -> None:
        """Mark the trip as completed and update button state."""
        from app.database.repositories import trip_repo
        trip = trip_repo.get_by_id(self._trip_id)
        if not trip:
            return
        trip_data = dict(trip)
        current_status = trip_data.get("status", "planned")
        new_status = "planned" if current_status == "completed" else "completed"
        trip_repo.update(self._trip_id, {**trip_data, "status": new_status})
        # Toggle button label to reflect state
        if new_status == "completed":
            self._complete_btn.setText("↩ Reopen")
            self._complete_btn.setStyleSheet(
                "background: rgba(99,102,241,0.15); color: #818cf8;"
                "border: 1px solid rgba(99,102,241,0.40); border-radius: 10px;"
                "padding: 8px 16px; font-weight: 700;"
            )
        else:
            self._complete_btn.setText("✓ Complete")
            self._complete_btn.setStyleSheet(
                "background: rgba(34,197,94,0.15); color: #22c55e;"
                "border: 1px solid rgba(34,197,94,0.40); border-radius: 10px;"
                "padding: 8px 16px; font-weight: 700;"
            )

    def _remove_journey(self) -> None:
        """Delete the trip after confirmation and navigate back."""
        from PySide6.QtWidgets import QMessageBox
        from app.database.repositories import trip_repo
        reply = QMessageBox.question(
            self, "Remove Journey",
            "Are you sure you want to permanently delete this journey?\nThis cannot be undone.",
            QMessageBox.Yes | QMessageBox.Cancel,
            QMessageBox.Cancel
        )
        if reply == QMessageBox.Yes:
            trip_repo.delete(self._trip_id)
            self.back_clicked.emit()
