"""
Travel Journal screen — photo diary grid with detail view, mood tags, and memories.
"""
from __future__ import annotations
import logging
from datetime import date
from pathlib import Path

from PySide6.QtCore    import Qt, Signal
from PySide6.QtGui     import QPixmap
from PySide6.QtWidgets import (
    QComboBox, QDateEdit, QDialog, QDialogButtonBox, QFileDialog,
    QFormLayout, QFrame, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QScrollArea, QSizePolicy, QTextEdit, QVBoxLayout, QWidget
)
from app.config import COLORS, FONT, MOODS
from app.database.repositories import trip_repo
from app.services.journal_service import journal_service
from app.ui.widgets.cards import JournalCard
from app.ui.widgets.loading import EmptyStateWidget

logger = logging.getLogger(__name__)


class InlineJournalForm(QFrame):
    """Inline expanding form for adding a journal entry with smooth height animation."""

    entry_created = Signal(dict)
    cancelled = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMaximumHeight(0)
        self._image_path = ""
        self.setStyleSheet(f"""
            InlineJournalForm {{
                background: #14141A;
                border-radius: 20px;
                border: 1px solid rgba(212, 169, 106, 0.25);
            }}
        """)
        self._build_ui()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(16)

        hdr = QLabel("New Memory Entry 📔")
        hdr.setStyleSheet(f"color:{COLORS['text']};font-size:{FONT['lg']};font-weight:800;border:none;")
        layout.addWidget(hdr)

        form = QFormLayout()
        form.setSpacing(12)

        self._title = QLineEdit()
        self._title.setPlaceholderText("Give your memory a title…")

        self._date = QDateEdit()
        self._date.setDate(date.today())
        self._date.setCalendarPopup(True)

        self._loc = QLineEdit()
        self._loc.setPlaceholderText("e.g. Baga Beach, Goa")

        self._mood = QComboBox()
        self._mood.addItems(MOODS)

        self._desc = QLineEdit()
        self._desc.setPlaceholderText("Write about your experience, feelings, highlights…")

        form.addRow("Title *", self._title)
        form.addRow("Date", self._date)
        form.addRow("Location", self._loc)
        form.addRow("Mood", self._mood)
        form.addRow("Description", self._desc)
        layout.addLayout(form)

        btn_row = QHBoxLayout()
        btn_row.addStretch()

        cancel_btn = QPushButton("Cancel")
        cancel_btn.setStyleSheet(f"QPushButton{{background:rgba(255,255,255,0.06);color:{COLORS['text_muted']};border:none;border-radius:10px;padding:8px 20px;}}QPushButton:hover{{background:rgba(255,255,255,0.12);}}")
        cancel_btn.clicked.connect(self.cancelled.emit)
        btn_row.addWidget(cancel_btn)

        save_btn = QPushButton("Save Entry")
        save_btn.setStyleSheet(f"QPushButton{{background:{COLORS['accent']};color:#111;border:none;border-radius:10px;padding:8px 22px;font-weight:700;}}QPushButton:hover{{background:{COLORS['accent_light']};}}")
        save_btn.clicked.connect(self._submit)
        btn_row.addWidget(save_btn)

        layout.addLayout(btn_row)

    def _submit(self):
        data = {
            "title":       self._title.text().strip() or "Untitled Memory",
            "date":        self._date.date().toString("yyyy-MM-dd"),
            "location":    self._loc.text().strip(),
            "mood":        self._mood.currentText(),
            "trip_id":     None,
            "description": self._desc.text().strip(),
            "image_path":  self._image_path,
        }
        self.entry_created.emit(data)


class JournalDetailWidget(QWidget):
    """Full-screen detail view for a single journal entry."""

    close_clicked = Signal()

    def __init__(self, entry: dict, parent=None):
        super().__init__(parent)
        self.setStyleSheet(f"background:{COLORS['bg_dark']};")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(48, 40, 48, 40)
        layout.setSpacing(20)

        # Back button
        back = QPushButton("← Back to Journal")
        back.setStyleSheet(f"background:transparent;color:{COLORS['accent']};border:none;font-size:{FONT['base']};font-weight:700;")
        back.clicked.connect(self.close_clicked)
        layout.addWidget(back, alignment=Qt.AlignLeft)

        # Title & mood
        hdr = QHBoxLayout()
        t = QLabel(entry.get("title", "Untitled"))
        t.setStyleSheet(f"color:{COLORS['text']};font-size:{FONT['3xl']};font-weight:900;letter-spacing:-1px;background:transparent;border:none;")
        hdr.addWidget(t, 1)

        mood = entry.get("mood", "")
        if mood:
            m_lbl = QLabel(mood.upper())
            m_lbl.setStyleSheet(f"color:{COLORS['sand']};font-size:12px;font-weight:800;letter-spacing:1px;background:rgba(255,255,255,0.06);border-radius:8px;padding:6px 14px;border:none;")
            hdr.addWidget(m_lbl)
        layout.addLayout(hdr)

        # Meta
        meta_parts = []
        if entry.get("date"):        meta_parts.append(f"📅 {entry['date']}")
        if entry.get("location"):    meta_parts.append(f"📍 {entry['location']}")
        meta = QLabel("   •   ".join(meta_parts))
        meta.setStyleSheet(f"color:{COLORS['text_muted']};font-size:{FONT['base']};background:transparent;border:none;")
        layout.addWidget(meta)

        # Photo
        if entry.get("image_path") and Path(entry["image_path"]).exists():
            pix = QPixmap(entry["image_path"]).scaledToWidth(700, Qt.SmoothTransformation)
            img_lbl = QLabel()
            img_lbl.setPixmap(pix)
            img_lbl.setStyleSheet("border-radius:18px;border:none;")
            img_lbl.setAlignment(Qt.AlignCenter)
            layout.addWidget(img_lbl)

        # Description
        desc = QLabel(entry.get("description", ""))
        desc.setWordWrap(True)
        desc.setStyleSheet(f"color:{COLORS['text']};font-size:{FONT['md']};line-height:1.7;background:transparent;border:none;")
        layout.addWidget(desc)
        layout.addStretch()


class JournalScreen(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._form_expanded = False
        self._build_ui()
        self.refresh()

    def _build_ui(self) -> None:
        self._stack_layout = QVBoxLayout(self)
        self._stack_layout.setContentsMargins(0, 0, 0, 0)
        self._stack_layout.setSpacing(0)

        # List view
        self._list_view = QWidget()
        self._list_view.setStyleSheet("background:transparent;")
        list_layout = QVBoxLayout(self._list_view)
        list_layout.setContentsMargins(36, 36, 36, 36)
        list_layout.setSpacing(20)

        hdr = QHBoxLayout()
        title_v = QVBoxLayout()
        title_v.setSpacing(4)
        title = QLabel("Travel Journal")
        title.setStyleSheet(f"color:{COLORS['text']};font-size:{FONT['3xl']};font-weight:900;letter-spacing:-1px;background:transparent;border:none;")
        title_v.addWidget(title)

        sub = QLabel("Your personal photo diary of moments, thoughts, and travel memories")
        sub.setStyleSheet(f"color:{COLORS['text_muted']};font-size:{FONT['base']};background:transparent;border:none;")
        title_v.addWidget(sub)
        hdr.addLayout(title_v)
        hdr.addStretch()

        self._new_btn = QPushButton("+  New Entry")
        self._new_btn.setFixedHeight(44)
        self._new_btn.setStyleSheet(f"background:{COLORS['accent']};color:#111;border:none;border-radius:14px;padding:0 24px;font-size:{FONT['base']};font-weight:700;")
        self._new_btn.clicked.connect(self._toggle_form)
        hdr.addWidget(self._new_btn)
        list_layout.addLayout(hdr)

        # Inline Expandable Form Container
        self._inline_form = InlineJournalForm()
        self._inline_form.entry_created.connect(self._on_entry_created)
        self._inline_form.cancelled.connect(lambda: self._animate_form(False))
        list_layout.addWidget(self._inline_form)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setStyleSheet("background:transparent;")
        
        self._grid_widget = QWidget()
        self._grid_widget.setStyleSheet("background:transparent;")
        self._grid_layout = QVBoxLayout(self._grid_widget)
        self._grid_layout.setContentsMargins(0, 0, 0, 0)
        self._grid_layout.setSpacing(16)
        scroll.setWidget(self._grid_widget)
        list_layout.addWidget(scroll, 1)

        self._stack_layout.addWidget(self._list_view)
        self._detail_view: JournalDetailWidget | None = None

    def _toggle_form(self):
        self._animate_form(not self._form_expanded)

    def _animate_form(self, expand: bool):
        from PySide6.QtCore import QPropertyAnimation, QEasingCurve
        self._form_expanded = expand
        anim = QPropertyAnimation(self._inline_form, b"maximumHeight", self)
        anim.setDuration(320)
        anim.setEasingCurve(QEasingCurve.OutCubic if expand else QEasingCurve.InCubic)
        anim.setStartValue(self._inline_form.maximumHeight())
        anim.setEndValue(380 if expand else 0)
        anim.start()

    def _on_entry_created(self, data: dict):
        if data.get("title"):
            journal_service.create_entry(data)
            self._animate_form(False)
            self.refresh()

    def refresh(self) -> None:
        while self._grid_layout.count():
            item = self._grid_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        entries = journal_service.get_all()
        if not entries:
            empty = EmptyStateWidget("◇", "No travel memories yet",
                                     "Save your first journal entry to start your photo diary.",
                                     button_text="Write First Entry")
            if empty.cta_button:
                empty.cta_button.clicked.connect(self._toggle_form)
            self._grid_layout.addWidget(empty)
            return

        for entry in entries:
            card = JournalCard(entry)
            card.clicked.connect(self._open_entry)
            self._grid_layout.addWidget(card)

        self._grid_layout.addStretch()


    def _open_entry(self, entry_id: int) -> None:
        entry = journal_service.get_entry(entry_id)
        if not entry:
            return
        if self._detail_view:
            self._detail_view.deleteLater()
        self._detail_view = JournalDetailWidget(entry)
        self._detail_view.close_clicked.connect(self._close_detail)
        self._list_view.hide()
        self._stack_layout.addWidget(self._detail_view)

    def _close_detail(self) -> None:
        if self._detail_view:
            self._detail_view.deleteLater()
            self._detail_view = None
        self._list_view.show()
        self.refresh()
