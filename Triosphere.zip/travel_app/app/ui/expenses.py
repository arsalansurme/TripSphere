"""
Expenses screen — travel spending overview, add/delete expenses, category splits.
Matches mockup design with:
- Lifetime Financial Overview text & circular stats pills
- Dynamic budget progress card with dynamic cover image of chosen trip context
- Animated category split card (expands/shrinks on click)
- Recent Expenses list
"""
from __future__ import annotations

import logging
from datetime import date, datetime
from PySide6.QtCore import Qt, Signal, QRect, QPropertyAnimation, QEasingCurve
from PySide6.QtGui import QPixmap, QPainter, QPainterPath, QLinearGradient, QColor, QPen, QFont
from PySide6.QtWidgets import (
    QComboBox, QDateEdit, QDialog, QDoubleSpinBox, QFormLayout, QFrame,
    QHBoxLayout, QLabel, QLineEdit, QPushButton, QScrollArea, QVBoxLayout, QWidget, QSizePolicy
)
from app.config import COLORS, FONT, EXPENSE_CATEGORIES, EXPENSE_CATEGORY_ICONS, DEFAULT_CURRENCY, ASSETS_DIR
from app.database.repositories import expense_repo, trip_repo
from app.services.expense_service import expense_service
from app.ui.widgets.cards import ExpenseCard
from app.ui.widgets.loading import EmptyStateWidget

logger = logging.getLogger(__name__)

GLASS_CARD = "background: rgba(10,10,14,0.72); border: 1px solid rgba(255,255,255,0.07); border-radius: 20px;"


def _load_pix_raw(filename: str) -> QPixmap | None:
    p = ASSETS_DIR / filename
    if p.exists():
        pix = QPixmap(str(p))
        if not pix.isNull():
            return pix
    return None


# ── Category Split Card (Expandable) ──────────────────────────────────────────
class CategorySplitCard(QFrame):
    """Category Split Card with expand/collapse animations when clicked."""

    def __init__(self, trip_id: int, parent=None):
        super().__init__(parent)
        self._trip_id = trip_id
        self._expanded = False
        self.setCursor(Qt.PointingHandCursor)
        self.setFixedWidth(280)
        self.setStyleSheet("""
            CategorySplitCard {
                background: #111114;
                border-radius: 20px;
                border: 1px solid rgba(255,255,255,0.06);
            }
        """)

        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(18, 18, 18, 18)
        self.layout.setSpacing(12)

        # Title
        title_lbl = QLabel("Category Split")
        title_lbl.setStyleSheet("color: #FFFFFF; font-size: 13px; font-weight: 800; background: transparent;")
        self.layout.addWidget(title_lbl)

        # Donut Chart Space
        self._donut = QFrame()
        self._donut.setFixedSize(100, 100)
        self._donut.setStyleSheet("background: transparent;")
        self._donut.paintEvent = self._paint_donut

        donut_layout = QHBoxLayout()
        donut_layout.addStretch()
        donut_layout.addWidget(self._donut)
        donut_layout.addStretch()
        self.layout.addLayout(donut_layout)

        # Summary Category Items (First 2 categories)
        self._summary_lay = QVBoxLayout()
        self._summary_lay.setSpacing(6)
        self.layout.addLayout(self._summary_lay)

        # Details Category Items (Hidden by default, expands on click)
        self._details_container = QFrame()
        self._details_container.setMaximumHeight(0)
        self._details_container.setStyleSheet("background: transparent; border: none;")
        self._details_lay = QVBoxLayout(self._details_container)
        self._details_lay.setContentsMargins(0, 0, 0, 0)
        self._details_lay.setSpacing(6)
        self.layout.addWidget(self._details_container)

        self.refresh()

    def _paint_donut(self, event):
        painter = QPainter(self._donut)
        painter.setRenderHint(QPainter.Antialiasing)

        stats = self._get_stats()
        r = 74
        rect = QRect((100 - r) // 2, (100 - r) // 2, r, r)

        pen = QPen()
        pen.setWidth(8)
        pen.setCapStyle(Qt.FlatCap)

        total_amount = sum(val for val, _ in stats.values())
        start_angle = 90 * 16
        colors = ["#FDBA74", "#A78BFA", "#F87171", "#60A5FA", "#34D399"]

        if total_amount == 0:
            pen.setColor(QColor("rgba(255,255,255,0.1)"))
            painter.setPen(pen)
            painter.drawArc(rect, 0, 360 * 16)
        else:
            for idx, (cat, (val, color_idx)) in enumerate(stats.items()):
                color = colors[color_idx % len(colors)]
                pen.setColor(QColor(color))
                painter.setPen(pen)

                span_angle = int((val / total_amount) * 360 * 16)
                painter.drawArc(rect, start_angle, -span_angle)
                start_angle -= span_angle

        # Text in center
        painter.setPen(QColor("#FFFFFF"))
        font = QFont()
        font.setPixelSize(12)
        font.setBold(True)
        painter.setFont(font)
        painter.drawText(rect, Qt.AlignCenter, f"{len(stats)}\nCATS")

    def _get_stats(self) -> dict:
        expenses = expense_repo.get_recent(200)
        if self._trip_id != -1:
            expenses = [e for e in expenses if e.get("trip_id") == self._trip_id]

        stats = {}
        for idx, e in enumerate(expenses):
            cat = e.get("category", "Other")
            amt = e.get("amount", 0)
            if cat not in stats:
                stats[cat] = [0.0, len(stats)]
            stats[cat][0] += amt
        return stats

    def set_trip_id(self, trip_id: int):
        self._trip_id = trip_id
        self.refresh()

    def refresh(self):
        while self._summary_lay.count():
            item = self._summary_lay.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        while self._details_lay.count():
            item = self._details_lay.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        stats = self._get_stats()
        total_amount = sum(val for val, _ in stats.values())
        colors = ["#FDBA74", "#A78BFA", "#F87171", "#60A5FA", "#34D399"]

        sorted_stats = sorted(stats.items(), key=lambda x: x[1][0], reverse=True)

        for i, (cat, (val, color_idx)) in enumerate(sorted_stats):
            pct = int((val / total_amount * 100) if total_amount > 0 else 0)
            color = colors[color_idx % len(colors)]

            row = QWidget()
            row_lay = QHBoxLayout(row)
            row_lay.setContentsMargins(0, 0, 0, 0)

            bullet = QLabel("●")
            bullet.setStyleSheet(f"color: {color}; font-size: 13px; background: transparent;")
            row_lay.addWidget(bullet)

            name = QLabel(cat)
            name.setStyleSheet("color: #E4E4E7; font-size: 12px; font-weight: 600; background: transparent;")
            row_lay.addWidget(name)
            row_lay.addStretch()

            val_lbl = QLabel(f"{pct}%")
            val_lbl.setStyleSheet("color: #71717A; font-size: 11px; font-weight: 700; background: transparent;")
            row_lay.addWidget(val_lbl)

            if i < 2:
                self._summary_lay.addWidget(row)
            else:
                self._details_lay.addWidget(row)

        self.update()

    def mousePressEvent(self, event):
        self._toggle_expand()

    def _toggle_expand(self):
        self._expanded = not self._expanded
        anim = QPropertyAnimation(self._details_container, b"maximumHeight", self)
        anim.setDuration(240)
        anim.setEasingCurve(QEasingCurve.OutCubic if self._expanded else QEasingCurve.InCubic)
        anim.setStartValue(self._details_container.maximumHeight())
        h = self._details_lay.count() * 24
        anim.setEndValue(h if self._expanded else 0)
        anim.start()


# ── Trip Budget Card (Dynamic Image) ──────────────────────────────────────────
class TripBudgetCard(QFrame):
    """Dynamic trip budget card showing the selected trip's photo & budget details."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(480, 240)
        self.setStyleSheet("""
            TripBudgetCard {
                border-radius: 20px;
                background: #111114;
                border: 1px solid rgba(255,255,255,0.06);
            }
        """)

        # Status badge (top-left)
        self._status_badge = QLabel("IN PROGRESS", self)
        self._status_badge.setStyleSheet("""
            background: rgba(0,0,0,0.65);
            color: #FDBA74;
            font-size: 9px;
            font-weight: 800;
            letter-spacing: 1px;
            border-radius: 8px;
            padding: 4px 10px;
        """)
        self._status_badge.adjustSize()
        self._status_badge.move(20, 20)

        # Title
        self._title = QLabel("Trip Budget", self)
        self._title.setStyleSheet("""
            color: rgba(255,255,255,0.85);
            font-size: 13px;
            font-weight: 700;
            background: transparent;
        """)
        self._title.setFixedWidth(440)
        self._title.adjustSize()
        self._title.move(20, 116)

        # Amount progress
        self._amt = QLabel("₹0 / ₹0", self)
        self._amt.setStyleSheet("""
            color: #FFFFFF;
            font-size: 30px;
            font-weight: 900;
            background: transparent;
        """)
        self._amt.setFixedWidth(440)
        self._amt.adjustSize()
        self._amt.move(20, 132)

        # Remaining subtext
        self._remaining = QLabel("Remaining: ₹0", self)
        self._remaining.setStyleSheet("""
            color: #A1A1AA;
            font-size: 12px;
            font-weight: 600;
            background: transparent;
        """)
        self._remaining.setFixedWidth(240)
        self._remaining.adjustSize()
        self._remaining.move(20, 184)

        # % Spent text
        self._pct_spent = QLabel("0% SPENT", self)
        self._pct_spent.setStyleSheet(f"""
            color: {COLORS['sand']};
            font-size: 10px;
            font-weight: 800;
            letter-spacing: 0.8px;
            background: transparent;
        """)
        self._pct_spent.adjustSize()
        self._pct_spent.move(480 - 20 - self._pct_spent.width(), 184)

        # Progress bar
        self._bar_outer = QFrame(self)
        self._bar_outer.setFixedSize(440, 6)
        self._bar_outer.setStyleSheet("background: rgba(255,255,255,0.15); border-radius: 3px;")
        self._bar_outer.move(20, 210)

        self._bar_fill = QFrame(self._bar_outer)
        self._bar_fill.setFixedHeight(6)
        self._bar_fill.setStyleSheet(f"background: {COLORS['sand']}; border-radius: 3px;")

        self._pix = None

    def update_trip(self, trip: dict | None):
        if not trip:
            self._title.setText("General Budget")
            self._amt.setText("₹0")
            self._remaining.setText("Remaining: ₹0")
            self._pct_spent.setText("0% SPENT")
            self._bar_fill.setFixedWidth(0)
            self._pix = _load_pix_raw("goa_beach_sunset.jpg")
            self.update()
            return

        self._title.setText(f"{trip.get('name', 'Trip')} Budget")

        budget = trip.get("budget", 0) or 0
        spent = 0
        try:
            spent = expense_repo.get_total_spent(trip.get("id")) or 0
        except Exception:
            pass

        self._amt.setText(f"₹{spent:,.0f} / ₹{budget:,.0f}" if budget > 0 else f"₹{spent:,.0f}")

        rem = max(0, budget - spent)
        self._remaining.setText(f"Remaining: ₹{rem:,.0f}")

        pct = min(spent / budget if budget > 0 else 0.0, 1.0)
        self._pct_spent.setText(f"{int(pct*100)}% SPENT")
        self._pct_spent.adjustSize()
        self._pct_spent.move(480 - 20 - self._pct_spent.width(), 184)

        self._bar_fill.setFixedWidth(max(6, int(440 * pct)))

        # Load cover image dynamically!
        img_name = trip.get("cover_image", "goa_beach_sunset.jpg") or "goa_beach_sunset.jpg"
        from pathlib import Path
        if Path(img_name).is_absolute() and Path(img_name).exists():
            self._pix = QPixmap(img_name)
        else:
            self._pix = _load_pix_raw(img_name)
            if not self._pix:
                self._pix = _load_pix_raw("goa_beach_sunset.jpg")

        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setRenderHint(QPainter.SmoothPixmapTransform)
        path = QPainterPath()
        path.addRoundedRect(0, 0, self.width(), self.height(), 20, 20)
        painter.setClipPath(path)

        if self._pix and not self._pix.isNull():
            scaled = self._pix.scaled(self.width(), self.height(),
                                      Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
            painter.drawPixmap((self.width() - scaled.width()) // 2,
                               (self.height() - scaled.height()) // 2, scaled)
        else:
            painter.fillRect(self.rect(), QColor(24, 24, 30))

        # Bottom gradient overlay for readability
        grad = QLinearGradient(0, 0, 0, self.height())
        grad.setColorAt(0.0, QColor(0, 0, 0, 0))
        grad.setColorAt(0.4, QColor(0, 0, 0, 40))
        grad.setColorAt(1.0, QColor(0, 0, 0, 220))
        painter.fillRect(self.rect(), grad)


# ── Inline Expand Form ────────────────────────────────────────────────────────



class InlineExpenseForm(QFrame):
    expense_created = Signal(dict)
    cancelled = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._selected_category = EXPENSE_CATEGORIES[0] if EXPENSE_CATEGORIES else "Food"
        self._selected_payment  = "Cash"
        self._cat_btns: dict[str, QPushButton] = {}
        self._pay_btns: dict[str, QPushButton] = {}
        self.setMaximumHeight(0)
        self.setStyleSheet("""
            InlineExpenseForm {
                background: rgba(14, 14, 20, 0.96);
                border-radius: 24px;
                border: 1px solid rgba(255, 255, 255, 0.08);
            }
        """)
        self._build_ui()

    def _form_label(self, text: str) -> QLabel:
        lbl = QLabel(text)
        lbl.setStyleSheet("color: rgba(255, 255, 255, 0.60); font-size: 11px; font-weight: 700; letter-spacing: 0.8px; background: transparent;")
        return lbl

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(32, 28, 32, 28)
        layout.setSpacing(14)

        # Title
        hdr = QLabel("ADD EXPENSE")
        hdr.setStyleSheet("color: #D4A96A; font-size: 14px; font-weight: 900; letter-spacing: 1.5px; background: transparent;")
        layout.addWidget(hdr)

        # ── Amount ────────────────────────────────────────────────────────────
        layout.addWidget(self._form_label("Amount *"))
        self._amount = QDoubleSpinBox()
        self._amount.setMinimum(0)
        self._amount.setMaximum(10_000_000)
        self._amount.setValue(0)
        self._amount.setPrefix("₹ ")
        self._amount.setFixedHeight(50)
        self._amount.setGroupSeparatorShown(True)
        self._amount.setStyleSheet("""
            QDoubleSpinBox {
                background: rgba(255, 255, 255, 0.05);
                border: 1px solid rgba(255, 255, 255, 0.10);
                border-radius: 10px;
                color: #FFFFFF;
                font-size: 22px;
                font-weight: 900;
                padding: 0 14px;
            }
            QDoubleSpinBox:focus { border-color: rgba(212, 169, 106, 0.50); }
        """)
        layout.addWidget(self._amount)

        # ── Category grid (QGridLayout — 4 columns × 2 rows) ─────────────────
        layout.addWidget(self._form_label("Category *"))

        from PySide6.QtWidgets import QGridLayout
        cat_grid = QGridLayout()
        cat_grid.setSpacing(8)
        cat_grid.setContentsMargins(0, 0, 0, 0)
        for col in range(4):
            cat_grid.setColumnStretch(col, 1)

        cats = EXPENSE_CATEGORIES
        for i, cat in enumerate(cats):
            icon = EXPENSE_CATEGORY_ICONS.get(cat, "💳")
            btn = QPushButton(f"{icon}  {cat}")
            btn.setFixedHeight(42)
            btn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setStyleSheet(self._cat_style(False))
            btn.clicked.connect(lambda checked=False, c=cat: self._select_category(c))
            self._cat_btns[cat] = btn
            row, col = divmod(i, 4)
            cat_grid.addWidget(btn, row, col)

        layout.addLayout(cat_grid)
        self._select_category(cats[0] if cats else "Food")

        # ── Description ───────────────────────────────────────────────────────
        layout.addWidget(self._form_label("Description"))
        self._desc = QLineEdit()
        self._desc.setPlaceholderText("e.g. Dinner at beach shack")
        self._desc.setFixedHeight(42)
        self._desc.setStyleSheet("""
            QLineEdit {
                background: rgba(255, 255, 255, 0.05);
                border: 1px solid rgba(255, 255, 255, 0.10);
                border-radius: 10px;
                color: #FFFFFF;
                font-size: 13px;
                padding: 0 14px;
            }
            QLineEdit:focus { border-color: rgba(212, 169, 106, 0.50); }
        """)
        layout.addWidget(self._desc)

        # ── Date ──────────────────────────────────────────────────────────────
        layout.addWidget(self._form_label("Date"))
        self._date = QDateEdit()
        self._date.setDate(date.today())
        self._date.setCalendarPopup(True)
        self._date.setFixedHeight(42)
        self._date.setStyleSheet("""
            QDateEdit {
                background: rgba(255, 255, 255, 0.05);
                border: 1px solid rgba(255, 255, 255, 0.10);
                border-radius: 10px;
                color: #FFFFFF;
                font-size: 13px;
                padding: 0 12px;
            }
            QDateEdit:focus { border-color: rgba(212, 169, 106, 0.50); }
        """)
        layout.addWidget(self._date)

        # ── Payment Method pills (aligned in 4 equal columns) ─────────────────
        layout.addWidget(self._form_label("Payment Method"))
        pay_row = QHBoxLayout()
        pay_row.setSpacing(8)
        pay_row.setContentsMargins(0, 0, 0, 0)
        for method in ["Cash", "UPI", "Card", "Other"]:
            btn = QPushButton(method)
            btn.setFixedHeight(40)
            btn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setStyleSheet(self._pay_style(False))
            btn.clicked.connect(lambda checked=False, m=method: self._select_payment(m))
            self._pay_btns[method] = btn
            pay_row.addWidget(btn, 1)
        layout.addLayout(pay_row)
        self._select_payment("Cash")

        # ── Trip selector ─────────────────────────────────────────────────────
        layout.addWidget(self._form_label("Trip (Optional)"))
        self._trips_combo = QComboBox()
        self._trips_combo.setFixedHeight(42)
        self._trips_combo.setStyleSheet("""
            QComboBox {
                background: rgba(255, 255, 255, 0.05);
                border: 1px solid rgba(255, 255, 255, 0.10);
                border-radius: 10px;
                color: #FFFFFF;
                font-size: 13px;
                padding: 0 14px;
            }
            QComboBox:focus { border-color: rgba(212, 169, 106, 0.50); }
            QComboBox::drop-down { border: none; width: 24px; }
            QComboBox QAbstractItemView {
                background: #1a1a22;
                color: #FFF;
                selection-background-color: rgba(255,255,255,0.12);
                border: 1px solid rgba(255,255,255,0.08);
            }
        """)
        self._trips_combo.addItem("(No specific trip)", None)
        for t in trip_repo.get_all():
            self._trips_combo.addItem(t["name"], t["id"])
        layout.addWidget(self._trips_combo)

        # ── Error message label ───────────────────────────────────────────────
        self._error_lbl = QLabel("")
        self._error_lbl.setStyleSheet("color: #F87171; font-size: 11px; font-weight: 700; background: transparent;")
        self._error_lbl.hide()
        layout.addWidget(self._error_lbl)

        # ── Action buttons ────────────────────────────────────────────────────
        btn_row = QHBoxLayout()
        btn_row.setSpacing(12)
        btn_row.addStretch()

        cancel_btn = QPushButton("Cancel")
        cancel_btn.setCursor(Qt.PointingHandCursor)
        cancel_btn.setFixedHeight(42)
        cancel_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.06);
                color: #A1A1AA;
                border: none;
                border-radius: 12px;
                padding: 0 24px;
                font-size: 13px;
                font-weight: 600;
            }
            QPushButton:hover { background: rgba(255, 255, 255, 0.12); color: #FFFFFF; }
        """)
        cancel_btn.clicked.connect(self._on_cancel)
        btn_row.addWidget(cancel_btn)

        self._save_btn = QPushButton("Add Expense ✓")
        self._save_btn.setCursor(Qt.PointingHandCursor)
        self._save_btn.setFixedHeight(42)
        self._save_btn.setStyleSheet("""
            QPushButton {
                background: #D4A96A;
                color: #111111;
                border: none;
                border-radius: 12px;
                padding: 0 28px;
                font-size: 13px;
                font-weight: 800;
            }
            QPushButton:hover { background: #FDBA74; }
        """)
        self._save_btn.clicked.connect(self._submit)
        btn_row.addWidget(self._save_btn)
        layout.addLayout(btn_row)

    def _cat_style(self, active: bool) -> str:
        if active:
            return """
                QPushButton {
                    background: rgba(255, 255, 255, 0.15);
                    color: #FFFFFF;
                    border: 1.5px solid rgba(255, 255, 255, 0.40);
                    border-radius: 10px;
                    font-size: 12px;
                    font-weight: 700;
                    padding: 0 8px;
                    text-align: center;
                }
            """
        return """
            QPushButton {
                background: rgba(255, 255, 255, 0.05);
                color: #A1A1AA;
                border: 1.5px solid rgba(255, 255, 255, 0.08);
                border-radius: 10px;
                font-size: 12px;
                font-weight: 600;
                padding: 0 8px;
                text-align: center;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.10);
                color: #FFFFFF;
                border-color: rgba(255, 255, 255, 0.18);
            }
        """

    def _pay_style(self, active: bool) -> str:
        if active:
            return """
                QPushButton {
                    background: rgba(255, 255, 255, 0.15);
                    color: #FFFFFF;
                    border: 1.5px solid rgba(255, 255, 255, 0.40);
                    border-radius: 10px;
                    font-size: 12px;
                    font-weight: 700;
                    padding: 0 12px;
                    text-align: center;
                }
            """
        return """
            QPushButton {
                background: rgba(255, 255, 255, 0.05);
                color: #A1A1AA;
                border: 1.5px solid rgba(255, 255, 255, 0.08);
                border-radius: 10px;
                font-size: 12px;
                font-weight: 600;
                padding: 0 12px;
                text-align: center;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.10);
                color: #FFFFFF;
                border-color: rgba(255, 255, 255, 0.18);
            }
        """

    def _select_category(self, cat: str):
        self._selected_category = cat
        for c, btn in self._cat_btns.items():
            btn.setStyleSheet(self._cat_style(c == cat))

    def _select_payment(self, method: str):
        self._selected_payment = method
        for m, btn in self._pay_btns.items():
            btn.setStyleSheet(self._pay_style(m == method))

    def populate_trips(self):
        self._trips_combo.blockSignals(True)
        self._trips_combo.clear()
        self._trips_combo.addItem("(No specific trip)", None)
        for t in trip_repo.get_all():
            self._trips_combo.addItem(t["name"], t["id"])
        self._trips_combo.blockSignals(False)

    def _on_cancel(self):
        self._reset_form()
        self.cancelled.emit()

    def _reset_form(self):
        self._amount.setValue(0)
        self._desc.clear()
        self._date.setDate(date.today())
        self._select_category(EXPENSE_CATEGORIES[0] if EXPENSE_CATEGORIES else "Food")
        self._select_payment("Cash")
        if self._trips_combo.count() > 0:
            self._trips_combo.setCurrentIndex(0)
        self._error_lbl.hide()

    def _submit(self):
        amount = self._amount.value()
        if amount <= 0:
            self._error_lbl.setText("⚠ Please enter an amount greater than 0")
            self._error_lbl.show()
            return
        self._error_lbl.hide()
        trip_id = self._trips_combo.currentData()
        data = {
            "trip_id":        trip_id,
            "category":       self._selected_category,
            "amount":         amount,
            "description":    self._desc.text().strip() or self._selected_category,
            "date":           self._date.date().toString("yyyy-MM-dd"),
            "payment_method": self._selected_payment,
            "currency":       "INR",
            "currency_sym":   "₹",
        }
        self.expense_created.emit(data)
        self._reset_form()


# ── Expenses Screen ───────────────────────────────────────────────────────────
class ExpensesScreen(QWidget):

    def __init__(self, parent=None):
        super().__init__(parent)
        self._current_trip_id = -1
        self._form_expanded = False
        self._build_ui()
        self.refresh()

    def _build_ui(self) -> None:
        outer_layout = QVBoxLayout(self)
        outer_layout.setContentsMargins(0, 0, 0, 0)
        outer_layout.setSpacing(0)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setStyleSheet("background: transparent; border: none;")
        scroll.viewport().setStyleSheet("background: transparent;")
        outer_layout.addWidget(scroll)

        scroll_content = QWidget()
        scroll_content.setStyleSheet("background: transparent;")
        scroll.setWidget(scroll_content)

        layout = QVBoxLayout(scroll_content)
        layout.setContentsMargins(36, 24, 36, 36)
        layout.setSpacing(20)

        # ── 1. Lifetime Financial Overview Header ──────────────────────────
        overview_container = QVBoxLayout()
        overview_container.setSpacing(2)
        overview_container.setAlignment(Qt.AlignCenter)

        small_lbl = QLabel("LIFETIME FINANCIAL OVERVIEW")
        small_lbl.setStyleSheet("color: #71717A; font-size: 11px; font-weight: 800; letter-spacing: 1.5px; background: transparent;")
        small_lbl.setAlignment(Qt.AlignCenter)
        overview_container.addWidget(small_lbl)

        self._lifetime_lbl = QLabel("₹0")
        self._lifetime_lbl.setStyleSheet("color: #FFFFFF; font-size: 40px; font-weight: 900; background: transparent; letter-spacing: -1px;")
        self._lifetime_lbl.setAlignment(Qt.AlignCenter)
        overview_container.addWidget(self._lifetime_lbl)

        # Stats pills row
        stats_pills = QHBoxLayout()
        stats_pills.setSpacing(12)
        stats_pills.setAlignment(Qt.AlignCenter)

        self._p_trips = QLabel("Total Trips  0")
        self._p_trips.setStyleSheet("""
            background: rgba(255,255,255,0.04);
            color: #E4E4E7;
            font-size: 11px;
            font-weight: 700;
            border: 1px solid rgba(255,255,255,0.12);
            border-radius: 12px;
            padding: 5px 14px;
        """)

        self._p_avg = QLabel("Avg per Trip  ₹0")
        self._p_avg.setStyleSheet("""
            background: rgba(255,255,255,0.04);
            color: #E4E4E7;
            font-size: 11px;
            font-weight: 700;
            border: 1px solid rgba(255,255,255,0.12);
            border-radius: 12px;
            padding: 5px 14px;
        """)
        stats_pills.addWidget(self._p_trips)
        stats_pills.addWidget(self._p_avg)

        overview_container.addLayout(stats_pills)
        layout.addLayout(overview_container)

        # ── 2. Context view & Plan new expense ──────────────────────────────
        context_row = QHBoxLayout()

        self._view_combo = QComboBox()
        self._view_combo.setFixedHeight(38)
        self._view_combo.setMinimumWidth(220)
        self._view_combo.setStyleSheet(f"""
            QComboBox {{
                background: rgba(255,255,255,0.05);
                color: {COLORS['sand']};
                border: 1px solid rgba(255, 255, 255, 0.12);
                border-radius: 10px;
                padding: 4px 14px;
                font-size: 12px;
                font-weight: 700;
            }}
        """)
        self._view_combo.currentIndexChanged.connect(self._on_view_changed)
        context_row.addWidget(self._view_combo)
        context_row.addStretch()

        self._add_btn = QPushButton("+  Add Expense")
        self._add_btn.setFixedSize(130, 38)
        self._add_btn.setStyleSheet(f"""
            QPushButton {{
                background: {COLORS['sand']};
                color: #111111;
                border: none;
                border-radius: 10px;
                font-size: 12px;
                font-weight: 700;
            }}
            QPushButton:hover {{
                background: {COLORS['accent_light']};
            }}
        """)
        self._add_btn.clicked.connect(self._toggle_form)
        context_row.addWidget(self._add_btn)

        layout.addLayout(context_row)

        # ── 3. Inline form ──────────────────────────────────────────────────
        self._inline_form = InlineExpenseForm()
        self._inline_form.expense_created.connect(self._on_expense_created)
        self._inline_form.cancelled.connect(lambda: self._animate_form(False))
        layout.addWidget(self._inline_form)

        # ── 4. Split Budget & Category Card Layout ────────────────────────
        split_lay = QHBoxLayout()
        split_lay.setSpacing(24)

        self._budget_card = TripBudgetCard()
        split_lay.addWidget(self._budget_card)

        self._category_card = CategorySplitCard(self._current_trip_id)
        split_lay.addWidget(self._category_card)
        split_lay.addStretch()

        layout.addLayout(split_lay)

        # ── 5. Recent Expenses ──────────────────────────────────────────────
        rec_title = QLabel("Recent Expenses")
        rec_title.setStyleSheet("color: #FFFFFF; font-size: 14px; font-weight: 800; background: transparent; padding-top: 10px;")
        layout.addWidget(rec_title)

        self._list_w = QWidget()
        self._list_w.setStyleSheet("background: transparent;")
        self._list_layout = QVBoxLayout(self._list_w)
        self._list_layout.setContentsMargins(0, 0, 0, 0)
        self._list_layout.setSpacing(12)
        layout.addWidget(self._list_w)

    def _populate_view_combo(self):
        self._view_combo.blockSignals(True)
        self._view_combo.clear()
        self._view_combo.addItem("🌐  Lifetime Context (All Trips)", -1)
        trips = trip_repo.get_all() or []
        for t in trips:
            self._view_combo.addItem(f"✈  {t['name']}", t["id"])
        self._view_combo.blockSignals(False)

    def _on_view_changed(self, idx: int):
        self._current_trip_id = self._view_combo.currentData()
        self.refresh()

    def refresh(self) -> None:
        self._populate_view_combo()
        self._inline_form.populate_trips()

        # Update view index selection
        self._view_combo.blockSignals(True)
        idx = self._view_combo.findData(self._current_trip_id)
        if idx >= 0:
            self._view_combo.setCurrentIndex(idx)
        self._view_combo.blockSignals(False)

        # Populate top Lifetime overview values
        try:
            all_trips = trip_repo.get_all() or []
            total_lifetime = sum(expense_repo.get_total_spent(t["id"]) or 0.0 for t in all_trips)
            self._lifetime_lbl.setText(f"₹{total_lifetime:,.2f}" if total_lifetime >= 1000 else f"₹{total_lifetime:,.0f}")
            self._p_trips.setText(f"Total Trips  {len(all_trips)}")
            avg = total_lifetime / len(all_trips) if all_trips else 0.0
            self._p_avg.setText(f"Avg per Trip  ₹{avg:,.0f}")
        except Exception as e:
            logger.debug(f"Lifetime refresh: {e}")

        # Update dynamic Left budget card
        selected_trip = None
        if self._current_trip_id != -1:
            selected_trip = trip_repo.get_by_id(self._current_trip_id)
        self._budget_card.update_trip(selected_trip)

        # Update dynamic Right Category split card
        self._category_card.set_trip_id(self._current_trip_id)

        # Populate recent expense list
        while self._list_layout.count():
            item = self._list_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        all_expenses = expense_repo.get_recent(150)
        if self._current_trip_id != -1:
            all_expenses = [e for e in all_expenses if e.get("trip_id") == self._current_trip_id]

        if not all_expenses:
            empty = EmptyStateWidget("💳", "No expenses logged yet",
                                     "Add your first expense to track your travel budget.")
            self._list_layout.addWidget(empty)
            return

        for exp in all_expenses:
            card = ExpenseCard(exp)
            card.delete_requested.connect(self._delete)
            self._list_layout.addWidget(card)

        self._list_layout.addStretch()

    def _toggle_form(self):
        self._animate_form(not self._form_expanded)

    def _animate_form(self, expand: bool):
        self._form_expanded = expand
        anim = QPropertyAnimation(self._inline_form, b"maximumHeight", self)
        anim.setDuration(350)
        anim.setEasingCurve(QEasingCurve.OutCubic if expand else QEasingCurve.InCubic)
        anim.setStartValue(self._inline_form.maximumHeight())
        anim.setEndValue(750 if expand else 0)
        anim.start()

    def _on_expense_created(self, data: dict):
        if data.get("amount", 0) > 0:
            expense_service.add_expense(data)
            self._animate_form(False)
            self.refresh()

    def _delete(self, expense_id: int) -> None:
        expense_service.delete_expense(expense_id)
        self.refresh()
