"""
TripSphere Trip Assistant — Premium 3D Personal Travel Companion Screen.

Visual architecture:
  ┌────────────────────────────────────────────────────────────┐
  │  HEADER  Trip Assistant · Your personal travel companion   │
  ├──────────────────────────┬─────────────────────────────────┤
  │  LEFT COLUMN             │  RIGHT COLUMN                   │
  │  ┌────────────────────┐  │  ┌─────────────────────────┐    │
  │  │  3D WebGL Globe    │  │  │  TRIP SNAPSHOT          │    │
  │  │  (Three.js)        │  │  │  Mood / Budget / Days…  │    │
  │  └────────────────────┘  │  ├─────────────────────────┤    │
  │  Status label            │  │  LIVE MAP               │    │
  │  ┌────────────────────┐  │  ├─────────────────────────┤    │
  │  │  Mic control       │  │  │  RECOMMENDATION CARDS   │    │
  │  └────────────────────┘  │  └─────────────────────────┘    │
  │  ┌────────────────────┐  │                                  │
  │  │  CONVERSATION      │  │                                  │
  │  └────────────────────┘  │                                  │
  ├──────────────────────────┴─────────────────────────────────┤
  │  Smart actions bar · Keyboard drawer                       │
  └────────────────────────────────────────────────────────────┘

Voice pipeline (voice_service.py + assistant_agent.py) is untouched.
Only the layout/visual layer is rebuilt here.
"""
from __future__ import annotations

import logging
import webbrowser
from pathlib import Path
from typing import Optional

from PySide6.QtCore import Qt, QTimer, QThread, Signal, Slot, QUrl
from PySide6.QtGui import QColor, QFont, QLinearGradient, QPainter, QBrush
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtWebEngineCore import QWebEnginePage
from PySide6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QScrollArea, QSizePolicy, QSplitter, QVBoxLayout, QWidget,
    QGraphicsOpacityEffect,
)

from app.map.map_view import MapView
from app.services.assistant_agent import assistant_agent, AssistantResponse
from app.services.voice_service import voice_service, VoiceState, clean_text_for_speech

logger = logging.getLogger(__name__)

# ── Asset path ────────────────────────────────────────────────────────────────
_UI_DIR = Path(__file__).parent
_3D_HTML = _UI_DIR / "assistant_3d.html"

# ── Premium palette ───────────────────────────────────────────────────────────
P = {
    "bg":         "#060B12",
    "navy":       "#0D1622",
    "panel":      "#111C28",
    "card":       "#162433",
    "border":     "rgba(255,255,255,0.07)",
    "border2":    "rgba(255,255,255,0.04)",
    "gold":       "#D8B15A",
    "goldL":      "#E7C56A",
    "cyan":       "#6ECFF6",
    "text":       "#F5F1E8",
    "muted":      "#AAB7C5",
    "muted2":     "#677A8E",
    "success":    "#69C99A",
    "danger":     "#E97878",
    "violet":     "#B8A4E8",
}

# ── State display strings ──────────────────────────────────────────────────────
STATE_LABELS = {
    VoiceState.IDLE:      ("Tap to talk", P["muted"]),
    VoiceState.LISTENING: ("Listening...", P["cyan"]),
    VoiceState.THINKING:  ("Thinking...", P["violet"]),
    VoiceState.SPEAKING:  ("Speaking...", P["goldL"]),
    VoiceState.ERROR:     ("Didn't catch that — try again", P["danger"]),
}

SMART_SUGGESTIONS = [
    ("🌊", "Beach trip", "I want a beach trip"),
    ("🗺️", "Show on map", "Show the location on map"),
    ("✈️", "Find flights", "Find flights for my trip"),
    ("🏨", "Find hotels", "Find hotels for my trip"),
    ("📅", "Plan trip", "Plan my trip with an itinerary"),
    ("📍", "Nearby places", "Show me places nearby"),
]


# ── Pill / Tag helpers ─────────────────────────────────────────────────────────

def _pill(text: str, bg: str, fg: str, size: int = 10) -> QLabel:
    lbl = QLabel(text)
    lbl.setStyleSheet(f"""
        background: {bg};
        color: {fg};
        border-radius: 10px;
        padding: 3px 10px;
        font-size: {size}px;
        font-weight: 700;
    """)
    return lbl


def _section_title(text: str) -> QLabel:
    lbl = QLabel(text)
    lbl.setStyleSheet(f"""
        color: {P['muted2']};
        font-size: 9px;
        font-weight: 800;
        letter-spacing: 1.6px;
        padding-left: 2px;
    """)
    return lbl


def _card_frame() -> QFrame:
    f = QFrame()
    f.setStyleSheet(f"""
        QFrame {{
            background: {P['panel']};
            border: 1px solid {P['border']};
            border-radius: 14px;
        }}
    """)
    return f


# ── 3D WebEngine View ──────────────────────────────────────────────────────────

class _BlockPage(QWebEnginePage):
    """Block new-window requests inside the 3D canvas page."""
    def createWindow(self, _type):
        return None


class AssistantOrbView(QWebEngineView):
    """
    QWebEngineView that hosts the Three.js 3D assistant globe.
    Exposes set_state(VoiceState) which calls window.setAssistantState() in JS.
    Falls back to a CSS-only gradient orb if the HTML file is missing.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        page = _BlockPage(self)
        self.setPage(page)
        self.setAttribute(Qt.WA_OpaquePaintEvent, False)
        self.setStyleSheet("background: transparent;")
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setMinimumHeight(200)

        if _3D_HTML.exists():
            self.load(QUrl.fromLocalFile(str(_3D_HTML)))
        else:
            logger.warning("assistant_3d.html not found — 3D globe unavailable.")

        self._current_state = VoiceState.IDLE
        self._state = VoiceState.IDLE

    def set_state(self, state: VoiceState) -> None:
        self._state = state
        if state == self._current_state:
            return
        self._current_state = state
        js = f"window.setAssistantState && window.setAssistantState('{state.value}');"
        self.page().runJavaScript(js)


# Alias for backwards compatibility
VoiceOrbWidget = AssistantOrbView


# ── Chat Screen ────────────────────────────────────────────────────────────────

class ChatScreen(QWidget):
    """
    Premium Trip Assistant screen.
    All voice/AI logic is delegated to VoiceWorker + AssistantAgent.
    This class is purely UI orchestration.
    """

    navigate = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._voice_worker = voice_service.create_worker()
        self._worker_thread = QThread()
        self._dialogue_history: list[tuple[str, str]] = []

        self._build_ui()
        # Aliases for backwards compatibility with test suites
        self._orb = self._orb_view
        self._state_title = self._state_label
        self._connect_voice_signals()
        self._update_snapshot_panel()

    def cleanup(self) -> None:
        """Clean up voice worker and background threads on exit."""
        try:
            if hasattr(self, "_voice_worker") and self._voice_worker:
                self._voice_worker.stop()
            if hasattr(self, "_worker_thread") and self._worker_thread.isRunning():
                self._worker_thread.quit()
                self._worker_thread.wait(300)
        except Exception as exc:
            logger.debug("ChatScreen cleanup error: %s", exc)

    # ═══════════════════════════════════════════════════════════════════════════
    # BUILD UI
    # ═══════════════════════════════════════════════════════════════════════════

    def _build_ui(self) -> None:
        self.setStyleSheet(f"background: {P['bg']}; font-family: 'Segoe UI', sans-serif;")

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ── HEADER ──────────────────────────────────────────────────────────────
        header = QFrame()
        header.setFixedHeight(58)
        header.setStyleSheet(f"""
            QFrame {{
                background: {P['navy']};
                border-bottom: 1px solid {P['border2']};
            }}
        """)
        hl = QHBoxLayout(header)
        hl.setContentsMargins(24, 0, 20, 0)
        hl.setSpacing(12)

        # Gold badge
        badge = QLabel("✦")
        badge.setFixedSize(30, 30)
        badge.setAlignment(Qt.AlignCenter)
        badge.setStyleSheet(f"""
            background: rgba(216,177,90,0.12);
            color: {P['goldL']};
            font-size: 14px;
            font-weight: 900;
            border-radius: 15px;
            border: 1px solid rgba(216,177,90,0.30);
        """)
        hl.addWidget(badge)

        title_col = QVBoxLayout()
        title_col.setSpacing(1)
        title_col.setAlignment(Qt.AlignVCenter)
        t1 = QLabel("Trip Assistant")
        t1.setStyleSheet(f"color: {P['text']}; font-size: 15px; font-weight: 700; letter-spacing: -0.2px;")
        t2 = QLabel("Your personal travel companion")
        t2.setStyleSheet(f"color: {P['muted']}; font-size: 10px;")
        title_col.addWidget(t1)
        title_col.addWidget(t2)
        hl.addLayout(title_col)
        hl.addStretch()

        # Live status badge
        self._header_status = _pill("● Ready", "rgba(105,201,154,0.10)", P["success"], 10)
        hl.addWidget(self._header_status)

        # ⌨ Type button
        self._keyboard_btn = QPushButton("⌨  Type")
        self._keyboard_btn.setCursor(Qt.PointingHandCursor)
        self._keyboard_btn.setFixedHeight(28)
        self._keyboard_btn.setStyleSheet(f"""
            QPushButton {{
                background: rgba(255,255,255,0.04);
                color: {P['muted']};
                border: 1px solid {P['border']};
                border-radius: 14px;
                padding: 0 14px;
                font-size: 10px;
                font-weight: 600;
            }}
            QPushButton:hover {{ background: rgba(255,255,255,0.08); color: {P['text']}; }}
        """)
        self._keyboard_btn.clicked.connect(self._toggle_keyboard_drawer)
        hl.addWidget(self._keyboard_btn)

        # ↺ Reset
        reset_btn = QPushButton("↺  Reset")
        reset_btn.setCursor(Qt.PointingHandCursor)
        reset_btn.setFixedHeight(28)
        reset_btn.setStyleSheet(f"""
            QPushButton {{
                background: transparent;
                color: {P['muted']};
                border: 1px solid {P['border']};
                border-radius: 14px;
                padding: 0 12px;
                font-size: 10px;
                font-weight: 600;
            }}
            QPushButton:hover {{ background: rgba(255,255,255,0.05); color: {P['text']}; }}
        """)
        reset_btn.clicked.connect(self._reset_conversation)
        hl.addWidget(reset_btn)

        root.addWidget(header)

        # ── KEYBOARD DRAWER (collapsible, hidden by default) ─────────────────
        self._keyboard_drawer = QFrame()
        self._keyboard_drawer.setVisible(False)
        self._keyboard_drawer.setStyleSheet(f"""
            QFrame {{
                background: {P['panel']};
                border-bottom: 1px solid {P['border2']};
            }}
        """)
        kb_lay = QHBoxLayout(self._keyboard_drawer)
        kb_lay.setContentsMargins(20, 8, 16, 8)
        kb_lay.setSpacing(10)

        self._text_input = QLineEdit()
        self._text_input.setPlaceholderText("Type your message and press Enter…")
        self._text_input.setStyleSheet(f"""
            QLineEdit {{
                background: {P['card']};
                border: 1px solid {P['border']};
                border-radius: 10px;
                color: {P['text']};
                font-size: 13px;
                padding: 8px 14px;
            }}
            QLineEdit:focus {{ border-color: rgba(216,177,90,0.45); }}
        """)
        self._text_input.returnPressed.connect(self._on_keyboard_submit)
        kb_lay.addWidget(self._text_input)

        kb_send = QPushButton("Ask")
        kb_send.setCursor(Qt.PointingHandCursor)
        kb_send.setFixedSize(60, 34)
        kb_send.setStyleSheet(f"""
            QPushButton {{
                background: {P['gold']};
                color: #080D14;
                font-size: 11px;
                font-weight: 700;
                border: none;
                border-radius: 10px;
            }}
            QPushButton:hover {{ background: {P['goldL']}; }}
        """)
        kb_send.clicked.connect(self._on_keyboard_submit)
        kb_lay.addWidget(kb_send)
        root.addWidget(self._keyboard_drawer)

        # ── MAIN SPLITTER ────────────────────────────────────────────────────
        splitter = QSplitter(Qt.Horizontal)
        splitter.setStyleSheet("QSplitter::handle { background: rgba(255,255,255,0.03); width:1px; }")

        # ═══════════════════════════════════════════════════════════════════
        # LEFT COLUMN
        # ═══════════════════════════════════════════════════════════════════
        left = QWidget()
        left.setStyleSheet(f"background: {P['bg']};")
        lv = QVBoxLayout(left)
        lv.setContentsMargins(20, 16, 12, 16)
        lv.setSpacing(12)

        # ── HERO: 3D orb + state + mic control ──────────────────────────────
        hero = _card_frame()
        hero.setStyleSheet(f"""
            QFrame {{
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                    stop:0 {P['navy']}, stop:1 {P['panel']});
                border: 1px solid {P['border']};
                border-radius: 18px;
            }}
        """)
        hero_v = QVBoxLayout(hero)
        hero_v.setContentsMargins(16, 16, 16, 18)
        hero_v.setSpacing(10)
        hero_v.setAlignment(Qt.AlignCenter)

        # 3D orb
        self._orb_view = AssistantOrbView()
        self._orb_view.setFixedHeight(200)
        hero_v.addWidget(self._orb_view)

        # Dynamic status label
        self._state_label = QLabel("Tap to talk")
        self._state_label.setAlignment(Qt.AlignCenter)
        self._state_label.setStyleSheet(f"""
            color: {P['muted']};
            font-size: 16px;
            font-weight: 600;
            letter-spacing: 0.2px;
            background: transparent;
        """)
        hero_v.addWidget(self._state_label)

        # Premium mic button
        self._mic_btn = QPushButton("🎙  Talk to TripSphere")
        self._mic_btn.setCursor(Qt.PointingHandCursor)
        self._mic_btn.setFixedHeight(46)
        self._mic_btn.setMinimumWidth(210)
        self._mic_btn.setMaximumWidth(320)
        self._mic_btn.setStyleSheet(self._mic_idle_style())
        self._mic_btn.clicked.connect(self._on_mic_btn_clicked)
        hero_v.addWidget(self._mic_btn, alignment=Qt.AlignCenter)

        lv.addWidget(hero)

        # ── CONVERSATION ────────────────────────────────────────────────────
        lv.addWidget(_section_title("CONVERSATION"))

        self._scroll = QScrollArea()
        self._scroll.setWidgetResizable(True)
        self._scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._scroll.setStyleSheet(f"""
            QScrollArea {{
                background: {P['panel']};
                border: 1px solid {P['border2']};
                border-radius: 14px;
            }}
            QScrollBar:vertical {{
                background: transparent; width: 4px;
            }}
            QScrollBar::handle:vertical {{
                background: rgba(255,255,255,0.10);
                border-radius: 2px;
            }}
        """)

        self._dialogue_container = QWidget()
        self._dialogue_container.setStyleSheet("background: transparent;")
        self._dialogue_layout = QVBoxLayout(self._dialogue_container)
        self._dialogue_layout.setContentsMargins(16, 14, 16, 14)
        self._dialogue_layout.setSpacing(16)
        self._dialogue_layout.addStretch()

        self._scroll.setWidget(self._dialogue_container)
        lv.addWidget(self._scroll, 1)

        # ── SMART ACTIONS BAR ───────────────────────────────────────────────
        sug_box = QWidget()
        sug_box.setStyleSheet("background: transparent;")
        sug_lay = QHBoxLayout(sug_box)
        sug_lay.setContentsMargins(0, 0, 0, 0)
        sug_lay.setSpacing(6)
        for icon, label, prompt in SMART_SUGGESTIONS:
            b = QPushButton(f"{icon}  {label}")
            b.setCursor(Qt.PointingHandCursor)
            b.setFixedHeight(28)
            b.setStyleSheet(f"""
                QPushButton {{
                    background: {P['panel']};
                    color: {P['muted']};
                    border: 1px solid {P['border2']};
                    border-radius: 14px;
                    padding: 0 11px;
                    font-size: 10px;
                    font-weight: 600;
                }}
                QPushButton:hover {{
                    background: {P['card']};
                    color: {P['text']};
                    border-color: rgba(216,177,90,0.30);
                }}
            """)
            b.clicked.connect(lambda _, p=prompt: self._submit_text(p))
            sug_lay.addWidget(b)
        sug_lay.addStretch()
        lv.addWidget(sug_box)

        splitter.addWidget(left)

        # ═══════════════════════════════════════════════════════════════════
        # RIGHT COLUMN
        # ═══════════════════════════════════════════════════════════════════
        right = QWidget()
        right.setStyleSheet(f"background: {P['bg']};")
        rv = QVBoxLayout(right)
        rv.setContentsMargins(8, 16, 20, 16)
        rv.setSpacing(12)

        # ── TRIP SNAPSHOT ────────────────────────────────────────────────────
        rv.addWidget(_section_title("TRIP SNAPSHOT"))

        self._snapshot_frame = _card_frame()
        self._snapshot_layout = QVBoxLayout(self._snapshot_frame)
        self._snapshot_layout.setContentsMargins(16, 14, 16, 14)
        self._snapshot_layout.setSpacing(9)

        self._snapshot_empty = QLabel("Your trip preferences will appear here as you chat.")
        self._snapshot_empty.setWordWrap(True)
        self._snapshot_empty.setStyleSheet(f"color: {P['muted2']}; font-size: 11px; line-height: 1.5;")
        self._snapshot_layout.addWidget(self._snapshot_empty)

        rv.addWidget(self._snapshot_frame)

        # ── LIVE MAP ─────────────────────────────────────────────────────────
        rv.addWidget(_section_title("LOCATION PREVIEW"))
        self._map = MapView()
        self._map.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self._map.setStyleSheet(f"border-radius: 12px; border: 1px solid {P['border2']};")
        rv.addWidget(self._map, 2)

        # ── RECOMMENDATION CARDS ──────────────────────────────────────────────
        self._rec_header = _section_title("RECOMMENDED")
        self._rec_header.setVisible(False)
        rv.addWidget(self._rec_header)

        self._rec_scroll = QScrollArea()
        self._rec_scroll.setWidgetResizable(True)
        self._rec_scroll.setFixedHeight(160)
        self._rec_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._rec_scroll.setStyleSheet("background: transparent; border: none;")
        self._rec_scroll.setVisible(False)

        self._rec_container = QWidget()
        self._rec_container.setStyleSheet("background: transparent;")
        self._rec_layout = QVBoxLayout(self._rec_container)
        self._rec_layout.setContentsMargins(0, 0, 0, 0)
        self._rec_layout.setSpacing(8)
        self._rec_scroll.setWidget(self._rec_container)
        rv.addWidget(self._rec_scroll)

        splitter.addWidget(right)
        splitter.setSizes([600, 400])
        root.addWidget(splitter, 1)

        # ── Seed initial welcome message ─────────────────────────────────────
        self._append_dialogue(
            "TRIPSPHERE",
            "Heeeyyy boss! 😄 What's the order today? Beach? Mountains? City? Or are we just escaping life for a bit?"
        )

    # ═══════════════════════════════════════════════════════════════════════════
    # STYLE HELPERS
    # ═══════════════════════════════════════════════════════════════════════════

    def _mic_idle_style(self) -> str:
        return f"""
            QPushButton {{
                background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                    stop:0 {P['gold']}, stop:1 {P['goldL']});
                color: #08111C;
                border: none;
                border-radius: 23px;
                font-size: 13px;
                font-weight: 700;
                letter-spacing: 0.2px;
            }}
            QPushButton:hover {{ background: {P['goldL']}; }}
        """

    def _mic_state_style(self, bg: str, fg: str, border: str) -> str:
        return f"""
            QPushButton {{
                background: {bg};
                color: {fg};
                border: 1.5px solid {border};
                border-radius: 23px;
                font-size: 13px;
                font-weight: 700;
            }}
        """

    # ═══════════════════════════════════════════════════════════════════════════
    # VOICE SIGNAL CONNECTIONS
    # ═══════════════════════════════════════════════════════════════════════════

    def _connect_voice_signals(self) -> None:
        self._voice_worker.moveToThread(self._worker_thread)
        self._worker_thread.start()

        self._voice_worker.state_changed.connect(self._on_voice_state_changed)
        self._voice_worker.user_spoken.connect(self._on_user_spoken)
        self._voice_worker.assistant_spoken.connect(self._on_assistant_spoken)
        self._voice_worker.error_occurred.connect(self._on_voice_error)

    @Slot(str)
    def _on_voice_state_changed(self, state_str: str) -> None:
        try:
            state = VoiceState(state_str)
        except ValueError:
            state = VoiceState.IDLE

        # Update 3D orb
        self._orb_view.set_state(state)

        # Update status label
        label_text, label_color = STATE_LABELS.get(state, ("Tap to talk", P["muted"]))
        self._state_label.setText(label_text)
        self._state_label.setStyleSheet(f"""
            color: {label_color};
            font-size: 16px;
            font-weight: 600;
            background: transparent;
        """)

        # Update header badge
        if state == VoiceState.LISTENING:
            self._header_status.setText("● Listening")
            self._header_status.setStyleSheet(f"background: rgba(110,207,246,0.12); color: {P['cyan']}; border-radius:10px; padding:3px 10px; font-size:10px; font-weight:700;")
            self._mic_btn.setText("🔴  Listening…")
            self._mic_btn.setStyleSheet(self._mic_state_style(
                "rgba(110,207,246,0.10)", P["cyan"], "rgba(110,207,246,0.40)"))
        elif state == VoiceState.THINKING:
            self._header_status.setText("● Thinking")
            self._header_status.setStyleSheet(f"background: rgba(184,164,232,0.12); color: {P['violet']}; border-radius:10px; padding:3px 10px; font-size:10px; font-weight:700;")
            self._mic_btn.setText("✨  Thinking…")
            self._mic_btn.setStyleSheet(self._mic_state_style(
                "rgba(184,164,232,0.10)", P["violet"], "rgba(184,164,232,0.40)"))
        elif state == VoiceState.SPEAKING:
            self._header_status.setText("● Speaking")
            self._header_status.setStyleSheet(f"background: rgba(216,177,90,0.12); color: {P['goldL']}; border-radius:10px; padding:3px 10px; font-size:10px; font-weight:700;")
            self._mic_btn.setText("🔊  Speaking  (tap to interrupt)")
            self._mic_btn.setStyleSheet(self._mic_state_style(
                "rgba(216,177,90,0.10)", P["goldL"], "rgba(216,177,90,0.40)"))
        elif state == VoiceState.ERROR:
            self._header_status.setText("● Error")
            self._header_status.setStyleSheet(f"background: rgba(233,120,120,0.12); color: {P['danger']}; border-radius:10px; padding:3px 10px; font-size:10px; font-weight:700;")
            self._mic_btn.setText("↺  Try Again")
            self._mic_btn.setStyleSheet(self._mic_state_style(
                "rgba(233,120,120,0.10)", P["danger"], "rgba(233,120,120,0.40)"))
        else:  # IDLE
            self._header_status.setText("● Ready")
            self._header_status.setStyleSheet(f"background: rgba(105,201,154,0.10); color: {P['success']}; border-radius:10px; padding:3px 10px; font-size:10px; font-weight:700;")
            self._mic_btn.setText("🎙  Talk to TripSphere")
            self._mic_btn.setStyleSheet(self._mic_idle_style())

    @Slot(str)
    def _on_user_spoken(self, text: str) -> None:
        self._append_dialogue("YOU", text)

    @Slot(str, object)
    def _on_assistant_spoken(self, text: str, resp: Optional[AssistantResponse]) -> None:
        cleaned = clean_text_for_speech(text)
        self._append_dialogue("TRIPSPHERE", cleaned)

        if resp is not None:
            if resp.map_action:
                self._execute_map_action(resp.map_action)
            self._update_snapshot_panel()
            self._render_recommendations(resp.cards)

    @Slot(str)
    def _on_voice_error(self, message: str) -> None:
        logger.warning("Voice assistant notice: %s", message)
        self._append_dialogue("TRIPSPHERE", message)
        self._on_voice_state_changed(VoiceState.ERROR.value)

    # ═══════════════════════════════════════════════════════════════════════════
    # USER INTERACTIONS
    # ═══════════════════════════════════════════════════════════════════════════

    def _on_mic_btn_clicked(self) -> None:
        state = self._voice_worker.current_state
        if state in (VoiceState.IDLE, VoiceState.ERROR):
            self._start_voice_conversation()
        elif state == VoiceState.SPEAKING:
            self._voice_worker.interrupt()
        else:
            self._voice_worker.stop()

    def _start_voice_conversation(self) -> None:
        greeting = "Heeeyyy boss! 😄 What's the order today? Beach, mountains, city — or are we just escaping somewhere?"
        self._append_dialogue("TRIPSPHERE", greeting)
        self._voice_worker.start_conversation(greeting)

    def _toggle_keyboard_drawer(self) -> None:
        vis = not self._keyboard_drawer.isVisible()
        self._keyboard_drawer.setVisible(vis)
        if vis:
            self._text_input.setFocus()

    def _on_keyboard_submit(self) -> None:
        text = self._text_input.text().strip()
        if not text:
            return
        self._text_input.clear()
        self._submit_text(text)

    def _submit_text(self, text: str) -> None:
        self._append_dialogue("YOU", text)
        self._voice_worker.submit_text_input(text)

    def _reset_conversation(self) -> None:
        self._voice_worker.stop()
        assistant_agent.reset()
        self._clear_dialogue()
        self._clear_recommendations()
        self._map.clear_all()
        self._update_snapshot_panel()
        self._append_dialogue(
            "TRIPSPHERE",
            "Okay, fresh start! 😄 So — what are we planning this time?"
        )
        self._on_voice_state_changed(VoiceState.IDLE.value)

    # ═══════════════════════════════════════════════════════════════════════════
    # DIALOGUE RENDERING — premium transcript style
    # ═══════════════════════════════════════════════════════════════════════════

    def _append_dialogue(self, speaker: str, text: str) -> None:
        self._dialogue_history.append((speaker, text))
        idx = len(self._dialogue_history) - 1

        entry = QFrame()
        entry.setStyleSheet("background: transparent; border: none;")
        ev = QVBoxLayout(entry)
        ev.setContentsMargins(0, 0, 0, 0)
        ev.setSpacing(4)

        if speaker == "YOU":
            spk = QLabel("YOU")
            spk.setStyleSheet(f"""
                color: {P['cyan']};
                font-size: 9px;
                font-weight: 800;
                letter-spacing: 1.2px;
            """)
            msg = QLabel(f"\u201c{text}\u201d")
            msg.setWordWrap(True)
            msg.setStyleSheet(f"""
                color: {P['text']};
                font-size: 13px;
                font-weight: 500;
                line-height: 1.55;
                background: {P['card']};
                border-radius: 10px;
                padding: 10px 14px;
                border-left: 2px solid rgba(110,207,246,0.35);
            """)
        else:
            spk = QLabel("TRIPSPHERE")
            spk.setStyleSheet(f"""
                color: {P['gold']};
                font-size: 9px;
                font-weight: 800;
                letter-spacing: 1.2px;
            """)
            msg = QLabel(text)
            msg.setWordWrap(True)
            msg.setStyleSheet(f"""
                color: {P['text']};
                font-size: 13px;
                font-weight: 500;
                line-height: 1.55;
                background: transparent;
                padding: 2px 0;
            """)

        ev.addWidget(spk)
        ev.addWidget(msg)

        # Fade older messages slightly
        total = self._dialogue_layout.count() - 1  # -1 for stretch
        if total > 2:
            # Reduce opacity of all entries except the newest two
            for i in range(self._dialogue_layout.count() - 1):
                w = self._dialogue_layout.itemAt(i).widget()
                if w:
                    age = total - i
                    if age > 2:
                        effect = QGraphicsOpacityEffect(w)
                        effect.setOpacity(max(0.35, 1.0 - (age - 2) * 0.12))
                        w.setGraphicsEffect(effect)

        self._dialogue_layout.insertWidget(self._dialogue_layout.count() - 1, entry)
        QTimer.singleShot(60, self._scroll_to_bottom)

    def _clear_dialogue(self) -> None:
        self._dialogue_history.clear()
        while self._dialogue_layout.count() > 1:
            item = self._dialogue_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

    def _scroll_to_bottom(self) -> None:
        self._scroll.verticalScrollBar().setValue(
            self._scroll.verticalScrollBar().maximum()
        )

    # ═══════════════════════════════════════════════════════════════════════════
    # TRIP SNAPSHOT PANEL
    # ═══════════════════════════════════════════════════════════════════════════

    def _update_snapshot_panel(self) -> None:
        """Rebuild the Trip Snapshot panel from live ConversationState."""
        while self._snapshot_layout.count() > 0:
            item = self._snapshot_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        s = assistant_agent.state
        fields: list[tuple[str, str]] = []

        if s.travel_style:
            fields.append(("🏖️  Mood", s.travel_style))
        if s.destination:
            fields.append(("📍  Destination", s.destination))
        if s.origin:
            fields.append(("🛫  From", s.origin))
        if s.budget > 0:
            fields.append(("💰  Budget", f"{s.currency_sym}{s.budget:,.0f}"))
        if s.days > 0:
            fields.append(("📅  Duration", f"{s.days} days"))
        if s.travelers > 1:
            fields.append(("👥  Travelers", f"{s.travelers} people"))
        elif s.travelers == 1 and (s.destination or s.budget > 0):
            fields.append(("👥  Travelers", "Solo"))
        if s.transport_mode and s.transport_mode != "driving":
            fields.append(("🚗  Transport", s.transport_mode.capitalize()))

        if not fields:
            self._snapshot_layout.addWidget(self._snapshot_empty)
            return

        for label, val in fields:
            row = QHBoxLayout()
            row.setContentsMargins(0, 1, 0, 1)
            lbl = QLabel(label)
            lbl.setStyleSheet(f"color: {P['muted']}; font-size: 11px; font-weight: 600;")
            val_lbl = QLabel(str(val))
            val_lbl.setStyleSheet(f"color: {P['goldL']}; font-size: 11px; font-weight: 700;")
            row.addWidget(lbl)
            row.addStretch()
            row.addWidget(val_lbl)
            container = QWidget()
            container.setStyleSheet("background: transparent;")
            container.setLayout(row)
            self._snapshot_layout.addWidget(container)

        # Thin divider at bottom
        div = QFrame()
        div.setFixedHeight(1)
        div.setStyleSheet(f"background: {P['border2']}; border: none;")
        self._snapshot_layout.addWidget(div)

    # ═══════════════════════════════════════════════════════════════════════════
    # RECOMMENDATION CARDS (unchanged logic, premium style)
    # ═══════════════════════════════════════════════════════════════════════════

    def _clear_recommendations(self) -> None:
        while self._rec_layout.count() > 0:
            item = self._rec_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self._rec_header.setVisible(False)
        self._rec_scroll.setVisible(False)

    def _render_recommendations(self, cards: list[dict]) -> None:
        self._clear_recommendations()
        if not cards:
            return
        count = 0
        for card in cards:
            w = self._build_recommendation_card(card)
            if w:
                self._rec_layout.addWidget(w)
                count += 1
        if count > 0:
            self._rec_header.setVisible(True)
            self._rec_scroll.setVisible(True)

    def _build_recommendation_card(self, card: dict) -> QWidget | None:
        c_type = card.get("type", "")

        # ── Nearby place / destination ──────────────────────────────────────
        if c_type == "nearby_place" or ("category" in card and ("lat" in card or "latitude" in card)):
            w = QFrame()
            w.setStyleSheet(f"""
                QFrame {{
                    background: {P['card']};
                    border: 1px solid {P['border']};
                    border-radius: 12px;
                }}
            """)
            lay = QVBoxLayout(w)
            lay.setContentsMargins(14, 11, 14, 11)
            lay.setSpacing(7)

            top = QHBoxLayout()
            name = QLabel(card.get("name", "Destination").upper())
            name.setStyleSheet(f"color: {P['text']}; font-weight: 800; font-size: 11px; letter-spacing: 0.5px;")
            top.addWidget(name, 1)
            cat_tag = _pill(card.get("category", "Place"), "rgba(105,201,154,0.10)", P["success"], 9)
            top.addWidget(cat_tag)
            lay.addLayout(top)

            if card.get("distance_km") is not None:
                d = QLabel(f"📍 {card.get('distance_km')} km away")
                d.setStyleSheet(f"color: {P['muted']}; font-size: 10px;")
                lay.addWidget(d)

            btn_row = QHBoxLayout()
            btn_row.setSpacing(6)
            for label, bg, fg, border, action in [
                ("◈ Explore", "rgba(255,255,255,0.04)", P["muted"], P["border"], lambda: self.navigate.emit("explore")),
            ]:
                b = QPushButton(label)
                b.setCursor(Qt.PointingHandCursor)
                b.setFixedHeight(26)
                b.setStyleSheet(f"background:{bg};color:{fg};border:1px solid {border};border-radius:7px;padding:0 10px;font-size:10px;font-weight:600;")
                b.clicked.connect(action)
                btn_row.addWidget(b)

            lat = card.get("lat") or card.get("latitude")
            lon = card.get("lon") or card.get("longitude")
            if lat and lon:
                mb = QPushButton("📍 Map")
                mb.setCursor(Qt.PointingHandCursor)
                mb.setFixedHeight(26)
                mb.setStyleSheet(f"background:rgba(110,207,246,0.10);color:{P['cyan']};border:1px solid rgba(110,207,246,0.25);border-radius:7px;padding:0 10px;font-size:10px;font-weight:600;")
                mb.clicked.connect(lambda _, lt=lat, ln=lon, nm=card.get("name", ""): (
                    self._map.center(lt, ln, zoom=15),
                    self._map.add_marker(lt, ln, nm, card.get("category", ""), "", 0, "place")
                ))
                btn_row.addWidget(mb)

            pb = QPushButton("📅 Plan")
            pb.setCursor(Qt.PointingHandCursor)
            pb.setFixedHeight(26)
            pb.setStyleSheet(f"background:rgba(216,177,90,0.10);color:{P['goldL']};border:1px solid rgba(216,177,90,0.25);border-radius:7px;padding:0 10px;font-size:10px;font-weight:600;")
            pb.clicked.connect(lambda _, nm=card.get("name", ""): self._submit_text(f"Plan a trip to {nm}"))
            btn_row.addWidget(pb)
            btn_row.addStretch()
            lay.addLayout(btn_row)
            return w

        # ── Flight card ─────────────────────────────────────────────────────
        elif "airline" in card or c_type == "flight":
            w = QFrame()
            w.setStyleSheet(f"background:{P['card']};border:1px solid {P['border']};border-radius:12px;")
            lay = QVBoxLayout(w)
            lay.setContentsMargins(14, 11, 14, 11)
            lay.setSpacing(5)
            top = QHBoxLayout()
            top.addWidget(QLabel(f"✈️  {card.get('airline')} ({card.get('airline_code', '')})"))
            top.addStretch()
            pv = card.get("price_estimated")
            if pv is not None:
                pr = QLabel(f"{card.get('currency_sym','₹')}{pv:,.0f}")
                pr.setStyleSheet(f"color:{P['goldL']};font-weight:800;font-size:12px;")
                top.addWidget(pr)
            lay.addLayout(top)
            info = QLabel(f"🕒 {card.get('departure_time')} → {card.get('arrival_time')}  •  ⏱ {card.get('duration_str')}")
            info.setStyleSheet(f"color:{P['muted']};font-size:10px;")
            lay.addWidget(info)
            return w

        # ── Hotel card ──────────────────────────────────────────────────────
        elif "room_type" in card or c_type == "hotel":
            w = QFrame()
            w.setStyleSheet(f"background:{P['card']};border:1px solid {P['border']};border-radius:12px;")
            lay = QVBoxLayout(w)
            lay.setContentsMargins(14, 11, 14, 11)
            lay.setSpacing(5)
            top = QHBoxLayout()
            top.addWidget(QLabel(f"🏨  {card.get('name')}"))
            top.addStretch()
            pv = card.get("price_per_night") or card.get("price_estimated")
            if pv is not None:
                pr = QLabel(f"{card.get('currency_sym','₹')}{pv:,.0f}/nt")
                pr.setStyleSheet(f"color:{P['goldL']};font-weight:800;font-size:12px;")
                top.addWidget(pr)
            lay.addLayout(top)
            desc = QLabel(f"★ {card.get('rating', 4.5)}  •  {card.get('location', '')}")
            desc.setStyleSheet(f"color:{P['muted']};font-size:10px;")
            lay.addWidget(desc)
            return w

        return None

    # ═══════════════════════════════════════════════════════════════════════════
    # MAP ACTIONS (unchanged)
    # ═══════════════════════════════════════════════════════════════════════════

    def _execute_map_action(self, action: dict) -> None:
        a_type = action.get("type")
        if a_type == "center":
            lat, lon = action.get("lat"), action.get("lon")
            name = action.get("name", "Location")
            if lat and lon:
                self._map.center(lat, lon, zoom=12)
                self._map.add_marker(lat, lon, name, "Destination", "", 1, "main")
        elif a_type == "route":
            coords = action.get("coords", [])
            if len(coords) >= 2:
                self._map.draw_route(coords)
                self._map.fit_bounds(coords)
        elif a_type == "nearby_places":
            self._map.clear_markers()
            places = action.get("places", [])
            center_info = action.get("center", {})
            c_lat, c_lon = center_info.get("lat"), center_info.get("lon")
            if c_lat and c_lon:
                self._map.center(c_lat, c_lon, zoom=13)
                self._map.add_marker(c_lat, c_lon, center_info.get("name", "Search Center"), "Center", "", 0, "main")
            for p in places:
                p_lat = p.get("lat") or p.get("latitude")
                p_lon = p.get("lon") or p.get("longitude")
                if p_lat and p_lon:
                    self._map.add_marker(p_lat, p_lon, p.get("name", "Place"),
                                         p.get("category", ""), p.get("address", ""),
                                         p.get("rating", 0), "place")

    # ═══════════════════════════════════════════════════════════════════════════
    # CLEANUP
    # ═══════════════════════════════════════════════════════════════════════════

    def cleanup(self) -> None:
        """Stop voice worker and audio playback when navigating away."""
        if self._voice_worker:
            self._voice_worker.stop()
        if self._worker_thread and self._worker_thread.isRunning():
            self._worker_thread.quit()
            self._worker_thread.wait(1000)
