"""
Budget analytics screen — responsive charts and budget summaries across trips.
"""
from __future__ import annotations
import logging

from PySide6.QtCore    import Qt
from PySide6.QtWidgets import (
    QComboBox, QFrame, QHBoxLayout, QLabel, QScrollArea,
    QSizePolicy, QVBoxLayout, QWidget
)
from app.config import COLORS, FONT, DEFAULT_CURRENCY
from app.database.repositories import trip_repo, expense_repo
from app.services.expense_service import expense_service
from app.ui.widgets.charts import DonutChart, BarChart, LineChart, BudgetGaugeChart

logger = logging.getLogger(__name__)


class BudgetScreen(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._current_trip_id: int | None = None
        self._build_ui()
        self.refresh()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(36, 36, 36, 36)
        layout.setSpacing(24)

        # Header
        hdr = QHBoxLayout()
        title_v = QVBoxLayout()
        title_v.setSpacing(4)
        title = QLabel("Travel Spending & Analytics")
        title.setStyleSheet(f"color:{COLORS['text']};font-size:{FONT['3xl']};font-weight:900;letter-spacing:-1px;background:transparent;")
        title_v.addWidget(title)

        sub = QLabel("Visual breakdown of your trip budgets, daily trends, and spending categories")
        sub.setStyleSheet(f"color:{COLORS['text_muted']};font-size:{FONT['base']};background:transparent;")
        title_v.addWidget(sub)
        hdr.addLayout(title_v)
        hdr.addStretch()

        self._trip_combo = QComboBox()
        self._trip_combo.setMinimumWidth(220)
        self._trip_combo.setFixedHeight(40)
        self._trip_combo.currentIndexChanged.connect(self._on_trip_changed)
        hdr.addWidget(QLabel("Select Trip:", styleSheet=f"color:{COLORS['text_muted']};font-size:13px;font-weight:600;background:transparent;"))
        hdr.addWidget(self._trip_combo)
        layout.addLayout(hdr)

        # Main Scrollable Content
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setStyleSheet("background:transparent;")
        
        self._content = QWidget()
        self._content.setStyleSheet("background:transparent;")
        self._content_layout = QVBoxLayout(self._content)
        self._content_layout.setContentsMargins(0, 0, 0, 0)
        self._content_layout.setSpacing(24)
        self._content_layout.addStretch()
        
        scroll.setWidget(self._content)
        layout.addWidget(scroll, 1)

    def refresh(self) -> None:
        self._trip_combo.blockSignals(True)
        self._trip_combo.clear()
        trips = trip_repo.get_all()
        for t in trips:
            self._trip_combo.addItem(t["name"], t["id"])
        self._trip_combo.blockSignals(False)

        if trips:
            self._current_trip_id = trips[0]["id"]
            self._render_charts()
        else:
            self._show_empty()

    def _on_trip_changed(self, idx: int) -> None:
        trip_id = self._trip_combo.currentData()
        if trip_id is not None:
            self._current_trip_id = trip_id
            self._render_charts()

    def _render_charts(self) -> None:
        if self._current_trip_id is None:
            return
        self._clear_charts()
        summary = expense_service.get_trip_summary(self._current_trip_id)
        sym = summary.get("currency_sym", DEFAULT_CURRENCY)

        # 1. Analytics Hero Metric Tile
        hero = QFrame()
        hero.setStyleSheet(f"""
            QFrame {{
                background: {COLORS['bg_card']};
                border: 1px solid {COLORS['border']};
                border-radius: 20px;
                padding: 24px;
            }}
        """)
        h_layout = QHBoxLayout(hero)
        h_layout.setContentsMargins(24, 16, 24, 16)
        h_layout.setSpacing(32)

        col1 = QVBoxLayout()
        col1.setSpacing(4)
        col1.addWidget(QLabel("TOTAL SPENT", styleSheet=f"color:{COLORS['text_subtle']};font-size:11px;font-weight:800;letter-spacing:1.5px;"))
        spent_lbl = QLabel(f"{sym}{summary['spent']:,.0f}")
        spent_lbl.setStyleSheet(f"color:{COLORS['text']};font-size:36px;font-weight:900;letter-spacing:-1px;")
        col1.addWidget(spent_lbl)
        h_layout.addLayout(col1)

        col2 = QVBoxLayout()
        col2.setSpacing(4)
        col2.addWidget(QLabel("BUDGET UTILIZATION", styleSheet=f"color:{COLORS['text_subtle']};font-size:11px;font-weight:800;letter-spacing:1.5px;"))
        pct_lbl = QLabel(f"{summary['pct']:.0f}% of {sym}{summary['budget']:,.0f}")
        pct_lbl.setStyleSheet(f"color:{COLORS['accent']};font-size:36px;font-weight:900;letter-spacing:-1px;")
        col2.addWidget(pct_lbl)
        h_layout.addLayout(col2)

        rem = max(summary['budget'] - summary['spent'], 0)
        col3 = QVBoxLayout()
        col3.setSpacing(4)
        col3.addWidget(QLabel("REMAINING BUDGET", styleSheet=f"color:{COLORS['text_subtle']};font-size:11px;font-weight:800;letter-spacing:1.5px;"))
        rem_lbl = QLabel(f"{sym}{rem:,.0f}")
        rem_lbl.setStyleSheet(f"color:{COLORS['sand']};font-size:36px;font-weight:900;letter-spacing:-1px;")
        col3.addWidget(rem_lbl)
        h_layout.addLayout(col3)

        self._insert(hero)

        # 2. Row 1: Gauge + Donut Chart
        row1 = QHBoxLayout()
        row1.setSpacing(20)

        gauge = BudgetGaugeChart(
            pct=summary["pct"], spent=summary["spent"],
            budget=summary["budget"], currency_sym=sym,
            title="Budget Utilization"
        )
        gauge.setMinimumHeight(320)
        gauge.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        row1.addWidget(gauge, 1)

        if summary["by_category"]:
            donut = DonutChart(summary["by_category"], "Category Distribution", sym)
            donut.setMinimumHeight(320)
            donut.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            row1.addWidget(donut, 1)
        else:
            no_data = QLabel("No category expenses logged yet.")
            no_data.setAlignment(Qt.AlignCenter)
            no_data.setStyleSheet(f"color:{COLORS['text_muted']};font-size:{FONT['base']};background:{COLORS['bg_card']};border-radius:20px;")
            row1.addWidget(no_data, 1)

        row1_w = QWidget()
        row1_w.setLayout(row1)
        self._insert(row1_w)

        # 3. Row 2: Bar Chart (Spending by Category)
        if summary["by_category"]:
            bar = BarChart(summary["by_category"], "Spending by Category", sym)
            bar.setMinimumHeight(300)
            bar.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            self._insert(bar)

        # 4. Row 3: Daily Spending Trend (Line Chart)
        daily = summary.get("daily_totals", [])
        if daily:
            line = LineChart(daily, "Daily Spending Trend", sym)
            line.setMinimumHeight(300)
            line.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            self._insert(line)

    def _show_empty(self) -> None:
        self._clear_charts()
        lbl = QLabel("No trips found. Create your first trip to view financial analytics.")
        lbl.setAlignment(Qt.AlignCenter)
        lbl.setStyleSheet(f"color:{COLORS['text_muted']};font-size:{FONT['lg']};padding:60px;")
        self._insert(lbl)

    def _clear_charts(self) -> None:
        while self._content_layout.count() > 1:
            item = self._content_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

    def _insert(self, widget: QWidget) -> None:
        self._content_layout.insertWidget(self._content_layout.count() - 1, widget)
