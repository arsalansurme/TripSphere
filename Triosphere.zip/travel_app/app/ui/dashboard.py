"""
Home / Dashboard Screen — full-screen slideshow background + glassmorphism cards.
"""
from __future__ import annotations

import logging
from datetime import datetime

from PySide6.QtCore import Qt, Signal, QTimer, QRect
from PySide6.QtGui import QPixmap, QLinearGradient, QColor, QPainter, QPainterPath, QPen, QRadialGradient
from PySide6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QScrollArea, QSizePolicy, QVBoxLayout, QWidget
)
from app.config import COLORS, FONT, DEFAULT_CURRENCY, ASSETS_DIR
from app.database.repositories import trip_repo, destination_repo, expense_repo, user_repo

logger = logging.getLogger(__name__)

# ── Slideshow images (cycle every 6 s) ────────────────────────────────────── i  had write this code not ai sooooooooooooooooooo its my work....
SLIDESHOW_IMAGES = [
    "goa_beach_sunset.jpg",
    "kyoto_japan.jpg",
    "swiss_alps.jpg",
    "bali_indonesia.jpg",
]

# ── Curated explore places ────────────────────────────────────────────────────
DISCOVER_PLACES = [
    {"name": "Kyoto, Japan",   "tag": "CULTURE",  "img": "kyoto_japan.jpg",
     "lat": 35.0116, "lon": 135.7681, "tag_color": "#C084FC"},
    {"name": "Swiss Alps",     "tag": "NATURE",   "img": "swiss_alps.jpg",
     "lat": 46.8182, "lon": 8.2275,   "tag_color": "#4ADE80"},
    {"name": "Bali, Indonesia","tag": "TROPICAL", "img": "bali_indonesia.jpg",
     "lat": -8.3405, "lon": 115.0920, "tag_color": "#FB923C"},
]

CATEGORY_FILTERS = [
    ("BEACH",     {"lat": 15.2993, "lon": 74.1240,  "name": "Goa Beaches"}),
    ("MOUNTAINS", {"lat": 46.8182, "lon": 8.2275,   "name": "Swiss Alps"}),
    ("CITY",      {"lat": 19.0760, "lon": 72.8777,  "name": "Mumbai"}),
    ("NATURE",    {"lat": -8.3405, "lon": 115.0920, "name": "Bali"}),
]

GLASS_CARD  = "background: rgba(10,10,14,0.72); border: 1px solid rgba(255,255,255,0.07); border-radius: 20px;"
GLASS_LIGHT = "background: rgba(18,18,24,0.80); border: 1px solid rgba(255,255,255,0.09); border-radius: 16px;"


# ── Helpers ───────────────────────────────────────────────────────────────────
def _load_raw(name: str) -> QPixmap | None:
    p = ASSETS_DIR / name
    if p.exists():
        px = QPixmap(str(p))
        return px if not px.isNull() else None
    return None


def _fmt_date(d: str) -> str:
    try:
        return datetime.strptime(d, "%Y-%m-%d").strftime("%d %b").upper().lstrip("0")
    except Exception:
        return d or "TBD"


def _calc_days(s: str, e: str) -> int:
    try:
        return max(1, (datetime.strptime(e, "%Y-%m-%d") - datetime.strptime(s, "%Y-%m-%d")).days + 1)
    except Exception:
        return 1


# ── Interactive draggable globe ────────────────────────────────────────────────
import math as _math

# Approximate lon/lat points on continents for globe decoration
_GLOBE_DOTS = [
    # North America
    (-100, 50), (-80, 40), (-90, 30), (-120, 35), (-70, 45),
    # South America
    (-60, -10), (-47, -15), (-70, -30), (-55, -25),
    # Europe
    (10, 50), (2, 48), (15, 52), (25, 40), (-5, 37),
    # Africa
    (20, 0), (35, 5), (15, 15), (30, -10), (10, -5),
    # Asia
    (80, 30), (100, 20), (120, 35), (140, 35), (60, 50), (45, 25),
    # Australia
    (135, -25), (150, -30), (125, -20),
    # India
    (78, 22), (77, 28), (80, 15),
]

class _InteractiveGlobe(QWidget):
    """3D-looking globe that auto-rotates and responds to mouse drag."""
    clicked_signal = Signal()

    def __init__(self, size: int = 200, parent=None):
        super().__init__(parent)
        self._sz = size
        self._radius = (size // 2) - 8
        self.setFixedSize(size, size)
        self.setCursor(Qt.OpenHandCursor)

        # Rotation angles
        self._lon_offset = 0.0   # horizontal spin angle (degrees)
        self._lat_offset = 20.0  # vertical tilt (degrees)

        # Drag state
        self._dragging = False
        self._drag_start_x = 0
        self._drag_start_y = 0
        self._drag_lon_start = 0.0
        self._drag_lat_start = 0.0

        # Auto-rotate timer
        self._auto_timer = QTimer(self)
        self._auto_timer.timeout.connect(self._auto_rotate)
        self._auto_timer.start(30)

    def _auto_rotate(self):
        if not self._dragging:
            self._lon_offset = (self._lon_offset + 0.3) % 360
            self.update()

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._dragging = True
            self._drag_start_x = e.position().x()
            self._drag_start_y = e.position().y()
            self._drag_lon_start = self._lon_offset
            self._drag_lat_start = self._lat_offset
            self.setCursor(Qt.ClosedHandCursor)

    def mouseMoveEvent(self, e):
        if self._dragging:
            dx = e.position().x() - self._drag_start_x
            dy = e.position().y() - self._drag_start_y
            self._lon_offset = (self._drag_lon_start + dx * 0.5) % 360
            self._lat_offset = max(-60.0, min(60.0, self._drag_lat_start - dy * 0.4))
            self.update()

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._dragging = False
            self.setCursor(Qt.OpenHandCursor)
            # Small drag = click → emit signal
            if abs(e.position().x() - self._drag_start_x) < 5 and \
               abs(e.position().y() - self._drag_start_y) < 5:
                self.clicked_signal.emit()

    def _project(self, lon_deg: float, lat_deg: float) -> tuple[float, float, float]:
        """Project lon/lat to 3D with current rotation, return (x, y, z)."""
        lon_rad = _math.radians(lon_deg + self._lon_offset)
        lat_rad = _math.radians(lat_deg + self._lat_offset * 0.3)
        x = _math.cos(lat_rad) * _math.cos(lon_rad)
        y = _math.sin(lat_rad)
        z = _math.cos(lat_rad) * _math.sin(lon_rad)
        return x, y, z

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        cx = self.width() // 2
        cy = self.height() // 2
        r = self._radius

        # --- Gradient sphere base ---
        grad = QRadialGradient(cx - r * 0.25, cy - r * 0.25, r * 1.4)
        grad.setColorAt(0.0, QColor(80, 140, 220, 255))
        grad.setColorAt(0.45, QColor(30, 80, 160, 245))
        grad.setColorAt(0.75, QColor(10, 40, 100, 230))
        grad.setColorAt(1.0, QColor(4, 16, 60, 200))
        painter.setBrush(grad)
        painter.setPen(Qt.NoPen)
        painter.drawEllipse(cx - r, cy - r, r * 2, r * 2)

        # --- Latitude lines ---
        pen_lat = QPen(QColor(255, 255, 255, 18), 0.8)
        painter.setPen(pen_lat)
        painter.setBrush(Qt.NoBrush)
        for lat in [-60, -30, 0, 30, 60]:
            pts = []
            for lo in range(0, 361, 4):
                x3, y3, z3 = self._project(lo, lat)
                if z3 > -0.2:  # visible hemisphere
                    sx = cx + int(x3 * r)
                    sy = cy - int(y3 * r)
                    pts.append((sx, sy))
            if len(pts) > 1:
                for i in range(len(pts) - 1):
                    painter.drawLine(pts[i][0], pts[i][1], pts[i+1][0], pts[i+1][1])

        # --- Longitude lines ---
        pen_lon = QPen(QColor(255, 255, 255, 12), 0.7)
        painter.setPen(pen_lon)
        for lon in range(0, 360, 30):
            pts = []
            for la in range(-90, 91, 4):
                x3, y3, z3 = self._project(lon, la)
                if z3 > -0.2:
                    sx = cx + int(x3 * r)
                    sy = cy - int(y3 * r)
                    pts.append((sx, sy))
            if len(pts) > 1:
                for i in range(len(pts) - 1):
                    painter.drawLine(pts[i][0], pts[i][1], pts[i+1][0], pts[i+1][1])

        # --- Land dots ---
        for (lon_d, lat_d) in _GLOBE_DOTS:
            x3, y3, z3 = self._project(lon_d, lat_d)
            if z3 > 0.05:
                brightness = 0.4 + 0.6 * z3
                sx = cx + int(x3 * r)
                sy = cy - int(y3 * r)
                dot_r = max(1, int(3 * brightness))
                alpha = int(200 * brightness)
                painter.setBrush(QColor(140, 220, 140, alpha))
                painter.setPen(Qt.NoPen)
                painter.drawEllipse(sx - dot_r, sy - dot_r, dot_r * 2, dot_r * 2)

        # --- Gloss highlight ---
        gloss = QRadialGradient(cx - r * 0.3, cy - r * 0.3, r * 0.7)
        gloss.setColorAt(0.0, QColor(255, 255, 255, 55))
        gloss.setColorAt(1.0, QColor(255, 255, 255, 0))
        painter.setBrush(gloss)
        painter.setPen(Qt.NoPen)
        painter.drawEllipse(cx - r, cy - r, r * 2, r * 2)

        # --- Outer ring ---
        pen_ring = QPen(QColor(100, 180, 255, 60), 1.5)
        painter.setPen(pen_ring)
        painter.setBrush(Qt.NoBrush)
        painter.drawEllipse(cx - r, cy - r, r * 2, r * 2)


# ── Fullscreen slideshow background widget ─────────────────────────────────────
class _SlideshowBg(QWidget):
    """Sits behind everything and paints cycling full-screen travel photos with smooth cross-fade."""

    def __init__(self, images: list[str], parent=None):
        super().__init__(parent)
        self._pixmaps = [_load_raw(n) for n in images]
        self._pixmaps = [p for p in self._pixmaps if p]
        self.setAttribute(Qt.WA_TransparentForMouseEvents)
        self.lower()               # always behind siblings

        self._current_idx = 0
        self._next_idx = 0
        self._fade_val = 1.0

        if self._pixmaps:
            self._timer = QTimer(self)
            self._timer.timeout.connect(self._start_fade)
            self._timer.start(6000)

            self._fade_timer = QTimer(self)
            self._fade_timer.timeout.connect(self._tick_fade)

    def _start_fade(self):
        if len(self._pixmaps) < 2:
            return
        self._current_idx = self._next_idx
        self._next_idx = (self._next_idx + 1) % len(self._pixmaps)
        self._fade_val = 0.0
        self._fade_timer.start(25)

    def _tick_fade(self):
        self._fade_val += 0.04
        if self._fade_val >= 1.0:
            self._fade_val = 1.0
            self._fade_timer.stop()
        self.update()

    def paintEvent(self, event):
        if not self._pixmaps:
            return
        painter = QPainter(self)
        painter.setRenderHint(QPainter.SmoothPixmapTransform)

        if self._fade_val < 1.0:
            pix_curr = self._pixmaps[self._current_idx]
            scaled_curr = pix_curr.scaled(self.width(), self.height(),
                                          Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
            x_curr = (self.width() - scaled_curr.width()) // 2
            y_curr = (self.height() - scaled_curr.height()) // 2
            painter.setOpacity(1.0 - self._fade_val)
            painter.drawPixmap(x_curr, y_curr, scaled_curr)

        if self._fade_val > 0.0:
            pix_next = self._pixmaps[self._next_idx]
            scaled_next = pix_next.scaled(self.width(), self.height(),
                                          Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
            x_next = (self.width() - scaled_next.width()) // 2
            y_next = (self.height() - scaled_next.height()) // 2
            painter.setOpacity(self._fade_val)
            painter.drawPixmap(x_next, y_next, scaled_next)

        painter.setOpacity(1.0)
        # Heavy dark overlay so UI stays readable
        grad = QLinearGradient(0, 0, 0, self.height())
        grad.setColorAt(0.0, QColor(5, 5, 8, 210))
        grad.setColorAt(0.4, QColor(5, 5, 8, 160))
        grad.setColorAt(1.0, QColor(5, 5, 8, 230))
        painter.fillRect(self.rect(), grad)


# ── Photo Panel (rounded, paintEvent-based) ────────────────────────────────────
class _PhotoPanel(QFrame):
    """Fixed-size widget rendering an image via paintEvent with rounded clipping."""

    def __init__(self, filename: str, w: int, h: int, radius: int = 16, parent=None):
        super().__init__(parent)
        self.setFixedSize(w, h)
        self._radius = radius
        self._pix = _load_raw(filename) or _load_raw("goa_beach_sunset.jpg")

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setRenderHint(QPainter.SmoothPixmapTransform)
        path = QPainterPath()
        path.addRoundedRect(0, 0, self.width(), self.height(), self._radius, self._radius)
        painter.setClipPath(path)
        if self._pix:
            scaled = self._pix.scaled(self.width(), self.height(),
                                      Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
            x = (self.width() - scaled.width()) // 2
            y = (self.height() - scaled.height()) // 2
            painter.drawPixmap(x, y, scaled)
        grad = QLinearGradient(0, 0, 0, self.height())
        grad.setColorAt(0.0, QColor(0, 0, 0, 0))
        grad.setColorAt(0.5, QColor(0, 0, 0, 30))
        grad.setColorAt(1.0, QColor(0, 0, 0, 200))
        painter.fillRect(self.rect(), grad)


# ── Place Card ────────────────────────────────────────────────────────────────
class PlaceCard(QFrame):
    explore_requested = Signal(float, float, str)

    def __init__(self, place: dict, parent=None):
        super().__init__(parent)
        self._place = place
        self._pix   = _load_raw(place["img"])
        self.setCursor(Qt.PointingHandCursor)
        self.setFixedSize(220, 280)

        tag_color = place.get("tag_color", "#A1A1AA")
        self._tag_lbl = QLabel(place["tag"], self)
        self._tag_lbl.setStyleSheet(f"""
            background: rgba(0,0,0,0.65); color: {tag_color};
            font-size: 9px; font-weight: 900; letter-spacing: 1.5px;
            border-radius: 8px; padding: 4px 10px;
        """)
        self._tag_lbl.adjustSize()
        self._tag_lbl.move(14, 228)

        self._name_lbl = QLabel(place["name"], self)
        self._name_lbl.setStyleSheet(
            "color: #FFFFFF; font-size: 13px; font-weight: 800; background: transparent;")
        self._name_lbl.adjustSize()
        self._name_lbl.move(14, 252)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setRenderHint(QPainter.SmoothPixmapTransform)
        path = QPainterPath()
        path.addRoundedRect(0, 0, self.width(), self.height(), 20, 20)
        painter.setClipPath(path)
        if self._pix:
            scaled = self._pix.scaled(self.width(), self.height(),
                                      Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
            painter.drawPixmap((self.width()-scaled.width())//2,
                               (self.height()-scaled.height())//2, scaled)
        grad = QLinearGradient(0, 0, 0, self.height())
        grad.setColorAt(0.0, QColor(0,0,0,0));  grad.setColorAt(0.5, QColor(0,0,0,20))
        grad.setColorAt(1.0, QColor(0,0,0,220))
        painter.fillRect(self.rect(), grad)

    def mousePressEvent(self, e):
        p = self._place
        self.explore_requested.emit(p["lat"], p["lon"], p["name"])


# ── Upcoming Trip Card ─────────────────────────────────────────────────────────
class UpcomingTripCard(QFrame):
    clicked = Signal(int)

    def __init__(self, trip: dict, parent=None):
        super().__init__(parent)
        self._tid = trip.get("id", -1)
        self.setCursor(Qt.PointingHandCursor)
        self.setFixedHeight(160)
        self.setStyleSheet(f"""
            UpcomingTripCard {{ {GLASS_CARD} }}
            UpcomingTripCard:hover {{ border-color: rgba(255,255,255,0.18); background: rgba(16,16,20,0.82); }}
        """)

        outer = QHBoxLayout(self)
        outer.setContentsMargins(0, 0, 16, 0)
        outer.setSpacing(0)

        # Left photo
        img_name = trip.get("cover_image") or "goa_beach_sunset.jpg"
        img_panel = _PhotoPanel(img_name, 220, 160, radius=20)

        cat = trip.get("category", "BEACH ESCAPE").upper()
        badge = QLabel(cat, img_panel)
        badge.setStyleSheet("""
            background: rgba(0,0,0,0.70); color: #F5F5F5;
            font-size: 10px; font-weight: 800; letter-spacing: 1px;
            border-radius: 8px; padding: 4px 10px;
        """)
        badge.adjustSize()
        badge.move(12, 12)

        name_lbl = QLabel(trip.get("name", "Adventure"), img_panel)
        name_lbl.setStyleSheet("color: #FFFFFF; font-size: 13px; font-weight: 800; background: transparent;")
        name_lbl.adjustSize()
        name_lbl.move(12, 160 - 14 - name_lbl.height())
        outer.addWidget(img_panel)

        # Right info
        right = QVBoxLayout()
        right.setContentsMargins(22, 20, 0, 20)
        right.setSpacing(8)

        start = trip.get("start_date", "")
        end   = trip.get("end_date", "")
        date_row = QHBoxLayout()
        date_ico = QLabel("🕐")
        date_ico.setStyleSheet("font-size: 12px; background: transparent;")
        date_row.addWidget(date_ico)
        date_lbl = QLabel(f"{_fmt_date(start)} — {_fmt_date(end)}" if start else "Dates TBD")
        date_lbl.setStyleSheet(f"color: {COLORS['sand']}; font-size: 12px; font-weight: 700; background: transparent;")
        date_row.addWidget(date_lbl)
        date_row.addStretch()
        right.addLayout(date_row)

        days = _calc_days(start, end)
        dest = trip.get("destination", "")
        sub = QLabel(f"{days} Days • {dest}" if dest else f"{days} Days")
        sub.setStyleSheet(f"color: {COLORS['text_muted']}; font-size: 12px; background: transparent;")
        right.addWidget(sub)
        right.addStretch()

        budget = trip.get("budget", 0) or 0
        spent  = 0
        try:
            spent = expense_repo.get_total_spent(self._tid) or 0
        except Exception:
            pass

        brow = QHBoxLayout()
        bl = QLabel("BUDGET PROGRESS")
        bl.setStyleSheet("color: #52525B; font-size: 10px; font-weight: 800; letter-spacing: 1px; background: transparent;")
        brow.addWidget(bl)
        brow.addStretch()
        ba = QLabel(f"₹{spent/1000:.1f}k / ₹{budget/1000:.0f}k" if budget > 0 else "No budget set")
        ba.setStyleSheet(f"color: {COLORS['sand']}; font-size: 10px; font-weight: 700; background: transparent;")
        brow.addWidget(ba)
        right.addLayout(brow)

        bar = QFrame()
        bar.setFixedHeight(6)
        bar.setStyleSheet("background: rgba(255,255,255,0.10); border-radius: 3px;")
        fill = QFrame(bar)
        fill.setFixedHeight(6)
        fill.setStyleSheet(f"background: {COLORS['sand']}; border-radius: 3px;")
        pct = min((spent/budget) if budget > 0 else 0.3, 1.0)
        bar.resizeEvent = lambda e, f=fill, p=pct: f.setFixedWidth(max(6, int(bar.width()*p)))
        right.addWidget(bar)
        outer.addLayout(right, 1)

        arr = QPushButton("→")
        arr.setFixedSize(40, 40)
        arr.setCursor(Qt.PointingHandCursor)
        arr.setStyleSheet(f"""
            QPushButton {{ background: {COLORS['sand']}; color: #111; border-radius: 20px;
                           font-size: 18px; font-weight: 800; border: none; }}
            QPushButton:hover {{ background: {COLORS['accent_light']}; }}
        """)
        arr.clicked.connect(lambda: self.clicked.emit(self._tid))
        outer.addWidget(arr, 0, Qt.AlignVCenter)

    def mousePressEvent(self, e):
        self.clicked.emit(self._tid)


# ── Stat Tile ──────────────────────────────────────────────────────────────────
class StatTile(QFrame):
    def __init__(self, number: str, label: str, parent=None):
        super().__init__(parent)
        self.setStyleSheet(GLASS_CARD)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.setFixedHeight(110)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(22, 20, 22, 18)
        lay.setSpacing(4)
        self._num = QLabel(number)
        self._num.setStyleSheet(f"color: {COLORS['sand']}; font-size: 28px; font-weight: 900; letter-spacing: -1px; background: transparent;")
        lay.addWidget(self._num)
        lbl = QLabel(label.upper())
        lbl.setStyleSheet("color: #71717A; font-size: 10px; font-weight: 800; letter-spacing: 1px; background: transparent;")
        lay.addWidget(lbl)

    def set_number(self, v: str):
        self._num.setText(v)


# ── Quick Access Button ────────────────────────────────────────────────────────
class QuickAccessBtn(QFrame):
    clicked_signal = Signal()

    def __init__(self, icon: str, label: str, parent=None):
        super().__init__(parent)
        self.setCursor(Qt.PointingHandCursor)
        self.setFixedSize(120, 72)
        self.setStyleSheet(f"""
            QuickAccessBtn {{ {GLASS_CARD} }}
            QuickAccessBtn:hover {{ border-color: rgba(255,255,255,0.18); }}
        """)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 12, 0, 10)
        lay.setSpacing(4)
        lay.setAlignment(Qt.AlignCenter)
        ico = QLabel(icon)
        ico.setAlignment(Qt.AlignCenter)
        ico.setStyleSheet("font-size: 22px; background: transparent;")
        lay.addWidget(ico)
        txt = QLabel(label)
        txt.setAlignment(Qt.AlignCenter)
        txt.setStyleSheet(f"color: {COLORS['text_muted']}; font-size: 11px; font-weight: 600; background: transparent;")
        lay.addWidget(txt)

    def mousePressEvent(self, e):
        self.clicked_signal.emit()


# ── Dashboard Screen ───────────────────────────────────────────────────────────
class DashboardScreen(QWidget):
    navigate         = Signal(str)
    open_trip        = Signal(int)
    explore_location = Signal(float, float, str)
    search_requested = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._active_filter = "BEACH"
        self._search_query  = ""
        self._build_ui()
        QTimer.singleShot(120, self.refresh)

    def _build_ui(self):
        self.setStyleSheet("background: transparent;")

        # ── Fullscreen slideshow background ───────────────────────────────
        self._bg = _SlideshowBg(SLIDESHOW_IMAGES, parent=self)

        # ── Scrollable content on top ──────────────────────────────────────
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setStyleSheet("background: transparent; border: none;")
        scroll.viewport().setStyleSheet("background: transparent;")
        outer.addWidget(scroll)

        content = QWidget()
        content.setStyleSheet("background: transparent;")
        scroll.setWidget(content)

        self._layout = QVBoxLayout(content)
        self._layout.setContentsMargins(44, 32, 44, 56)
        self._layout.setSpacing(0)

        # ── 1. Search bar ──────────────────────────────────────────────────
        srow = QHBoxLayout()
        srow.addStretch()

        capsule = QFrame()
        capsule.setFixedHeight(52)
        capsule.setMinimumWidth(520)
        capsule.setStyleSheet("""
            QFrame {
                background: rgba(10,10,14,0.78);
                border-radius: 26px;
                border: 1px solid rgba(255,255,255,0.12);
            }
            QFrame:hover { border-color: rgba(255, 255, 255, 0.22); }
        """)
        cl = QHBoxLayout(capsule)
        cl.setContentsMargins(20, 0, 8, 0)
        cl.setSpacing(10)

        ico = QLabel("🔍")
        ico.setStyleSheet("font-size: 15px; background: transparent; color: #71717A;")
        cl.addWidget(ico)

        self._search_input = QLineEdit()
        self._search_input.setPlaceholderText("Where do you want to escape to?")
        self._search_input.setStyleSheet("""
            QLineEdit { background: transparent; border: none; color: #F5F5F5;
                        font-size: 14px; font-weight: 500; }
            QLineEdit::placeholder { color: #71717A; }
        """)
        self._search_input.returnPressed.connect(self._on_search)
        cl.addWidget(self._search_input, 1)

        sbtn = QPushButton("Search")
        sbtn.setFixedSize(96, 40)
        sbtn.setCursor(Qt.PointingHandCursor)
        sbtn.setStyleSheet(f"""
            QPushButton {{
                background: {COLORS['sand']}; color: #111111;
                border-radius: 20px; font-size: 13px; font-weight: 800;
                border: none; padding: 0 18px;
            }}
            QPushButton:hover {{ background: {COLORS['accent_light']}; }}
        """)
        sbtn.clicked.connect(self._on_search)
        cl.addWidget(sbtn)

        srow.addWidget(capsule)
        srow.addStretch()
        self._layout.addLayout(srow)
        self._layout.addSpacing(24)

        # ── 2. Quick access icons ─────────────────────────────────────────
        qarow = QHBoxLayout()
        qarow.addStretch()
        qarow.setSpacing(14)
        for icon, label in [("✈️", "Flight"), ("🏨", "Hotel"), ("🚆", "Train"), ("🚌", "Bus")]:
            btn = QuickAccessBtn(icon, label)
            btn.clicked_signal.connect(lambda: self.navigate.emit("explore"))
            qarow.addWidget(btn)
        qarow.addStretch()
        self._layout.addLayout(qarow)
        self._layout.addSpacing(40)

        # ── 3. Greeting + Interactive Globe ───────────────────────────────
        hero_row = QHBoxLayout()
        hero_row.setSpacing(32)

        # Left: text
        greet_v = QVBoxLayout()
        greet_v.setSpacing(4)
        hour = datetime.now().hour
        gtxt = "Good Morning," if hour < 12 else ("Good Afternoon," if hour < 17 else "Good Evening,")
        g1 = QLabel(gtxt)
        g1.setStyleSheet(f"color: {COLORS['sand']}; font-size: 14px; font-weight: 600; background: transparent;")
        greet_v.addWidget(g1)

        g2 = QLabel(user_repo.get_profile().get("name") or "Traveller")
        self._greeting_name_lbl = g2
        g2.setStyleSheet("color: #FFFFFF; font-size: 26px; font-weight: 900; background: transparent;")
        greet_v.addWidget(g2)

        greet_v.addStretch()
        hero_row.addLayout(greet_v, 1)


        self._layout.addLayout(hero_row)
        self._layout.addSpacing(36)

        # ── 4. Stats row ──────────────────────────────────────────────────
        yr_row = QHBoxLayout()
        yr_ico = QLabel("📈")
        yr_ico.setStyleSheet("font-size: 13px; background: transparent;")
        yr_row.addWidget(yr_ico)
        yr_lbl = QLabel("Your Travel Year")
        yr_lbl.setStyleSheet("color: #FFFFFF; font-size: 14px; font-weight: 700; background: transparent;")
        yr_row.addWidget(yr_lbl)
        yr_row.addStretch()
        self._layout.addLayout(yr_row)
        self._layout.addSpacing(14)

        srow2 = QHBoxLayout()
        srow2.setSpacing(14)
        self._stat_trips     = StatTile("0", "Trips")
        self._stat_places    = StatTile("0", "Places")
        self._stat_countries = StatTile("0", "Countries")
        self._stat_spent     = StatTile("₹0", "Total Spent")
        for t in (self._stat_trips, self._stat_places, self._stat_countries, self._stat_spent):
            srow2.addWidget(t)
        self._layout.addLayout(srow2)
        self._layout.addSpacing(36)

        # ── 5. Upcoming Trips ─────────────────────────────────────────────
        ut_row = QHBoxLayout()
        ut_ico = QLabel("📅")
        ut_ico.setStyleSheet("font-size: 13px; background: transparent;")
        ut_row.addWidget(ut_ico)
        self._ut_lbl = QLabel("Upcoming Trip")
        self._ut_lbl.setStyleSheet("color: #FFFFFF; font-size: 14px; font-weight: 700; background: transparent;")
        ut_row.addWidget(self._ut_lbl)
        ut_row.addStretch()
        self._layout.addLayout(ut_row)
        self._layout.addSpacing(14)

        self._trips_container = QVBoxLayout()
        self._trips_container.setSpacing(14)
        self._layout.addLayout(self._trips_container)
        self._layout.addSpacing(40)

        # ── 6. Places to explore ──────────────────────────────────────────
        p_hdr = QHBoxLayout()
        p_ico = QLabel("✈")
        p_ico.setStyleSheet("font-size: 13px; background: transparent;")
        p_hdr.addWidget(p_ico)
        p_lbl = QLabel("Places worth escaping to")
        p_lbl.setStyleSheet("color: #FFFFFF; font-size: 14px; font-weight: 700; background: transparent;")
        p_hdr.addWidget(p_lbl)
        p_hdr.addStretch()

        self._filter_btns: dict[str, QPushButton] = {}
        for cat, _ in CATEGORY_FILTERS:
            pill = QPushButton(cat)
            pill.setFixedHeight(30)
            pill.setCursor(Qt.PointingHandCursor)
            self._filter_btns[cat] = pill
            pill.clicked.connect(lambda _, c=cat: self._set_filter(c))
            p_hdr.addWidget(pill)

        self._layout.addLayout(p_hdr)
        self._update_filter_styles()
        self._layout.addSpacing(18)

        self._cards_row = QHBoxLayout()
        self._cards_row.setSpacing(18)
        self._layout.addLayout(self._cards_row)
        self._render_place_cards()

    def resizeEvent(self, event):
        """Keep slideshow background filling entire widget."""
        self._bg.setGeometry(QRect(0, 0, self.width(), self.height()))
        super().resizeEvent(event)

    # ── Filters ───────────────────────────────────────────────────────────────

    def _set_filter(self, cat: str):
        self._active_filter = cat
        self._update_filter_styles()
        # Navigate explore to the filter location
        for c, loc in CATEGORY_FILTERS:
            if c == cat:
                self.explore_location.emit(loc["lat"], loc["lon"], loc["name"])
                self.navigate.emit("explore")
                break

    def _update_filter_styles(self):
        for cat, pill in self._filter_btns.items():
            active = cat == self._active_filter
            if active:
                pill.setStyleSheet(f"""
                    QPushButton {{
                        background: {COLORS['sand']}; color: #111111;
                        border: none; border-radius: 15px; padding: 0 16px;
                        font-size: 10px; font-weight: 800; letter-spacing: 0.8px;
                    }}
                """)
            else:
                pill.setStyleSheet(f"""
                    QPushButton {{
                        background: rgba(255,255,255,0.08); color: {COLORS['text_muted']};
                        border: 1px solid rgba(255,255,255,0.10); border-radius: 15px;
                        padding: 0 16px; font-size: 10px; font-weight: 700; letter-spacing: 0.8px;
                    }}
                    QPushButton:hover {{ background: rgba(255,255,255,0.14); color: #FFF; }}
                """)

    def _render_place_cards(self):
        while self._cards_row.count():
            item = self._cards_row.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        for place in DISCOVER_PLACES:
            card = PlaceCard(place)
            card.explore_requested.connect(self._on_place_explore)
            self._cards_row.addWidget(card)
        self._cards_row.addStretch()

    def _on_place_explore(self, lat: float, lon: float, name: str):
        self.explore_location.emit(lat, lon, name)
        self.navigate.emit("explore")

    # ── Search ────────────────────────────────────────────────────────────────

    def _on_search(self):
        q = self._search_input.text().strip()
        if q:
            self.search_requested.emit(q)

    # ── Refresh ───────────────────────────────────────────────────────────────

    def refresh(self):
        try:
            self._greeting_name_lbl.setText(user_repo.get_profile().get("name") or "Traveller")
            self._refresh_stats()
            self._refresh_trips()
        except Exception as e:
            logger.error(f"Dashboard refresh error: {e}")

    def _refresh_stats(self):
        try:
            trips = trip_repo.get_all() or []
            spent = sum(expense_repo.get_total_spent(t["id"]) or 0 for t in trips)
            dests = destination_repo.get_all() or []
            countries = {t.get("destination", "") for t in trips if t.get("destination")}
            self._stat_trips.set_number(str(len(trips)))
            self._stat_places.set_number(str(len(dests)))
            self._stat_countries.set_number(str(len(countries)))
            self._stat_spent.set_number(
                f"₹{spent/100000:.2f}L" if spent >= 100000 else f"₹{spent:,.0f}")
        except Exception as e:
            logger.debug(f"Stats refresh: {e}")

    def _refresh_trips(self):
        while self._trips_container.count():
            item = self._trips_container.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        try:
            trips = trip_repo.get_all() or []
            today = datetime.today().date()
            upcoming = []
            for t in trips:
                try:
                    if datetime.strptime(t["end_date"], "%Y-%m-%d").date() >= today:
                        upcoming.append(t)
                except Exception:
                    upcoming.append(t)

            if not upcoming:
                upcoming = trips[:3]

            self._ut_lbl.setText(
                f"Upcoming Trips ({len(upcoming)})" if len(upcoming) > 1 else "Upcoming Trip")

            for trip in upcoming[:5]:
                card = UpcomingTripCard(trip)
                card.clicked.connect(self.open_trip.emit)
                self._trips_container.addWidget(card)

            if not upcoming:
                lbl = QLabel("No trips yet — head to Trips to start planning!")
                lbl.setStyleSheet(f"color: {COLORS['text_muted']}; font-size: 13px; padding: 8px 0;")
                self._trips_container.addWidget(lbl)

        except Exception as e:
            logger.error(f"Trips refresh: {e}")
