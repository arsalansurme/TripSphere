"""
Trips screen — list trips + create new trip dialog.
"""
from __future__ import annotations
import logging
from datetime import date

from PySide6.QtCore    import Qt, Signal, Slot, QObject, QThread
from PySide6.QtGui     import QPixmap, QPainter, QPainterPath, QLinearGradient, QColor, QCursor
from PySide6.QtWidgets import (
    QComboBox, QDateEdit, QDialog, QDialogButtonBox,
    QDoubleSpinBox, QFormLayout, QFrame, QHBoxLayout, QLabel,
    QLineEdit, QPushButton, QScrollArea, QSpinBox,
    QTextEdit, QVBoxLayout, QWidget
)
from app.config import COLORS, FONT, ASSETS_DIR
from app.database.repositories import trip_repo, expense_repo
from app.services.trip_service import trip_service
from app.ui.widgets.loading import EmptyStateWidget

logger = logging.getLogger(__name__)


class _TripRelay(QObject):
    """Safely dispatches worker signals onto the main UI thread."""
    _relay = Signal(object, object)

    def __init__(self, slot, parent: QObject | None = None):
        super().__init__(parent)
        self._slot = slot
        self._relay.connect(self._dispatch)

    @Slot(object, object)
    def _dispatch(self, origin, destination) -> None:
        self._slot(origin, destination)

    def receive(self, origin, destination) -> None:
        self._relay.emit(origin, destination)


class TripGeocodeWorker(QObject):
    finished = Signal(object, object)

    def __init__(self, origin: str, destination: str):
        super().__init__()
        self.origin = origin
        self.destination = destination

    def run(self):
        from app.api.geocoding import geocoding_service
        try:
            logger.info("[API request started] Trip origin geocode: %s", self.origin)
            origin_result = geocoding_service.geocode(self.origin)
            logger.info("[API response received] Trip origin geocode")
        except Exception as exc:
            logger.error("[API error] Trip origin geocode failed: %s", exc)
            origin_result = None
        try:
            logger.info("[API request started] Trip destination geocode: %s", self.destination)
            destination_result = geocoding_service.geocode(self.destination)
            logger.info("[API response received] Trip destination geocode")
        except Exception as exc:
            logger.error("[API error] Trip destination geocode failed: %s", exc)
            destination_result = None
        self.finished.emit(origin_result, destination_result)


def _load_pix_raw(filename: str) -> QPixmap | None:
    p = ASSETS_DIR / filename
    if p.exists():
        pix = QPixmap(str(p))
        if not pix.isNull():
            return pix
    return None


def _fmt_date(d: str) -> str:
    from datetime import datetime
    try:
        return datetime.strptime(d, "%Y-%m-%d").strftime("%b %d")
    except Exception:
        return d or ""


class JourneyCard(QFrame):
    """Tall vertical travel summary card matching the Journeys mockup."""
    clicked = Signal(int)

    def __init__(self, trip: dict, parent=None):
        super().__init__(parent)
        self._trip = trip
        self._tid = trip.get("id", -1)
        self.setCursor(QCursor(Qt.PointingHandCursor))
        self.setFixedSize(280, 440)
        self.setStyleSheet("JourneyCard { border-radius: 24px; background: #111; }")

        # Load cover image
        img_name = trip.get("cover_image", "goa_beach_sunset.jpg") or "goa_beach_sunset.jpg"
        from pathlib import Path
        if Path(img_name).is_absolute() and Path(img_name).exists():
            self._pix = QPixmap(img_name)
        else:
            self._pix = _load_pix_raw(img_name)
            if not self._pix:
                self._pix = _load_pix_raw("goa_beach_sunset.jpg")

        # Sub-widgets on top (placed absolutely)
        # Status badge (top-left)
        status = (trip.get("status") or "planned").upper()
        self._status_badge = QLabel(status, self)
        self._status_badge.setStyleSheet("""
            background: rgba(0, 0, 0, 0.55);
            color: #E4E4E7;
            font-size: 9px;
            font-weight: 800;
            letter-spacing: 0.8px;
            border-radius: 8px;
            padding: 4px 10px;
        """)
        self._status_badge.adjustSize()
        self._status_badge.move(16, 16)

        # Category badge (peach background, next to status)
        category = (trip.get("category") or "Beach").upper()
        self._cat_badge = QLabel(category, self)
        self._cat_badge.setStyleSheet("""
            background: #FDBA74;
            color: #C2410C;
            font-size: 9px;
            font-weight: 800;
            letter-spacing: 0.8px;
            border-radius: 8px;
            padding: 4px 10px;
        """)
        self._cat_badge.adjustSize()
        self._cat_badge.move(16 + self._status_badge.width() + 8, 16)

        # Options button "..." (top-right)
        self._opt_btn = QPushButton("•••", self)
        self._opt_btn.setFixedSize(28, 28)
        self._opt_btn.setCursor(Qt.PointingHandCursor)
        self._opt_btn.setStyleSheet("""
            QPushButton {
                background: rgba(0, 0, 0, 0.55);
                color: #FFFFFF;
                border-radius: 14px;
                font-size: 10px;
                font-weight: 800;
                border: none;
            }
            QPushButton:hover {
                background: rgba(0, 0, 0, 0.80);
            }
        """)
        self._opt_btn.move(280 - 28 - 16, 16)

        # Bottom Labels Group (Title, Dates, Budget, Progress bar)
        self._title_lbl = QLabel(trip.get("name", "Journey Name"), self)
        self._title_lbl.setWordWrap(True)
        self._title_lbl.setStyleSheet("""
            color: #FFFFFF;
            font-size: 20px;
            font-weight: 900;
            background: transparent;
        """)
        self._title_lbl.setFixedWidth(248)
        self._title_lbl.adjustSize()

        # Dates with calendar icon
        start_dt = _fmt_date(trip.get("start_date"))
        end_dt = _fmt_date(trip.get("end_date"))
        date_text = f"📅  {start_dt} - {end_dt}" if start_dt else "📅  Dates TBD"
        self._date_lbl = QLabel(date_text, self)
        self._date_lbl.setStyleSheet("""
            color: rgba(255,255,255,0.75);
            font-size: 12px;
            font-weight: 600;
            background: transparent;
        """)
        self._date_lbl.setFixedWidth(248)
        self._date_lbl.adjustSize()

        # Budget Progress
        budget = trip.get("budget", 0) or 0
        spent = 0
        try:
            spent = expense_repo.get_total_spent(self._tid) or 0
        except Exception:
            pass

        if budget > 0:
            b_txt = f"Budget Progress  ₹{spent:,.0f} / ₹{budget:,.0f}"
        else:
            b_txt = "Budget Progress  Setting up..."
        self._budget_lbl = QLabel(b_txt, self)
        self._budget_lbl.setStyleSheet("""
            color: rgba(255,255,255,0.70);
            font-size: 10px;
            font-weight: 700;
            background: transparent;
        """)
        self._budget_lbl.setFixedWidth(248)
        self._budget_lbl.adjustSize()

        # Progress bar
        self._bar_outer = QFrame(self)
        self._bar_outer.setFixedSize(248, 6)
        self._bar_outer.setStyleSheet("background: rgba(255,255,255,0.15); border-radius: 3px;")

        self._bar_fill = QFrame(self._bar_outer)
        self._bar_fill.setFixedHeight(6)
        self._bar_fill.setStyleSheet(f"background: {COLORS['sand']}; border-radius: 3px;")
        pct = min(spent / budget if budget > 0 else 0.1, 1.0)
        self._bar_fill.setFixedWidth(max(6, int(248 * pct)))

        # Position bottom layout elements absolute
        self._title_lbl.move(16, 300)
        self._date_lbl.move(16, 362)
        self._budget_lbl.move(16, 392)
        self._bar_outer.move(16, 412)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setRenderHint(QPainter.SmoothPixmapTransform)
        path = QPainterPath()
        path.addRoundedRect(0, 0, self.width(), self.height(), 24, 24)
        painter.setClipPath(path)

        if self._pix and not self._pix.isNull():
            scaled = self._pix.scaled(self.width(), self.height(),
                                      Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
            painter.drawPixmap((self.width() - scaled.width()) // 2,
                               (self.height() - scaled.height()) // 2, scaled)
        else:
            painter.fillRect(self.rect(), QColor(24, 24, 30))

        # Bottom gradient overlay for readability
        grad = QLinearGradient(0, 0, 0, self.height())
        grad.setColorAt(0.0, QColor(0, 0, 0, 0))
        grad.setColorAt(0.5, QColor(0, 0, 0, 50))
        grad.setColorAt(1.0, QColor(0, 0, 0, 220))
        painter.fillRect(self.rect(), grad)

    def mousePressEvent(self, e):
        if self._opt_btn.geometry().contains(e.pos()):
            return
        self.clicked.emit(self._tid)


class TravelersSelector(QWidget):
    valueChanged = Signal(int)

    def __init__(self, val: int = 2, parent=None):
        super().__init__(parent)
        self._val = val
        self.setFixedSize(140, 36)

        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(10)

        # Minus button
        self._minus = QPushButton("−")
        self._minus.setFixedSize(32, 32)
        self._minus.setCursor(Qt.PointingHandCursor)
        self._minus.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.05);
                color: #FFFFFF;
                border: 1px solid rgba(255, 255, 255, 0.12);
                border-radius: 16px;
                font-size: 14px;
                font-weight: 800;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.12);
            }
        """)
        self._minus.clicked.connect(self._dec)
        lay.addWidget(self._minus)

        # Value label
        self._lbl = QLabel(f"{self._val}")
        self._lbl.setAlignment(Qt.AlignCenter)
        self._lbl.setStyleSheet("color: #FFFFFF; font-size: 13px; font-weight: 700; background: transparent;")
        lay.addWidget(self._lbl, 1)

        # Plus button
        self._plus = QPushButton("+")
        self._plus.setFixedSize(32, 32)
        self._plus.setCursor(Qt.PointingHandCursor)
        self._plus.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.05);
                color: #FFFFFF;
                border: 1px solid rgba(255, 255, 255, 0.12);
                border-radius: 16px;
                font-size: 14px;
                font-weight: 800;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.12);
            }
        """)
        self._plus.clicked.connect(self._inc)
        lay.addWidget(self._plus)

    def value(self) -> int:
        return self._val

    def set_value(self, val: int):
        self._val = max(1, val)
        self._lbl.setText(f"{self._val}")
        self.valueChanged.emit(self._val)

    def _dec(self):
        self.set_value(self._val - 1)

    def _inc(self):
        self.set_value(self._val + 1)


class InlineTripForm(QFrame):
    """Inline expanding form for planning a new trip with smooth height animation."""

    trip_created = Signal(dict)
    cancelled = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._geocode_thread: QThread | None = None
        self.setMaximumHeight(0)
        self.setStyleSheet(f"""
            InlineTripForm {{
                background: rgba(20, 20, 26, 0.95);
                border-radius: 24px;
                border: 1px solid rgba(212, 169, 106, 0.25);
            }}
        """)
        self._build_ui()

    def _build_ui(self) -> None:
        from datetime import date
        from app.ui.widgets.search_bar import LocationSearchWidget

        layout = QVBoxLayout(self)
        layout.setContentsMargins(32, 28, 32, 28)
        layout.setSpacing(20)

        # Title
        hdr = QLabel("PLAN YOUR NEXT JOURNEY")
        hdr.setStyleSheet("color: #D4A96A; font-size: 14px; font-weight: 900; letter-spacing: 1.5px; background: transparent;")
        layout.addWidget(hdr)

        # Main horizontal split
        split_lay = QHBoxLayout()
        split_lay.setSpacing(32)

        # Left Column: Basic Info
        left_col = QVBoxLayout()
        left_col.setSpacing(14)

        # Trip Name field
        left_col.addWidget(self._field_label("Trip Name *"))
        self._name = QLineEdit()
        self._name.setPlaceholderText("Goa Adventure 2026")
        self._name.setStyleSheet("""
            QLineEdit {
                background: rgba(255, 255, 255, 0.05);
                border: 1px solid rgba(255, 255, 255, 0.10);
                border-radius: 10px;
                color: #FFFFFF;
                font-size: 13px;
                padding: 10px 14px;
            }
            QLineEdit:focus {
                border-color: rgba(212, 169, 106, 0.50);
            }
        """)
        left_col.addWidget(self._name)

        # From field
        left_col.addWidget(self._field_label("From (Location) *"))
        self._origin_search = LocationSearchWidget("Start location (e.g. Mumbai)")
        left_col.addWidget(self._origin_search)

        # Destination field
        left_col.addWidget(self._field_label("Destination *"))
        self._dest_search = LocationSearchWidget("Where are you going? (e.g. Goa)")
        left_col.addWidget(self._dest_search)

        # Cover Image field
        left_col.addWidget(self._field_label("Cover Image"))
        img_row = QHBoxLayout()
        self._image_path = QLineEdit()
        self._image_path.setPlaceholderText("No custom image selected")
        self._image_path.setReadOnly(True)
        self._image_path.setStyleSheet("""
            QLineEdit {
                background: rgba(255, 255, 255, 0.03);
                border: 1px solid rgba(255, 255, 255, 0.08);
                border-radius: 10px;
                color: #A1A1AA;
                padding: 10px 14px;
                font-size: 12px;
            }
        """)
        img_row.addWidget(self._image_path, 1)

        browse_btn = QPushButton("Browse...")
        browse_btn.setCursor(Qt.PointingHandCursor)
        browse_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.08);
                color: #D4A96A;
                border: 1px solid rgba(255, 255, 255, 0.12);
                border-radius: 10px;
                padding: 10px 16px;
                font-weight: 700;
                font-size: 11px;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.14);
            }
        """)
        browse_btn.clicked.connect(self._browse_image)
        img_row.addWidget(browse_btn)
        left_col.addLayout(img_row)

        split_lay.addLayout(left_col, 1)

        # Right Column: Dates, Budget, Notes
        right_col = QVBoxLayout()
        right_col.setSpacing(14)

        # Dates row
        dates_lay = QHBoxLayout()
        dates_lay.setSpacing(14)

        start_v = QVBoxLayout()
        start_v.setSpacing(4)
        start_v.addWidget(self._field_label("Start Date"))
        self._start = QDateEdit()
        self._start.setDate(date.today())
        self._start.setCalendarPopup(True)
        self._start.setStyleSheet(self._date_style())
        start_v.addWidget(self._start)
        dates_lay.addLayout(start_v, 1)

        end_v = QVBoxLayout()
        end_v.setSpacing(4)
        end_v.addWidget(self._field_label("End Date"))
        self._end = QDateEdit()
        self._end.setDate(date.today())
        self._end.setCalendarPopup(True)
        self._end.setStyleSheet(self._date_style())
        end_v.addWidget(self._end)
        dates_lay.addLayout(end_v, 1)

        right_col.addLayout(dates_lay)

        # Travelers & Budget row
        tb_lay = QHBoxLayout()
        tb_lay.setSpacing(14)

        trav_v = QVBoxLayout()
        trav_v.setSpacing(4)
        trav_v.addWidget(self._field_label("Travelers"))
        self._travelers = TravelersSelector(2)
        trav_v.addWidget(self._travelers)
        tb_lay.addLayout(trav_v, 1)

        bud_v = QVBoxLayout()
        bud_v.setSpacing(4)
        bud_v.addWidget(self._field_label("Budget"))
        self._budget = QDoubleSpinBox()
        self._budget.setMinimum(0)
        self._budget.setMaximum(10_000_000)
        self._budget.setValue(30000)
        self._budget.setPrefix("₹ ")
        self._budget.setFixedHeight(36)
        self._budget.setStyleSheet("""
            QDoubleSpinBox {
                background: rgba(255, 255, 255, 0.05);
                border: 1px solid rgba(255, 255, 255, 0.10);
                border-radius: 10px;
                color: #FFFFFF;
                font-size: 13px;
                font-weight: 700;
                padding-left: 10px;
            }
        """)
        bud_v.addWidget(self._budget)
        tb_lay.addLayout(bud_v, 1)

        right_col.addLayout(tb_lay)

        # Notes multiline field
        right_col.addWidget(self._field_label("Notes"))
        self._notes = QLineEdit()
        self._notes.setPlaceholderText("Anything about this trip...")
        self._notes.setStyleSheet("""
            QLineEdit {
                background: rgba(255, 255, 255, 0.05);
                border: 1px solid rgba(255, 255, 255, 0.10);
                border-radius: 10px;
                color: #FFFFFF;
                font-size: 13px;
                padding: 10px 14px;
            }
        """)
        right_col.addWidget(self._notes)

        split_lay.addLayout(right_col, 1)
        layout.addLayout(split_lay)

        # Error display area
        self._error_lbl = QLabel("")
        self._error_lbl.setStyleSheet("color: #F87171; font-size: 11px; font-weight: 700; background: transparent;")
        self._error_lbl.hide()
        layout.addWidget(self._error_lbl)

        # Buttons row
        btn_row = QHBoxLayout()
        btn_row.addStretch()

        cancel_btn = QPushButton("Cancel")
        cancel_btn.setCursor(Qt.PointingHandCursor)
        cancel_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.06);
                color: #A1A1AA;
                border: none;
                border-radius: 12px;
                padding: 10px 24px;
                font-size: 13px;
                font-weight: 600;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.12);
            }
        """)
        cancel_btn.clicked.connect(self.cancelled.emit)
        btn_row.addWidget(cancel_btn)

        self._save_btn = QPushButton("Create Trip ✈")
        self._save_btn.setCursor(Qt.PointingHandCursor)
        self._save_btn.setStyleSheet("""
            QPushButton {
                background: #D4A96A;
                color: #111111;
                border: none;
                border-radius: 12px;
                padding: 10px 28px;
                font-size: 13px;
                font-weight: 800;
            }
            QPushButton:hover {
                background: #FDBA74;
            }
        """)
        self._save_btn.clicked.connect(self._submit)
        btn_row.addWidget(self._save_btn)

        layout.addLayout(btn_row)

    def _field_label(self, text: str) -> QLabel:
        lbl = QLabel(text)
        lbl.setStyleSheet("color: rgba(255, 255, 255, 0.65); font-size: 11px; font-weight: 700; letter-spacing: 0.5px; background: transparent;")
        return lbl

    def _date_style(self) -> str:
        return """
            QDateEdit {
                background: rgba(255, 255, 255, 0.05);
                border: 1px solid rgba(255, 255, 255, 0.10);
                border-radius: 10px;
                color: #FFFFFF;
                font-size: 13px;
                font-weight: 600;
                padding: 8px 10px;
            }
        """

    def _browse_image(self):
        from PySide6.QtWidgets import QFileDialog
        path, _ = QFileDialog.getOpenFileName(self, "Select Cover Image", "", "Images (*.png *.jpg *.jpeg)")
        if path:
            self._image_path.setText(path)

    def _submit(self):
        # Validate fields inline
        name = self._name.text().strip()
        from_loc = self._origin_search.text().strip()
        to_loc = self._dest_search.text().strip()
        start = self._start.date()
        end = self._end.date()
        travelers = self._travelers.value()
        budget = self._budget.value()

        if not name:
            self._show_error("⚠ Trip name cannot be empty")
            return
        if not from_loc:
            self._show_error("⚠ From location cannot be empty")
            return
        if not to_loc:
            self._show_error("⚠ Destination cannot be empty")
            return
        if end < start:
            self._show_error("⚠ End date must be after start date")
            return
        if travelers < 1:
            self._show_error("⚠ Travelers must be at least 1")
            return
        if budget < 0:
            self._show_error("⚠ Budget cannot be negative")
            return

        self._error_lbl.hide()
        data = {
            "name":        name,
            "origin":      from_loc,
            "destination": to_loc,
            "start_date":  start.toString("yyyy-MM-dd"),
            "end_date":    end.toString("yyyy-MM-dd"),
            "travelers":   travelers,
            "budget":      budget,
            "currency":    "INR",
            "currency_sym":"₹",
            "notes":       self._notes.text().strip(),
            "cover_image": self._image_path.text().strip() or "goa_beach_sunset.jpg",
            "origin_lat":  None,
            "origin_lon":  None,
            "dest_lat":    None,
            "dest_lon":    None,
        }

        # Check if locations were already resolved in the search widgets
        origin_loc = self._origin_search.get_selected_location()
        dest_loc   = self._dest_search.get_selected_location()

        if origin_loc:
            data["origin_lat"] = float(origin_loc.get("latitude") or origin_loc.get("lat") or 0.0)
            data["origin_lon"] = float(origin_loc.get("longitude") or origin_loc.get("lon") or 0.0)
        if dest_loc:
            data["dest_lat"]   = float(dest_loc.get("latitude") or dest_loc.get("lat") or 0.0)
            data["dest_lon"]   = float(dest_loc.get("longitude") or dest_loc.get("lon") or 0.0)

        # If both coordinates are already known, save immediately
        if data["origin_lat"] and data["dest_lat"]:
            self._finish_trip(data, origin_loc, dest_loc)
            return

        # Otherwise, geocode in a background thread
        self._save_btn.setEnabled(False)
        self._save_btn.setText("Creating Trip…")
        logger.info("[action started] Create trip geocoding: %s", name)

        worker = TripGeocodeWorker(from_loc, to_loc)
        thread = QThread(self)
        thread._worker = worker
        self._geocode_worker = worker
        self._geocode_thread = thread

        # Relay guarantees delivery directly on the main UI thread
        relay = _TripRelay(lambda o, d: self._finish_trip(data, o, d), parent=self)
        thread._relay = relay

        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.finished.connect(relay.receive)
        worker.finished.connect(thread.quit)
        worker.finished.connect(worker.deleteLater)
        thread.finished.connect(relay.deleteLater)
        thread.finished.connect(thread.deleteLater)
        thread.finished.connect(lambda: setattr(self, "_geocode_thread", None))
        thread.finished.connect(lambda: setattr(self, "_geocode_worker", None))
        thread.start()

    def _finish_trip(self, data: dict, origin: dict | None, destination: dict | None) -> None:
        """Called on main UI thread with geocoded results."""
        if origin:
            data["origin_lat"] = float(origin.get("latitude") or origin.get("lat") or 0.0)
            data["origin_lon"] = float(origin.get("longitude") or origin.get("lon") or 0.0)
        if destination:
            data["dest_lat"]   = float(destination.get("latitude") or destination.get("lat") or 0.0)
            data["dest_lon"]   = float(destination.get("longitude") or destination.get("lon") or 0.0)
        logger.info("[action completed] Create trip resolved: %s", data["name"])
        self._reset_form()
        self.trip_created.emit(data)

    def _reset_form(self):
        """Reset form fields and re-enable save button."""
        self._save_btn.setEnabled(True)
        self._save_btn.setText("Create Trip ✈")
        self._name.clear()
        self._origin_search.clear()
        self._dest_search.clear()
        self._notes.clear()
        self._image_path.clear()
        self._start.setDate(date.today())
        self._end.setDate(date.today())
        self._budget.setValue(30000)
        self._travelers.set_value(2)
        self._error_lbl.hide()

    def _show_error(self, msg: str):
        self._error_lbl.setText(msg)
        self._error_lbl.show()

    def cleanup(self) -> None:
        if self._geocode_thread and self._geocode_thread.isRunning():
            self._geocode_thread.quit()
            self._geocode_thread.wait(300)
        if hasattr(self, "_origin_search") and hasattr(self._origin_search, "cleanup"):
            self._origin_search.cleanup()
        if hasattr(self, "_dest_search") and hasattr(self._dest_search, "cleanup"):
            self._dest_search.cleanup()


class TripsScreen(QWidget):
    """My Journeys screen with smooth inline expandable form."""

    trip_selected = Signal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._current_filter = "All"
        self._form_expanded = False
        self._build_ui()
        self.refresh()

    def _build_ui(self) -> None:
        from PySide6.QtCore import QPropertyAnimation, QEasingCurve
        layout = QVBoxLayout(self)
        layout.setContentsMargins(36, 36, 36, 36)
        layout.setSpacing(20)

        # Header
        hdr = QHBoxLayout()
        title_v = QVBoxLayout()
        title_v.setSpacing(4)
        title = QLabel("My Journeys")
        title.setStyleSheet(f"color: {COLORS['text']}; font-size: {FONT['3xl']}; font-weight: 900; letter-spacing: -1px; background: transparent; border:none;")
        title_v.addWidget(title)

        sub = QLabel("Track, manage, and relive all your travel experiences")
        sub.setStyleSheet(f"color: {COLORS['text_muted']}; font-size: {FONT['base']}; background: transparent; border:none;")
        title_v.addWidget(sub)
        hdr.addLayout(title_v)
        hdr.addStretch()

        self._new_btn = QPushButton("+  Plan New Journey")
        self._new_btn.setFixedHeight(44)
        self._new_btn.setStyleSheet(f"""
            QPushButton {{
                background: {COLORS['sand']};
                color: #111111;
                border: none;
                border-radius: 22px;
                padding: 0 28px;
                font-size: 14px;
                font-weight: 700;
            }}
            QPushButton:hover {{
                background: {COLORS['accent_light']};
            }}
        """)
        self._new_btn.clicked.connect(self._toggle_form)
        hdr.addWidget(self._new_btn)
        layout.addLayout(hdr)

        # Inline Expandable Form Container
        self._inline_form = InlineTripForm()
        self._inline_form.trip_created.connect(self._on_trip_created)
        self._inline_form.cancelled.connect(lambda: self._animate_form(False))
        layout.addWidget(self._inline_form)

        # Filter pills
        filter_row = QHBoxLayout()
        filter_row.setSpacing(12)
        self._filter_btns = []
        for status in ["All", "Upcoming", "Ongoing"]:
            btn = QPushButton(status)
            btn.setCheckable(True)
            btn.setChecked(status == "All")
            btn.setFixedHeight(36)
            btn.setStyleSheet(f"""
                QPushButton {{
                    background: transparent;
                    color: rgba(255,255,255,0.60);
                    border: 1px solid rgba(255,255,255,0.15);
                    border-radius: 18px;
                    padding: 0 22px;
                    font-size: 13px;
                    font-weight: 600;
                }}
                QPushButton:checked {{
                    background: {COLORS['sand']};
                    color: #111111;
                    border: none;
                    font-weight: 700;
                }}
                QPushButton:hover:!checked {{
                    background: rgba(255,255,255,0.06);
                    color: #FFFFFF;
                }}
            """)
            btn.clicked.connect(lambda _, s=status: self._filter(s))
            self._filter_btns.append(btn)
            filter_row.addWidget(btn)
        filter_row.addStretch()
        layout.addLayout(filter_row)

        # Trip list scroll (horizontal)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setStyleSheet("background: transparent;")
        self._list_widget = QWidget()
        self._list_widget.setStyleSheet("background: transparent;")
        self._list_layout = QHBoxLayout(self._list_widget)
        self._list_layout.setContentsMargins(0, 12, 0, 12)
        self._list_layout.setSpacing(24)
        self._list_layout.setAlignment(Qt.AlignLeft)
        scroll.setWidget(self._list_widget)
        layout.addWidget(scroll, 1)

    def _toggle_form(self):
        self._animate_form(not self._form_expanded)

    def _animate_form(self, expand: bool):
        from PySide6.QtCore import QPropertyAnimation, QEasingCurve
        self._form_expanded = expand
        anim = QPropertyAnimation(self._inline_form, b"maximumHeight", self)
        anim.setDuration(350)
        anim.setEasingCurve(QEasingCurve.OutCubic if expand else QEasingCurve.InCubic)
        anim.setStartValue(self._inline_form.maximumHeight())
        anim.setEndValue(520 if expand else 0)
        anim.start()

    def _on_trip_created(self, data: dict):
        try:
            logger.info("Inserting trip into database: %s", data.get("name"))
            trip_id = trip_service.create_trip(data)
            logger.info("Trip created successfully with ID: %s", trip_id)
            self._animate_form(False)
            self.refresh()
        except Exception as e:
            logger.error("Create trip failed: %s", e, exc_info=True)
            self._inline_form._show_error(f"Failed to create trip: {e}")
            self._inline_form._save_btn.setEnabled(True)
            self._inline_form._save_btn.setText("Create Trip ✈")


    def refresh(self) -> None:
        while self._list_layout.count():
            item = self._list_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        trips = trip_service.get_all_trips()

        # Apply status filter
        if self._current_filter == "Upcoming":
            trips = [t for t in trips if t.get("status") == "planned"]
        elif self._current_filter == "Ongoing":
            trips = [t for t in trips if t.get("status") == "ongoing"]
        elif self._current_filter == "Memories":
            trips = [t for t in trips if t.get("status") == "completed"]

        if not trips:
            empty = EmptyStateWidget(
                icon="✈", title="No journeys found",
                subtitle="Start planning your next adventure!",
                button_text="Plan a Trip"
            )
            if empty.cta_button:
                empty.cta_button.clicked.connect(self._new_trip)
            self._list_layout.addWidget(empty)
            return

        for t in trips:
            card = JourneyCard(t)
            card.clicked.connect(self.trip_selected)
            self._list_layout.addWidget(card)

        self._list_layout.addStretch()

    def _filter(self, status: str) -> None:
        self._current_filter = status
        for btn in self._filter_btns:
            btn.setChecked(btn.text() == status)
        self.refresh()

    def _new_trip(self) -> None:
        self._toggle_form()

    def cleanup(self) -> None:
        if hasattr(self, "_inline_form") and hasattr(self._inline_form, "cleanup"):
            self._inline_form.cleanup()
