"""
Surprise Me / Discover Screen — Animated travel discovery experience.
"""
from __future__ import annotations
import logging
import random

from PySide6.QtCore    import Qt, QPropertyAnimation, QEasingCurve, QRect, Signal
from PySide6.QtGui     import QColor
from PySide6.QtWidgets import (
    QCheckBox, QFrame, QGridLayout, QHBoxLayout, QLabel,
    QPushButton, QScrollArea, QSizePolicy, QVBoxLayout, QWidget
)
from app.config import COLORS, FONT, DEFAULT_CURRENCY
from app.services.recommendation_service import recommendation_service
from app.database.repositories import destination_repo, favorites_repo

logger = logging.getLogger(__name__)

_CATEGORIES = ["Beach", "City", "Heritage", "Mountains", "Nature", "Spiritual"]


class RandomDestinationScreen(QWidget):
    """Surprise Me screen with filter preferences and animated destination reveal."""

    add_to_trip = Signal(dict)
    explore     = Signal(dict)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._current_dest: dict | None = None
        self._build_ui()
        self.refresh()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(40, 40, 40, 40)
        layout.setSpacing(24)

        # ── Header ────────────────────────────────────────────────────────────
        hdr_v = QVBoxLayout()
        hdr_v.setSpacing(6)
        title = QLabel("✦  Discover Something New")
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet(f"color:{COLORS['text']};font-size:{FONT['3xl']};font-weight:900;letter-spacing:-1px;background:transparent;border:none;")
        hdr_v.addWidget(title)

        sub = QLabel("Unsure where to head next? Let fate pick your next travel escape.")
        sub.setAlignment(Qt.AlignCenter)
        sub.setStyleSheet(f"color:{COLORS['text_muted']};font-size:{FONT['md']};background:transparent;border:none;")
        hdr_v.addWidget(sub)
        layout.addLayout(hdr_v)

        # ── Filter Preferences ────────────────────────────────────────────────
        filter_frame = QFrame()
        filter_frame.setObjectName("filter_frame")
        filter_frame.setStyleSheet(f"""
            QFrame#filter_frame {{
                background: {COLORS['bg_card']};
                border: none;
                border-radius: 20px;
            }}
        """)
        filter_layout = QVBoxLayout(filter_frame)
        filter_layout.setContentsMargins(24, 18, 24, 18)
        filter_layout.setSpacing(12)

        filter_title = QLabel("FILTER PREFERENCES")
        filter_title.setStyleSheet(f"color:{COLORS['text_subtle']};font-size:10px;font-weight:800;letter-spacing:1.5px;background:transparent;border:none;")
        filter_layout.addWidget(filter_title)

        cat_row = QHBoxLayout()
        cat_row.setSpacing(16)
        self._cat_checks: dict[str, QCheckBox] = {}
        for cat in _CATEGORIES:
            cb = QCheckBox(cat)
            cb.setStyleSheet(f"""
                QCheckBox {{ color:{COLORS['text_muted']}; font-size:{FONT['base']}; font-weight: 500; border:none; }}
                QCheckBox:checked {{ color:{COLORS['accent']}; font-weight: 700; }}
                QCheckBox::indicator {{ width:18px; height:18px; border-radius:6px; border:none; background:rgba(255,255,255,0.08); }}
                QCheckBox::indicator:checked {{ background:{COLORS['accent']}; }}
            """)
            self._cat_checks[cat] = cb
            cat_row.addWidget(cb)
        cat_row.addStretch()
        filter_layout.addLayout(cat_row)
        layout.addWidget(filter_frame)

        # ── Roll Button ───────────────────────────────────────────────────────
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        self._surprise_btn = QPushButton("🎲   Surprise Me")
        self._surprise_btn.setMinimumHeight(48)
        self._surprise_btn.setMinimumWidth(220)
        self._surprise_btn.setStyleSheet(f"""
            QPushButton {{
                background: {COLORS['accent']};
                color: #111111;
                border: none;
                border-radius: 16px;
                font-size: {FONT['md']};
                font-weight: 800;
                padding: 0 32px;
            }}
            QPushButton:hover {{
                background: {COLORS['accent_light']};
            }}
        """)
        self._surprise_btn.clicked.connect(self._roll)
        btn_row.addWidget(self._surprise_btn)
        btn_row.addStretch()
        layout.addLayout(btn_row)

        # ── Destination reveal card ───────────────────────────────────────────
        self._card_container = QWidget()
        card_layout = QVBoxLayout(self._card_container)
        card_layout.setContentsMargins(0, 0, 0, 0)

        self._dest_card = QFrame()
        self._dest_card.setObjectName("dest_card")
        self._dest_card.setStyleSheet(f"""
            QFrame#dest_card {{
                background: {COLORS['bg_card']};
                border: none;
                border-radius: 24px;
            }}
        """)
        dc_layout = QVBoxLayout(self._dest_card)
        dc_layout.setContentsMargins(32, 28, 32, 28)
        dc_layout.setSpacing(16)

        # Header title
        name_row = QHBoxLayout()
        name_col = QVBoxLayout()
        name_col.setSpacing(4)
        self._dest_name = QLabel("Destination")
        self._dest_name.setStyleSheet(f"color:{COLORS['text']};font-size:36px;font-weight:900;letter-spacing:-1px;background:transparent;border:none;")
        name_col.addWidget(self._dest_name)
        self._dest_country = QLabel("Country")
        self._dest_country.setStyleSheet(f"color:{COLORS['accent']};font-size:{FONT['lg']};font-weight:600;background:transparent;border:none;")
        name_col.addWidget(self._dest_country)
        name_row.addLayout(name_col, 1)
        dc_layout.addLayout(name_row)

        # Description
        self._dest_desc = QLabel("")
        self._dest_desc.setWordWrap(True)
        self._dest_desc.setStyleSheet(f"color:{COLORS['text_muted']};font-size:{FONT['base']};line-height:1.6;background:transparent;border:none;")
        dc_layout.addWidget(self._dest_desc)

        # Info grid
        info_grid = QGridLayout()
        info_grid.setSpacing(14)
        self._season_lbl   = self._info_box("Best Season",  "—", info_grid, 0, 0)
        self._budget_lbl   = self._info_box("Budget / Day", "—", info_grid, 0, 1)
        self._category_lbl = self._info_box("Category",     "—", info_grid, 0, 2)
        dc_layout.addLayout(info_grid)

        # Action buttons
        action_row = QHBoxLayout()
        action_row.setSpacing(14)

        explore_btn = QPushButton("Explore Location →")
        explore_btn.setFixedHeight(40)
        explore_btn.setStyleSheet(f"QPushButton{{background:{COLORS['accent']};color:#111;border:none;border-radius:12px;padding:0 24px;font-size:{FONT['base']};font-weight:700;}}QPushButton:hover{{background:{COLORS['accent_light']};}}")
        explore_btn.clicked.connect(self._on_explore)
        action_row.addWidget(explore_btn)

        fav_btn = QPushButton("♡ Save to Favorites")
        fav_btn.setFixedHeight(40)
        fav_btn.setStyleSheet(f"QPushButton{{background:rgba(255,255,255,0.07);color:{COLORS['coral']};border:none;border-radius:12px;padding:0 24px;font-size:{FONT['base']};font-weight:700;}}QPushButton:hover{{background:rgba(255,255,255,0.14);}}")
        fav_btn.clicked.connect(self._save_fav)
        action_row.addWidget(fav_btn)

        trip_btn = QPushButton("+ Plan This Trip")
        trip_btn.setFixedHeight(40)
        trip_btn.setStyleSheet(f"QPushButton{{background:rgba(255,255,255,0.07);color:{COLORS['sand']};border:none;border-radius:12px;padding:0 24px;font-size:{FONT['base']};font-weight:700;}}QPushButton:hover{{background:rgba(255,255,255,0.14);}}")
        trip_btn.clicked.connect(lambda: self.add_to_trip.emit(self._current_dest or {}))
        action_row.addWidget(trip_btn)
        action_row.addStretch()
        dc_layout.addLayout(action_row)

        card_layout.addWidget(self._dest_card)
        layout.addWidget(self._card_container)
        layout.addStretch(1)

    @staticmethod
    def _info_box(label, value, grid, row, col) -> QLabel:
        box = QFrame()
        box.setStyleSheet(f"background:rgba(255,255,255,0.04);border:none;border-radius:14px;")
        bl = QVBoxLayout(box)
        bl.setContentsMargins(16, 14, 16, 14)
        bl.setSpacing(4)
        lbl_top = QLabel(label.upper())
        lbl_top.setStyleSheet(f"color:{COLORS['text_subtle']};font-size:10px;font-weight:800;letter-spacing:1px;background:transparent;border:none;")
        bl.addWidget(lbl_top)
        val_lbl = QLabel(value)
        val_lbl.setStyleSheet(f"color:{COLORS['text']};font-size:{FONT['base']};font-weight:700;background:transparent;border:none;")
        bl.addWidget(val_lbl)
        grid.addWidget(box, row, col)
        return val_lbl

    def refresh(self) -> None:
        if not self._current_dest:
            self._roll()

    def _roll(self) -> None:
        filters = {}
        checked = [k for k, cb in self._cat_checks.items() if cb.isChecked()]
        if checked:
            filters["category"] = random.choice(checked)

        dest = recommendation_service.get_random_destination(filters)
        if not dest:
            dest = recommendation_service.get_random_destination(None)
        if not dest:
            return

        self._current_dest = dest
        self._populate_card(dest)
        self._card_container.setVisible(True)

    def _populate_card(self, dest: dict) -> None:
        self._dest_name.setText(dest.get("name", "Unknown Destination"))
        self._dest_country.setText(f"{dest.get('country','')}   •   {dest.get('continent','')}")
        self._dest_desc.setText(dest.get("description", ""))

        self._season_lbl.setText(dest.get("best_season", "—"))
        budget = dest.get("budget_inr", 0)
        sym = DEFAULT_CURRENCY
        self._budget_lbl.setText(f"{sym}{budget:,.0f}/day" if budget else "Varies")
        self._category_lbl.setText(dest.get("category", "—"))

    def _on_explore(self) -> None:
        if self._current_dest:
            self.explore.emit(self._current_dest)

    def _save_fav(self) -> None:
        if self._current_dest:
            favorites_repo.insert({
                "name":        self._current_dest.get("name", ""),
                "category":    self._current_dest.get("category", ""),
                "lat":         self._current_dest.get("lat"),
                "lon":         self._current_dest.get("lon"),
                "description": self._current_dest.get("description", ""),
                "source":      "random",
            })
