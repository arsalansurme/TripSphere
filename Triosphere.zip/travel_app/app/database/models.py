"""
Database schema creation and migration for TripSphere.
Call initialize_database() once at application startup.
"""
import logging
from app.database.db import db

logger = logging.getLogger(__name__)

# ── DDL Statements ────────────────────────────────────────────────────────────

_SCHEMA_SQL = """
-- Users / profile
CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT    NOT NULL DEFAULT 'Traveller',
    email         TEXT,
    home_city     TEXT    DEFAULT 'Mumbai',
    home_lat      REAL    DEFAULT 19.0760,
    home_lon      REAL    DEFAULT 72.8777,
    currency      TEXT    DEFAULT 'INR',
    currency_sym  TEXT    DEFAULT '₹',
    travel_mode   TEXT    DEFAULT 'driving',
    theme         TEXT    DEFAULT 'dark',
    created_at    TEXT    DEFAULT (datetime('now'))
);

-- Key/value store for small bits of app state (e.g. which profile is active)
CREATE TABLE IF NOT EXISTS app_state (
    key           TEXT    PRIMARY KEY,
    value         TEXT
);

-- Destination catalogue
CREATE TABLE IF NOT EXISTS destinations (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT    NOT NULL,
    country       TEXT    NOT NULL,
    continent     TEXT,
    lat           REAL    NOT NULL,
    lon           REAL    NOT NULL,
    category      TEXT,
    description   TEXT,
    best_season   TEXT,
    budget_inr    REAL    DEFAULT 0,
    tags          TEXT,           -- comma-separated
    image_path    TEXT,
    popularity    INTEGER DEFAULT 0,
    created_at    TEXT    DEFAULT (datetime('now'))
);

-- Places / POIs within a destination
CREATE TABLE IF NOT EXISTS places (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    destination_id INTEGER REFERENCES destinations(id) ON DELETE CASCADE,
    name           TEXT    NOT NULL,
    category       TEXT,
    lat            REAL,
    lon            REAL,
    address        TEXT,
    description    TEXT,
    rating         REAL    DEFAULT 0,
    popularity     INTEGER DEFAULT 0,
    tags           TEXT,
    created_at     TEXT    DEFAULT (datetime('now'))
);

-- Trips
CREATE TABLE IF NOT EXISTS trips (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id       INTEGER NOT NULL DEFAULT 1 REFERENCES users(id) ON DELETE CASCADE,
    name          TEXT    NOT NULL,
    origin        TEXT,
    origin_lat    REAL,
    origin_lon    REAL,
    destination   TEXT,
    dest_lat      REAL,
    dest_lon      REAL,
    start_date    TEXT,
    end_date      TEXT,
    travelers     INTEGER DEFAULT 1,
    budget        REAL    DEFAULT 0,
    currency      TEXT    DEFAULT 'INR',
    currency_sym  TEXT    DEFAULT '₹',
    notes         TEXT,
    cover_image   TEXT,
    status        TEXT    DEFAULT 'planned',   -- planned/ongoing/completed
    created_at    TEXT    DEFAULT (datetime('now')),
    updated_at    TEXT    DEFAULT (datetime('now'))
);

-- Trip stops (multi-destination)
CREATE TABLE IF NOT EXISTS trip_stops (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    trip_id      INTEGER NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
    stop_order   INTEGER NOT NULL DEFAULT 0,
    place_name   TEXT    NOT NULL,
    lat          REAL,
    lon          REAL,
    address      TEXT,
    nights       INTEGER DEFAULT 1,
    notes        TEXT
);

-- Day-by-day itinerary items
CREATE TABLE IF NOT EXISTS itinerary (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    trip_id        INTEGER NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
    date           TEXT,
    time           TEXT,
    place_name     TEXT,
    activity       TEXT    NOT NULL,
    notes          TEXT,
    estimated_cost REAL    DEFAULT 0,
    currency_sym   TEXT    DEFAULT '₹'
);

-- Expenses
CREATE TABLE IF NOT EXISTS expenses (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id        INTEGER NOT NULL DEFAULT 1 REFERENCES users(id) ON DELETE CASCADE,
    trip_id        INTEGER REFERENCES trips(id) ON DELETE CASCADE,
    category       TEXT    NOT NULL DEFAULT 'Other',
    amount         REAL    NOT NULL DEFAULT 0,
    currency       TEXT    DEFAULT 'INR',
    currency_sym   TEXT    DEFAULT '₹',
    date           TEXT    DEFAULT (date('now')),
    description    TEXT,
    payment_method TEXT    DEFAULT 'Cash',
    created_at     TEXT    DEFAULT (datetime('now'))
);

-- Journal entries
CREATE TABLE IF NOT EXISTS journal_entries (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id      INTEGER NOT NULL DEFAULT 1 REFERENCES users(id) ON DELETE CASCADE,
    trip_id      INTEGER REFERENCES trips(id) ON DELETE SET NULL,
    title        TEXT    NOT NULL,
    date         TEXT    DEFAULT (date('now')),
    location     TEXT,
    lat          REAL,
    lon          REAL,
    description  TEXT,
    mood         TEXT,
    image_path   TEXT,
    created_at   TEXT    DEFAULT (datetime('now')),
    updated_at   TEXT    DEFAULT (datetime('now'))
);

-- Favorites
CREATE TABLE IF NOT EXISTS favorites (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id      INTEGER NOT NULL DEFAULT 1 REFERENCES users(id) ON DELETE CASCADE,
    name         TEXT    NOT NULL,
    category     TEXT,
    lat          REAL,
    lon          REAL,
    address      TEXT,
    description  TEXT,
    notes        TEXT,
    source       TEXT    DEFAULT 'user',
    created_at   TEXT    DEFAULT (datetime('now'))
);

-- Search cache
CREATE TABLE IF NOT EXISTS search_cache (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    query        TEXT    NOT NULL UNIQUE,
    result_json  TEXT,
    created_at   TEXT    DEFAULT (datetime('now'))
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_places_destination ON places(destination_id);
CREATE INDEX IF NOT EXISTS idx_trip_stops_trip    ON trip_stops(trip_id);
CREATE INDEX IF NOT EXISTS idx_itinerary_trip     ON itinerary(trip_id);
CREATE INDEX IF NOT EXISTS idx_expenses_trip      ON expenses(trip_id);
CREATE INDEX IF NOT EXISTS idx_journal_trip       ON journal_entries(trip_id);
CREATE INDEX IF NOT EXISTS idx_destinations_name  ON destinations(name);
"""

# Indexes on user_id — created only after _migrate_add_user_id_columns()
# has guaranteed the column exists, since older databases won't have it yet.
_USER_ID_INDEX_SQL = """
CREATE INDEX IF NOT EXISTS idx_trips_user     ON trips(user_id);
CREATE INDEX IF NOT EXISTS idx_expenses_user  ON expenses(user_id);
CREATE INDEX IF NOT EXISTS idx_journal_user   ON journal_entries(user_id);
CREATE INDEX IF NOT EXISTS idx_favorites_user ON favorites(user_id);
"""

# Tables that gained a `user_id` column after their initial release.
# For a fresh database CREATE TABLE already includes the column, so
# each ALTER TABLE below is a no-op guarded by _table_has_column().
_USER_ID_MIGRATIONS = ["trips", "expenses", "journal_entries", "favorites"]


def _table_has_column(table: str, column: str) -> bool:
    rows = db.conn.execute(f"PRAGMA table_info({table})").fetchall()
    return any(r["name"] == column for r in rows)


def _migrate_add_user_id_columns() -> None:
    """Add the user_id column (defaulting existing rows to profile 1) to
    tables that predate multi-profile support, so upgrading an existing
    tripsphere.db doesn't lose or scramble anyone's data."""
    for table in _USER_ID_MIGRATIONS:
        try:
            if not _table_has_column(table, "user_id"):
                db.conn.execute(
                    f"ALTER TABLE {table} ADD COLUMN user_id INTEGER NOT NULL DEFAULT 1"
                )
                logger.info("Migrated table '%s': added user_id column.", table)
        except Exception as exc:
            logger.error("Failed to migrate user_id column on '%s': %s", table, exc)
    db.conn.commit()


def initialize_database() -> None:
    """Create all tables and indexes if they don't already exist."""
    try:
        statements = [s.strip() for s in _SCHEMA_SQL.split(";") if s.strip()]
        for stmt in statements:
            db.conn.execute(stmt)
        db.conn.commit()

        # Bring older databases (pre multi-profile) up to date before
        # touching anything that depends on the user_id column existing.
        _migrate_add_user_id_columns()

        for stmt in [s.strip() for s in _USER_ID_INDEX_SQL.split(";") if s.strip()]:
            db.conn.execute(stmt)
        db.conn.commit()

        logger.info("Database schema initialized successfully.")
    except Exception as exc:
        logger.critical("Failed to initialize database: %s", exc)
        raise
