"""
Thread-safe SQLite database manager for TripSphere.
Uses a per-thread connection to avoid sharing connections across threads.
"""
import sqlite3
import threading
import logging
from pathlib import Path
from typing import Any, Optional

from app.config import DB_PATH

logger = logging.getLogger(__name__)


class DatabaseManager:
    """Singleton database manager providing thread-local SQLite connections."""

    _instance: Optional["DatabaseManager"] = None
    _lock = threading.Lock()

    def __new__(cls) -> "DatabaseManager":
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._local = threading.local()
                    cls._instance._db_path = DB_PATH
        return cls._instance

    # ── Connection management ────────────────────────────────────────────────

    @property
    def conn(self) -> sqlite3.Connection:
        """Return a thread-local connection, creating it if needed."""
        if not hasattr(self._local, "connection") or self._local.connection is None:
            self._local.connection = self._create_connection()
        return self._local.connection

    def _create_connection(self) -> sqlite3.Connection:
        """Create a new SQLite connection with optimal settings."""
        conn = sqlite3.connect(
            str(self._db_path),
            check_same_thread=False,
            timeout=30,
        )
        conn.row_factory = sqlite3.Row          # dict-like rows
        conn.execute("PRAGMA journal_mode=WAL") # better concurrency
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA cache_size=-8000") # 8 MB page cache
        return conn

    def close(self) -> None:
        """Close the thread-local connection."""
        if hasattr(self._local, "connection") and self._local.connection:
            self._local.connection.close()
            self._local.connection = None

    # ── Query helpers ────────────────────────────────────────────────────────

    def execute(self, sql: str, params: tuple = ()) -> sqlite3.Cursor:
        """Execute a single statement and return the cursor."""
        try:
            cursor = self.conn.execute(sql, params)
            self.conn.commit()
            return cursor
        except sqlite3.Error as exc:
            logger.error("DB execute error: %s | SQL: %s | params: %s", exc, sql, params)
            self.conn.rollback()
            raise

    def executemany(self, sql: str, param_list: list[tuple]) -> None:
        """Execute a statement for each parameter tuple."""
        try:
            self.conn.executemany(sql, param_list)
            self.conn.commit()
        except sqlite3.Error as exc:
            logger.error("DB executemany error: %s", exc)
            self.conn.rollback()
            raise

    def fetchone(self, sql: str, params: tuple = ()) -> Optional[sqlite3.Row]:
        """Execute and return a single row."""
        try:
            return self.conn.execute(sql, params).fetchone()
        except sqlite3.Error as exc:
            logger.error("DB fetchone error: %s | SQL: %s", exc, sql)
            return None

    def fetchall(self, sql: str, params: tuple = ()) -> list[sqlite3.Row]:
        """Execute and return all rows."""
        try:
            return self.conn.execute(sql, params).fetchall()
        except sqlite3.Error as exc:
            logger.error("DB fetchall error: %s | SQL: %s", exc, sql)
            return []

    def fetchall_dict(self, sql: str, params: tuple = ()) -> list[dict[str, Any]]:
        """Execute and return all rows as plain dicts."""
        rows = self.fetchall(sql, params)
        return [dict(r) for r in rows]

    def last_insert_id(self) -> int:
        """Return the rowid of the last INSERT."""
        return self.conn.execute("SELECT last_insert_rowid()").fetchone()[0]


# Module-level singleton
db = DatabaseManager()
