"""
Data Access Layer — repository classes for each domain entity.
All database access goes through these classes, never directly from UI code.
"""
from __future__ import annotations

import json
import logging
from typing import Any, Optional
from datetime import date

from app.database.db import db
from app.session import get_current_user_id

logger = logging.getLogger(__name__)


# ── Destinations ──────────────────────────────────────────────────────────────

class DestinationRepository:
    """CRUD for the destinations table."""

    def get_all(self) -> list[dict]:
        return db.fetchall_dict("SELECT * FROM destinations ORDER BY popularity DESC, name")

    def get_by_id(self, dest_id: int) -> Optional[dict]:
        row = db.fetchone("SELECT * FROM destinations WHERE id = ?", (dest_id,))
        return dict(row) if row else None

    def search(self, query: str) -> list[dict]:
        q = f"%{query}%"
        return db.fetchall_dict(
            "SELECT * FROM destinations WHERE name LIKE ? OR country LIKE ? OR tags LIKE ? ORDER BY popularity DESC LIMIT 20",
            (q, q, q),
        )

    def get_random(self, filters: dict | None = None) -> Optional[dict]:
        sql = "SELECT * FROM destinations"
        params: list = []
        if filters:
            clauses = []
            if filters.get("continent"):
                clauses.append("continent = ?")
                params.append(filters["continent"])
            if filters.get("category"):
                clauses.append("category = ?")
                params.append(filters["category"])
            if filters.get("tag"):
                clauses.append("tags LIKE ?")
                params.append(f"%{filters['tag']}%")
            if clauses:
                sql += " WHERE " + " AND ".join(clauses)
        sql += " ORDER BY RANDOM() LIMIT 1"
        row = db.fetchone(sql, tuple(params))
        return dict(row) if row else None

    def upsert(self, data: dict) -> int:
        existing = db.fetchone("SELECT id FROM destinations WHERE name = ? AND country = ?",
                               (data["name"], data["country"]))
        if existing:
            return existing["id"]
        db.execute(
            """INSERT INTO destinations
               (name, country, continent, lat, lon, category, description, best_season, budget_inr, tags, popularity)
               VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (data.get("name"), data.get("country"), data.get("continent"),
             data.get("lat"), data.get("lon"), data.get("category"),
             data.get("description"), data.get("best_season"),
             data.get("budget_inr", 0), ",".join(data.get("tags", [])),
             data.get("popularity", 0)),
        )
        return db.last_insert_id()

    def get_by_category(self, category: str) -> list[dict]:
        return db.fetchall_dict(
            "SELECT * FROM destinations WHERE category = ? ORDER BY popularity DESC", (category,)
        )

    def increment_popularity(self, dest_id: int) -> None:
        db.execute("UPDATE destinations SET popularity = popularity + 1 WHERE id = ?", (dest_id,))


# ── Places ────────────────────────────────────────────────────────────────────

class PlaceRepository:
    """CRUD for the places table."""

    def get_by_destination(self, dest_id: int) -> list[dict]:
        return db.fetchall_dict(
            "SELECT * FROM places WHERE destination_id = ? ORDER BY popularity DESC, rating DESC",
            (dest_id,),
        )

    def get_by_id(self, place_id: int) -> Optional[dict]:
        row = db.fetchone("SELECT * FROM places WHERE id = ?", (place_id,))
        return dict(row) if row else None

    def search(self, query: str) -> list[dict]:
        q = f"%{query}%"
        return db.fetchall_dict(
            "SELECT * FROM places WHERE name LIKE ? OR category LIKE ? OR description LIKE ? LIMIT 20",
            (q, q, q),
        )

    def get_by_category(self, dest_id: int, category: str) -> list[dict]:
        return db.fetchall_dict(
            "SELECT * FROM places WHERE destination_id = ? AND category = ? ORDER BY rating DESC",
            (dest_id, category),
        )

    def insert(self, data: dict) -> int:
        db.execute(
            """INSERT INTO places
               (destination_id, name, category, lat, lon, address, description, rating, popularity, tags)
               VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (data.get("destination_id"), data.get("name"), data.get("category"),
             data.get("lat"), data.get("lon"), data.get("address"),
             data.get("description"), data.get("rating", 0),
             data.get("popularity", 0), data.get("tags", "")),
        )
        return db.last_insert_id()

    def exists(self, dest_id: int, name: str) -> bool:
        row = db.fetchone(
            "SELECT id FROM places WHERE destination_id = ? AND name = ?", (dest_id, name)
        )
        return row is not None


# ── Trips ─────────────────────────────────────────────────────────────────────

class TripRepository:
    """CRUD for the trips table. Every trip belongs to one profile."""

    def get_all(self) -> list[dict]:
        return db.fetchall_dict(
            "SELECT * FROM trips WHERE user_id = ? ORDER BY created_at DESC",
            (get_current_user_id(),),
        )

    def get_by_id(self, trip_id: int) -> Optional[dict]:
        row = db.fetchone(
            "SELECT * FROM trips WHERE id = ? AND user_id = ?",
            (trip_id, get_current_user_id()),
        )
        return dict(row) if row else None

    def get_recent(self, limit: int = 5) -> list[dict]:
        return db.fetchall_dict(
            "SELECT * FROM trips WHERE user_id = ? ORDER BY updated_at DESC LIMIT ?",
            (get_current_user_id(), limit),
        )

    def get_upcoming(self) -> list[dict]:
        today = date.today().isoformat()
        return db.fetchall_dict(
            "SELECT * FROM trips WHERE user_id = ? AND start_date >= ? ORDER BY start_date LIMIT 5",
            (get_current_user_id(), today),
        )

    def insert(self, data: dict) -> int:
        db.execute(
            """INSERT INTO trips
               (user_id, name, origin, origin_lat, origin_lon, destination, dest_lat, dest_lon,
                start_date, end_date, travelers, budget, currency, currency_sym, notes, cover_image, status)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (get_current_user_id(), data.get("name"), data.get("origin"), data.get("origin_lat"),
             data.get("origin_lon"), data.get("destination"), data.get("dest_lat"),
             data.get("dest_lon"), data.get("start_date"), data.get("end_date"),
             data.get("travelers", 1), data.get("budget", 0),
             data.get("currency", "INR"), data.get("currency_sym", "₹"),
             data.get("notes"), data.get("cover_image"), data.get("status", "planned")),
        )
        return db.last_insert_id()

    def update(self, trip_id: int, data: dict) -> None:
        db.execute(
            """UPDATE trips SET name=?, origin=?, destination=?, start_date=?, end_date=?,
               travelers=?, budget=?, notes=?, status=?, cover_image=?, updated_at=datetime('now')
               WHERE id=? AND user_id=?""",
            (data.get("name"), data.get("origin"), data.get("destination"),
             data.get("start_date"), data.get("end_date"), data.get("travelers", 1),
             data.get("budget", 0), data.get("notes"), data.get("status", "planned"),
             data.get("cover_image"), trip_id, get_current_user_id()),
        )

    def delete(self, trip_id: int) -> None:
        db.execute("DELETE FROM trips WHERE id = ? AND user_id = ?", (trip_id, get_current_user_id()))

    # ── Budget helpers ────────────────────────────────────────────────────────

    def get_total_spent(self, trip_id: int) -> float:
        row = db.fetchone("SELECT SUM(amount) as total FROM expenses WHERE trip_id = ?", (trip_id,))
        return row["total"] or 0.0 if row else 0.0


# ── Trip Stops ────────────────────────────────────────────────────────────────

class TripStopRepository:
    """CRUD for trip_stops."""

    def get_by_trip(self, trip_id: int) -> list[dict]:
        return db.fetchall_dict(
            "SELECT * FROM trip_stops WHERE trip_id = ? ORDER BY stop_order", (trip_id,)
        )

    def insert(self, data: dict) -> int:
        db.execute(
            """INSERT INTO trip_stops (trip_id, stop_order, place_name, lat, lon, address, nights, notes)
               VALUES (?,?,?,?,?,?,?,?)""",
            (data["trip_id"], data.get("stop_order", 0), data["place_name"],
             data.get("lat"), data.get("lon"), data.get("address"),
             data.get("nights", 1), data.get("notes")),
        )
        return db.last_insert_id()

    def delete(self, stop_id: int) -> None:
        db.execute("DELETE FROM trip_stops WHERE id = ?", (stop_id,))

    def update_order(self, stop_id: int, new_order: int) -> None:
        db.execute("UPDATE trip_stops SET stop_order = ? WHERE id = ?", (new_order, stop_id))

    def delete_by_trip(self, trip_id: int) -> None:
        db.execute("DELETE FROM trip_stops WHERE trip_id = ?", (trip_id,))


# ── Itinerary ─────────────────────────────────────────────────────────────────

class ItineraryRepository:
    """CRUD for itinerary items."""

    def get_by_trip(self, trip_id: int) -> list[dict]:
        return db.fetchall_dict(
            "SELECT * FROM itinerary WHERE trip_id = ? ORDER BY date, time", (trip_id,)
        )

    def insert(self, data: dict) -> int:
        db.execute(
            """INSERT INTO itinerary (trip_id, date, time, place_name, activity, notes, estimated_cost, currency_sym)
               VALUES (?,?,?,?,?,?,?,?)""",
            (data["trip_id"], data.get("date"), data.get("time"),
             data.get("place_name"), data.get("activity"), data.get("notes"),
             data.get("estimated_cost", 0), data.get("currency_sym", "₹")),
        )
        return db.last_insert_id()

    def delete(self, item_id: int) -> None:
        db.execute("DELETE FROM itinerary WHERE id = ?", (item_id,))


# ── Expenses ──────────────────────────────────────────────────────────────────

class ExpenseRepository:
    """CRUD for expenses. Scoped to the active profile."""

    def get_all(self, trip_id: int | None = None) -> list[dict]:
        if trip_id is not None:
            return db.fetchall_dict(
                "SELECT * FROM expenses WHERE trip_id = ? AND user_id = ? ORDER BY date DESC, created_at DESC",
                (trip_id, get_current_user_id()),
            )
        return db.fetchall_dict(
            "SELECT * FROM expenses WHERE user_id = ? ORDER BY date DESC, created_at DESC",
            (get_current_user_id(),),
        )

    def get_by_id(self, expense_id: int) -> Optional[dict]:
        row = db.fetchone(
            "SELECT * FROM expenses WHERE id = ? AND user_id = ?",
            (expense_id, get_current_user_id()),
        )
        return dict(row) if row else None

    def insert(self, data: dict) -> int:
        db.execute(
            """INSERT INTO expenses (user_id, trip_id, category, amount, currency, currency_sym, date, description, payment_method)
               VALUES (?,?,?,?,?,?,?,?,?)""",
            (get_current_user_id(), data.get("trip_id"), data.get("category", "Other"), data.get("amount", 0),
             data.get("currency", "INR"), data.get("currency_sym", "₹"),
             data.get("date", date.today().isoformat()),
             data.get("description"), data.get("payment_method", "Cash")),
        )
        return db.last_insert_id()

    def update(self, expense_id: int, data: dict) -> None:
        db.execute(
            """UPDATE expenses SET category=?, amount=?, date=?, description=?, payment_method=?
               WHERE id=? AND user_id=?""",
            (data.get("category"), data.get("amount"), data.get("date"),
             data.get("description"), data.get("payment_method"), expense_id, get_current_user_id()),
        )

    def delete(self, expense_id: int) -> None:
        db.execute("DELETE FROM expenses WHERE id = ? AND user_id = ?", (expense_id, get_current_user_id()))

    def get_total(self, trip_id: int) -> float:
        row = db.fetchone("SELECT SUM(amount) as t FROM expenses WHERE trip_id = ?", (trip_id,))
        return (row["t"] or 0.0) if row else 0.0

    def get_by_category(self, trip_id: int) -> dict[str, float]:
        rows = db.fetchall(
            "SELECT category, SUM(amount) as total FROM expenses WHERE trip_id = ? GROUP BY category",
            (trip_id,),
        )
        return {r["category"]: r["total"] for r in rows}

    def get_daily_totals(self, trip_id: int) -> list[dict]:
        return db.fetchall_dict(
            "SELECT date, SUM(amount) as total FROM expenses WHERE trip_id = ? GROUP BY date ORDER BY date",
            (trip_id,),
        )

    def get_recent(self, limit: int = 10) -> list[dict]:
        return db.fetchall_dict(
            "SELECT * FROM expenses WHERE user_id = ? ORDER BY created_at DESC LIMIT ?",
            (get_current_user_id(), limit),
        )


# ── Journal ───────────────────────────────────────────────────────────────────

class JournalRepository:
    """CRUD for journal_entries. Scoped to the active profile."""

    def get_all(self, trip_id: int | None = None) -> list[dict]:
        if trip_id is not None:
            return db.fetchall_dict(
                "SELECT * FROM journal_entries WHERE trip_id = ? AND user_id = ? ORDER BY date DESC",
                (trip_id, get_current_user_id()),
            )
        return db.fetchall_dict(
            "SELECT * FROM journal_entries WHERE user_id = ? ORDER BY date DESC, created_at DESC",
            (get_current_user_id(),),
        )

    def get_by_id(self, entry_id: int) -> Optional[dict]:
        row = db.fetchone(
            "SELECT * FROM journal_entries WHERE id = ? AND user_id = ?",
            (entry_id, get_current_user_id()),
        )
        return dict(row) if row else None

    def get_with_location(self) -> list[dict]:
        return db.fetchall_dict(
            "SELECT * FROM journal_entries WHERE user_id = ? AND lat IS NOT NULL AND lon IS NOT NULL",
            (get_current_user_id(),),
        )

    def insert(self, data: dict) -> int:
        db.execute(
            """INSERT INTO journal_entries
               (user_id, trip_id, title, date, location, lat, lon, description, mood, image_path)
               VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (get_current_user_id(), data.get("trip_id"), data.get("title"), data.get("date", date.today().isoformat()),
             data.get("location"), data.get("lat"), data.get("lon"),
             data.get("description"), data.get("mood"), data.get("image_path")),
        )
        return db.last_insert_id()

    def update(self, entry_id: int, data: dict) -> None:
        db.execute(
            """UPDATE journal_entries SET title=?, date=?, location=?, description=?, mood=?,
               image_path=?, updated_at=datetime('now') WHERE id=? AND user_id=?""",
            (data.get("title"), data.get("date"), data.get("location"),
             data.get("description"), data.get("mood"), data.get("image_path"), entry_id, get_current_user_id()),
        )

    def delete(self, entry_id: int) -> None:
        db.execute("DELETE FROM journal_entries WHERE id = ? AND user_id = ?", (entry_id, get_current_user_id()))


# ── Favorites ─────────────────────────────────────────────────────────────────

class FavoritesRepository:
    """CRUD for favorites. Scoped to the active profile."""

    def get_all(self) -> list[dict]:
        return db.fetchall_dict(
            "SELECT * FROM favorites WHERE user_id = ? ORDER BY created_at DESC",
            (get_current_user_id(),),
        )

    def insert(self, data: dict) -> int:
        db.execute(
            """INSERT INTO favorites (user_id, name, category, lat, lon, address, description, notes, source)
               VALUES (?,?,?,?,?,?,?,?,?)""",
            (get_current_user_id(), data.get("name"), data.get("category"), data.get("lat"), data.get("lon"),
             data.get("address"), data.get("description"), data.get("notes"),
             data.get("source", "user")),
        )
        return db.last_insert_id()

    def delete(self, fav_id: int) -> None:
        db.execute("DELETE FROM favorites WHERE id = ? AND user_id = ?", (fav_id, get_current_user_id()))

    def is_favorited(self, name: str, lat: float, lon: float) -> bool:
        row = db.fetchone(
            "SELECT id FROM favorites WHERE user_id = ? AND name = ? AND ABS(lat - ?) < 0.001 AND ABS(lon - ?) < 0.001",
            (get_current_user_id(), name, lat, lon),
        )
        return row is not None

    def get_by_id(self, fav_id: int) -> Optional[dict]:
        row = db.fetchone(
            "SELECT * FROM favorites WHERE id = ? AND user_id = ?",
            (fav_id, get_current_user_id()),
        )
        return dict(row) if row else None


# ── Search Cache ──────────────────────────────────────────────────────────────

class SearchCacheRepository:
    """Cache for geocoding/search results."""

    def get(self, query: str) -> Optional[Any]:
        row = db.fetchone(
            "SELECT result_json FROM search_cache WHERE query = ? AND created_at > datetime('now', '-1 hour')",
            (query.lower().strip(),),
        )
        if row:
            try:
                return json.loads(row["result_json"])
            except Exception:
                return None
        return None

    def set(self, query: str, result: Any) -> None:
        try:
            json_str = json.dumps(result, ensure_ascii=False)
            db.execute(
                "INSERT OR REPLACE INTO search_cache (query, result_json) VALUES (?,?)",
                (query.lower().strip(), json_str),
            )
        except Exception as exc:
            logger.warning("Failed to cache search result: %s", exc)

    def clear(self) -> None:
        db.execute("DELETE FROM search_cache")


# ── Users ─────────────────────────────────────────────────────────────────────

class UserRepository:
    """Profile management. Supports multiple local profiles (no passwords)."""

    def get_profile(self, user_id: int | None = None) -> dict:
        uid = user_id if user_id is not None else get_current_user_id()
        row = db.fetchone("SELECT * FROM users WHERE id = ?", (uid,))
        if not row:
            db.execute("INSERT INTO users (id, name) VALUES (?, 'Traveller')", (uid,))
            row = db.fetchone("SELECT * FROM users WHERE id = ?", (uid,))
        return dict(row)

    def update_profile(self, data: dict, user_id: int | None = None) -> None:
        uid = user_id if user_id is not None else get_current_user_id()
        db.execute(
            """UPDATE users SET name=?, email=?, home_city=?, home_lat=?, home_lon=?,
               currency=?, currency_sym=?, travel_mode=?, theme=? WHERE id=?""",
            (data.get("name", "Traveller"), data.get("email"),
             data.get("home_city"), data.get("home_lat"), data.get("home_lon"),
             data.get("currency", "INR"), data.get("currency_sym", "₹"),
             data.get("travel_mode", "driving"), data.get("theme", "dark"), uid),
        )

    def get_all_profiles(self) -> list[dict]:
        """All local profiles, for the account switcher."""
        return db.fetchall_dict("SELECT * FROM users ORDER BY id")

    def create_profile(self, name: str) -> int:
        name = (name or "").strip() or "Traveller"
        db.execute("INSERT INTO users (name) VALUES (?)", (name,))
        return db.last_insert_id()

    def delete_profile(self, user_id: int) -> None:
        """Remove a profile and all of its trips/expenses/journal/favorites
        (enforced by ON DELETE CASCADE). Refuses to delete the last profile."""
        profiles = self.get_all_profiles()
        if len(profiles) <= 1:
            raise ValueError("Can't delete the only remaining profile.")
        db.execute("DELETE FROM users WHERE id = ?", (user_id,))


# ── Module-level singleton instances ──────────────────────────────────────────

destination_repo = DestinationRepository()
place_repo       = PlaceRepository()
trip_repo        = TripRepository()
trip_stop_repo   = TripStopRepository()
itinerary_repo   = ItineraryRepository()
expense_repo     = ExpenseRepository()
journal_repo     = JournalRepository()
favorites_repo   = FavoritesRepository()
cache_repo       = SearchCacheRepository()
user_repo        = UserRepository()
