"""
Seed the database with sample destinations, places, and demo trip data.
Called once on first launch.
"""
import json
import logging
from pathlib import Path
from datetime import date, timedelta

from app.database.db import db
from app.database.repositories import destination_repo, place_repo, trip_repo, trip_stop_repo, expense_repo, journal_repo

logger = logging.getLogger(__name__)

_DATA_FILE = Path(__file__).parent.parent.parent / "data" / "destinations.json"


def is_seeded() -> bool:
    """Check whether seed data has already been inserted."""
    row = db.fetchone("SELECT COUNT(*) as cnt FROM destinations")
    return (row["cnt"] if row else 0) > 0


def seed_destinations() -> None:
    """Load destinations.json and insert into DB."""
    if not _DATA_FILE.exists():
        logger.warning("destinations.json not found, skipping seed.")
        return

    with open(_DATA_FILE, encoding="utf-8") as f:
        destinations = json.load(f)

    for dest_data in destinations:
        dest_id = destination_repo.upsert(dest_data)
        for place_data in dest_data.get("places", []):
            if not place_repo.exists(dest_id, place_data["name"]):
                place_repo.insert({**place_data, "destination_id": dest_id})

    logger.info("Seeded %d destinations.", len(destinations))


def seed_demo_trip() -> None:
    """Insert a sample trip with stops, expenses, and journal entry."""
    existing = trip_repo.get_all()
    if existing:
        return  # already has trips

    trip_id = trip_repo.insert({
        "name": "Goa Adventure 2026",
        "origin": "Mumbai",
        "origin_lat": 19.0760,
        "origin_lon": 72.8777,
        "destination": "Goa",
        "dest_lat": 15.2993,
        "dest_lon": 74.1240,
        "start_date": (date.today() + timedelta(days=30)).isoformat(),
        "end_date":   (date.today() + timedelta(days=35)).isoformat(),
        "travelers": 2,
        "budget": 30000,
        "notes": "Sun, sea, and Portuguese vibes. 5 days of bliss.",
        "status": "planned",
    })

    # Stops
    stops = [
        {"trip_id": trip_id, "stop_order": 0, "place_name": "Mumbai",
         "lat": 19.0760, "lon": 72.8777, "nights": 0},
        {"trip_id": trip_id, "stop_order": 1, "place_name": "Pune",
         "lat": 18.5204, "lon": 73.8567, "nights": 1},
        {"trip_id": trip_id, "stop_order": 2, "place_name": "Goa",
         "lat": 15.2993, "lon": 74.1240, "nights": 4},
    ]
    for stop in stops:
        trip_stop_repo.insert(stop)

    # Expenses
    today = date.today().isoformat()
    expenses = [
        {"trip_id": trip_id, "category": "Transport", "amount": 7200,
         "description": "Train + bus tickets Mumbai→Pune→Goa", "date": today},
        {"trip_id": trip_id, "category": "Accommodation", "amount": 5000,
         "description": "Beach shack resort for 4 nights", "date": today},
        {"trip_id": trip_id, "category": "Food", "amount": 4500,
         "description": "Seafood, beach shacks, local cuisine", "date": today},
        {"trip_id": trip_id, "category": "Activities", "amount": 1750,
         "description": "Water sports at Baga Beach", "date": today},
    ]
    for exp in expenses:
        expense_repo.insert(exp)

    # Journal entry
    journal_repo.insert({
        "trip_id": trip_id,
        "title": "Sunset at Baga Beach 🌅",
        "date": today,
        "location": "Baga Beach, Goa",
        "lat": 15.5553,
        "lon": 73.7517,
        "description": "Watched the most gorgeous sunset over the Arabian Sea. The sky turned shades of orange and pink. Had fresh catch of the day at a beach shack. Truly magical.",
        "mood": "Amazing 🤩",
    })

    logger.info("Seeded demo trip (id=%d).", trip_id)


def run_seed() -> None:
    """Entry point: seed everything if not already done."""
    if is_seeded():
        logger.info("Database already seeded, skipping.")
        return
    logger.info("Seeding database...")
    seed_destinations()
    seed_demo_trip()
    logger.info("Database seeding complete.")
