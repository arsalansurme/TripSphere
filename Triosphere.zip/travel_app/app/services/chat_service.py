"""
Chat Service — Supports Gemini API, OpenAI API, Ollama local LLM, or smart offline fallback.
Builds rich travel-context prompts from the user's live trip/budget/itinerary data.
"""
from __future__ import annotations

import json
import logging
import os
import re
import threading
from typing import Callable

import requests

from app.config import DEFAULT_CURRENCY
from app.database.repositories import (
    trip_repo, expense_repo, favorites_repo,
    itinerary_repo, trip_stop_repo, user_repo
)

logger = logging.getLogger(__name__)

# ── API Configuration (read dynamically so .env is always loaded first) ───────
# Keys are looked up at call-time, not module import time.
OPENAI_URL  = "https://api.openai.com/v1/chat/completions"

# ── Ollama fallback ────────────────────────────────────────────────────────────
OLLAMA_URL   = "http://localhost:11434/api/chat"
OLLAMA_MODEL = "qwen3.5:9b"  # default; overridden by model dropdown

# Regex to strip <think>...</think> blocks emitted by reasoning models
_THINK_RE = re.compile(r"<think>.*?</think>", re.DOTALL)


def _get_gemini_key() -> str:
    return os.environ.get("GEMINI_API_KEY", "")


def _get_openai_key() -> str:
    return os.environ.get("OPENAI_API_KEY", "")

SYSTEM_PROMPT = """You are TripSphere AI — a warm, knowledgeable, and practical personal travel assistant embedded inside the TripSphere travel planning application.

Your job is to help the user with:
- What to visit, see, eat and experience near any location
- How to plan an itinerary or day trip efficiently
- Budget advice: how much to carry, cheapest transport options, cost estimates
- Travel logistics: buses, trains, flights, cabs between cities
- Recommendations tailored to the user's current trips, destinations, and saved places

Keep responses concise, practical and warm. Use bullet points when listing places or tips. Be specific — give real names of places, costs in INR where possible, and honest advice.
"""


def _build_context_block() -> str:
    """Pull live data from the DB and format it as a context paragraph."""
    lines: list[str] = []

    # User profile
    try:
        profile = user_repo.get_profile()
        name = profile.get("name", "the user")
        home = profile.get("home_city", "India")
        currency_sym = profile.get("currency_sym", DEFAULT_CURRENCY)
        lines.append(f"User: {name}, home city: {home}, preferred currency: {currency_sym}")
    except Exception:
        currency_sym = DEFAULT_CURRENCY

    # Current / recent trips
    try:
        trips = trip_repo.get_all()
        if trips:
            trip_strs = []
            for t in trips[:3]:
                spent = expense_repo.get_total(trip_id=t["id"]) or 0
                remaining = (t.get("budget") or 0) - spent
                s = (
                    f"  \u2022 '{t.get('name')}' to {t.get('destination', 'unknown')}"
                    f" [{t.get('start_date','?')} \u2192 {t.get('end_date','?')}]"
                    f", budget: {currency_sym}{t.get('budget',0):,.0f}"
                    f", spent: {currency_sym}{spent:,.0f}"
                    f", remaining: {currency_sym}{max(remaining,0):,.0f}"
                )
                trip_strs.append(s)
            lines.append("Active trips:\n" + "\n".join(trip_strs))
    except Exception:
        pass

    # Itinerary stops for latest trip
    try:
        trips = trip_repo.get_all()
        if trips:
            latest = trips[0]
            stops = trip_stop_repo.get_by_trip(latest["id"])
            if stops:
                stop_names = [s.get("place_name", "?") for s in stops[:10]]
                lines.append(f"Trip stops for '{latest.get('name')}': {', '.join(stop_names)}")
    except Exception:
        pass

    # Saved favorites
    try:
        favs = favorites_repo.get_all()
        if favs:
            fav_names = [f.get("name", "?") for f in favs[:10]]
            lines.append(f"Saved places: {', '.join(fav_names)}")
    except Exception:
        pass

    if not lines:
        return ""

    return (
        "\n\n---\n"
        "CONTEXT (user's current data — use this to personalise your answers):\n"
        + "\n".join(lines)
        + "\n---"
    )


class ChatService:
    """Sends messages to Ollama and streams the response token-by-token."""

    def __init__(self):
        self._history: list[dict] = []
        self._model: str = OLLAMA_MODEL
        self._active_trip: dict | None = None

    # ── Public API ─────────────────────────────────────────────────────────────

    def set_active_trip(self, trip: dict | None) -> None:
        self._active_trip = trip

    def send(
        self,
        user_message: str,
        on_token: Callable[[str], None],
        on_done: Callable[[], None],
        on_error: Callable[[str], None],
    ) -> None:
        """
        Send a message to Ollama in a background thread.
        Calls on_token(str) for each streamed token, then on_done().
        """
        self._history.append({"role": "user", "content": user_message})
        thread = threading.Thread(
            target=self._stream,
            args=(user_message, on_token, on_done, on_error),
            daemon=True,
        )
        thread.start()

    def clear_history(self) -> None:
        self._history.clear()

    def set_model(self, model: str) -> None:
        self._model = model

    def get_available_models(self) -> list[str]:
        """Return list of locally installed Ollama models + API models if keys exist."""
        models = []
        if _get_gemini_key():
            models.append("Google Gemini 2.0 Flash")
            models.append("Google Gemini 1.5 Flash")
        if _get_openai_key():
            models.append("OpenAI GPT-4o-Mini")

        # Query local Ollama tags
        local_ollama_models = []
        try:
            r = requests.get("http://localhost:11434/api/tags", timeout=2)
            if r.status_code == 200:
                data = r.json()
                local_ollama_models = [m["name"] for m in data.get("models", [])]
        except Exception:
            pass

        if local_ollama_models:
            models.extend(local_ollama_models)
        else:
            # Add default local options so user can configure locally
            models.append("gemma")
            models.append("qwen3.5:9b")

        models.append("TripSphere Smart Concierge (Offline)")
        return models

    # ── Internal ───────────────────────────────────────────────────────────────

    def _stream(
        self,
        user_message: str,
        on_token: Callable[[str], None],
        on_done: Callable[[], None],
        on_error: Callable[[str], None],
    ) -> None:
        context = _build_context_block()
        if self._active_trip:
            context += f"\nCurrently selected trip context: {self._active_trip.get('name')} to {self._active_trip.get('destination')}"
        system = SYSTEM_PROMPT + context

        model_lower = self._model.lower()
        if "gemini" in model_lower:
            model_code = "gemini-2.0-flash" if "2.0" in self._model else "gemini-1.5-flash"
            logger.info("Using Gemini API for chat (%s).", model_code)
            self._stream_gemini(user_message, system, model_code, on_token, on_done, on_error)
        elif "gpt" in model_lower or "openai" in model_lower:
            logger.info("Using OpenAI API for chat.")
            self._stream_openai(user_message, system, on_token, on_done, on_error)
        elif "offline" in model_lower or "smart assistant" in model_lower or "concierge" in model_lower:
            logger.info("Using Smart Offline Concierge.")
            self._stream_fallback(user_message, on_token, on_done)
        else:
            logger.info("Using local Ollama model: %s", self._model)
            self._stream_ollama(user_message, system, on_token, on_done, on_error)

    def _stream_gemini(
        self,
        user_message: str,
        system: str,
        model_code: str,
        on_token: Callable[[str], None],
        on_done: Callable[[], None],
        on_error: Callable[[str], None],
    ) -> None:
        """Call Google Gemini API."""
        gemini_key = _get_gemini_key()
        history_contents = []
        for msg in self._history[:-1]:  # exclude just-added user message
            role = "user" if msg["role"] == "user" else "model"
            history_contents.append({"role": role, "parts": [{"text": msg["content"]}]})
        # Add the current user turn
        history_contents.append({"role": "user", "parts": [{"text": user_message}]})

        payload = {
            "system_instruction": {"parts": [{"text": system}]},
            "contents": history_contents,
            "generationConfig": {"temperature": 0.8, "maxOutputTokens": 1024},
        }
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{model_code}:generateContent?key={gemini_key}"
        try:
            resp = requests.post(url, json=payload, timeout=30)
            if resp.status_code != 200:
                logger.error("Gemini API HTTP %d: %s", resp.status_code, resp.text[:400])
                self._stream_ollama(user_message, system, on_token, on_done, on_error)
                return
            data = resp.json()
            candidates = data.get("candidates", [])
            if not candidates:
                logger.error("Gemini returned no candidates: %s", data)
                self._stream_ollama(user_message, system, on_token, on_done, on_error)
                return
            text = candidates[0]["content"]["parts"][0]["text"]
            self._history.append({"role": "assistant", "content": text})
            self._stream_text(text, on_token, on_done)
        except Exception as exc:
            logger.error("Gemini API error: %s — falling back to Ollama", exc)
            self._stream_ollama(user_message, system, on_token, on_done, on_error)

    def _stream_openai(
        self,
        user_message: str,
        system: str,
        on_token: Callable[[str], None],
        on_done: Callable[[], None],
        on_error: Callable[[str], None],
    ) -> None:
        """Call OpenAI Chat Completions API."""
        openai_key = _get_openai_key()
        messages = [{"role": "system", "content": system}]
        messages += self._history  # already includes current user message
        payload = {"model": "gpt-4o-mini", "messages": messages, "temperature": 0.8, "max_tokens": 1024}
        headers = {"Authorization": f"Bearer {openai_key}", "Content-Type": "application/json"}
        try:
            resp = requests.post(OPENAI_URL, json=payload, headers=headers, timeout=30)
            resp.raise_for_status()
            data = resp.json()
            text = data["choices"][0]["message"]["content"]
            self._history.append({"role": "assistant", "content": text})
            self._stream_text(text, on_token, on_done)
        except Exception as exc:
            logger.error("OpenAI API error: %s — falling back to Ollama", exc)
            self._stream_ollama(user_message, system, on_token, on_done, on_error)

    def _stream_ollama(
        self,
        user_message: str,
        system: str,
        on_token: Callable[[str], None],
        on_done: Callable[[], None],
        on_error: Callable[[str], None],
    ) -> None:
        """Stream from local Ollama instance."""
        messages = [{"role": "system", "content": system}]
        messages += self._history  # includes the user message just appended

        payload = {
            "model": self._model,
            "messages": messages,
            "stream": True,
        }

        full_response = ""
        try:
            with requests.post(
                OLLAMA_URL, json=payload, stream=True, timeout=120
            ) as resp:
                if resp.status_code != 200:
                    try:
                        err_body = resp.json().get("error", resp.text[:200])
                    except Exception:
                        err_body = resp.text[:200]
                    on_error(f"Ollama error ({resp.status_code}):\n{err_body}")
                    return

                for raw_line in resp.iter_lines():
                    if not raw_line:
                        continue
                    try:
                        chunk = json.loads(raw_line)
                    except json.JSONDecodeError:
                        continue

                    token = chunk.get("message", {}).get("content", "")
                    if token:
                        full_response += token
                        # Strip thinking tags before displaying
                        display = _THINK_RE.sub("", full_response).lstrip()
                        on_token(display)

                    if chunk.get("done", False):
                        break

            self._history.append({"role": "assistant", "content": _THINK_RE.sub("", full_response).strip()})
            on_done()

        except (requests.exceptions.ConnectionError, requests.exceptions.Timeout):
            logger.info("Ollama offline — using Smart Travel Assistant Engine.")
            self._stream_fallback(user_message, on_token, on_done)
        except Exception as exc:
            logger.error("Chat stream error: %s — using Smart Travel Assistant Engine", exc)
            self._stream_fallback(user_message, on_token, on_done)

    def _stream_text(
        self,
        text: str,
        on_token: Callable[[str], None],
        on_done: Callable[[], None],
    ) -> None:
        """Simulate streaming by emitting word-by-word for a smooth UX."""
        import time
        words = text.split(" ")
        accumulated = ""
        for i, word in enumerate(words):
            accumulated += (word + (" " if i < len(words) - 1 else ""))
            on_token(accumulated)
            time.sleep(0.015)
        on_done()

    def _stream_fallback(
        self,
        user_message: str,
        on_token: Callable[[str], None],
        on_done: Callable[[], None],
    ) -> None:
        import time
        response = self._generate_smart_fallback(user_message)
        words = response.split(" ")
        accumulated = ""
        for i, word in enumerate(words):
            accumulated += (word + (" " if i < len(words) - 1 else ""))
            on_token(accumulated)
            time.sleep(0.02)
        self._history.append({"role": "assistant", "content": response})
        on_done()

    def _generate_smart_fallback(self, query: str) -> str:
        q = query.lower().strip()

        # Greetings
        if q in ["hi", "hii", "hiii", "hello", "hey", "good morning", "good afternoon", "good evening"]:
            _name = user_repo.get_profile().get("name") or "there"
            return (
                f"Hello {_name}! 👋 How can I help you escape or plan your journey today?\n\n"
                "You can ask me about:\n"
                "• Recommendations for any city or country (e.g. Paris, Tokyo, Bali, Goa)\n"
                "• Day-by-day itineraries and top attractions\n"
                "• Travel budgets, flights, trains, and food spots"
            )

        # Paris / France
        if "paris" in q or "france" in q:
            return (
                "Paris Travel Highlights 🇫🇷:\n\n"
                "• Eiffel Tower & Champ de Mars — Best viewed at dusk from Trocadéro.\n"
                "• Louvre Museum & Musée d'Orsay — Masterpieces and Impressionist art.\n"
                "• Montmartre & Sacré-Cœur — Bohemian streets and panoramic city views.\n"
                "• Food & Wine — Fresh croissants at local boulangeries, bistro duck confit & Bordeaux wine."
            )

        # Japan / Tokyo / Kyoto
        if "tokyo" in q or "kyoto" in q or "japan" in q:
            return (
                "Japan Travel Highlights 🇯🇵:\n\n"
                "• Tokyo — Shibuya Crossing, Senso-ji Temple in Asakusa, and futuristic TeamLab Planets.\n"
                "• Kyoto — Arashiyama Bamboo Grove, Fushimi Inari Shrines, and Gion geisha district.\n"
                "• Culinary Highlights — Authentic Tonkotsu Ramen, Tsukiji Omakase Sushi, and Matcha sweets.\n"
                "• Transit Tip — Get a JR Pass or Suica card for seamless Shinkansen bullet train rides!"
            )

        # Switzerland / Swiss Alps
        if "swiss" in q or "switzerland" in q or "alps" in q:
            return (
                "Switzerland Travel Highlights 🇨🇭:\n\n"
                "• Interlaken & Jungfraujoch — 'Top of Europe' glacier views and alpine cable cars.\n"
                "• Lucerne — Chapel Bridge, Lake Lucerne cruises, and Mount Pilatus cogwheel railway.\n"
                "• Scenic Trains — Glacier Express & Bernina Express panoramic rail journeys."
            )

        # Bali / Indonesia
        if "bali" in q or "indonesia" in q:
            return (
                "Bali Escapes 🏝:\n\n"
                "• Ubud — Tegallalang rice terraces, sacred Monkey Forest, and wellness retreats.\n"
                "• Uluwatu — Cliffside temples, Kecak fire dances, and world-class surfing.\n"
                "• Nusa Penida — Kelingking T-Rex beach and crystal clear snorkeling bays."
            )

        # Marine Drive / Mumbai
        if "marine drive" in q or "mumbai" in q:
            return (
                "Top recommendations near Marine Drive, Mumbai 🌊:\n\n"
                "• Girgaon Chowpatty — Famous for Pav Bhaji, Bhel Puri, and sunset walks.\n"
                "• Nariman Point — Panoramic skyline view of Queen's Necklace.\n"
                "• Gateway of India & Taj Mahal Palace — Iconic heritage landmarks.\n"
                "• Kala Ghoda Arts Precinct — Cafes, art galleries, and colonial architecture."
            )

        # Itinerary advice
        if "one day" in q or "1 day" in q or "complete" in q or "itinerary" in q:
            return (
                "Here is an efficient 1-Day Exploring Itinerary ⏱:\n\n"
                "• Morning (9 AM - 12 PM): Key heritage landmarks & iconic photo spots.\n"
                "• Afternoon (12:30 PM - 3:30 PM): Regional food tasting + local market walk.\n"
                "• Evening (4 PM - 7:30 PM): Sunset scenic point, beach, or rooftop lounge.\n\n"
                "💡 Tip: Group nearby sights by district to minimize travel time!"
            )

        # Budget advice
        if "money" in q or "budget" in q or "cost" in q or "carry" in q:
            if self._active_trip:
                name = self._active_trip.get("name", "your trip")
                b = self._active_trip.get("budget", 0)
                return f"For your '{name}', your set budget is {DEFAULT_CURRENCY}{b:,.0f}. Plan ~₹3,000/day for meals, transit, and passes."
            return (
                "Travel Budget Guide 💰:\n\n"
                "• Average Daily Budget: ₹2,500 – ₹5,000 per person (meals, passes, & cabs).\n"
                "• Cash vs Card: Keep 30% in cash for local street stalls/autos, rest via UPI/Cards."
            )

        # Transport & Goa
        if "goa" in q or "cheapest" in q or "transport" in q:
            return (
                "Travel & Transport Guide ✈🚆:\n\n"
                "• Train: Konkan Kanya or Jan Shatabdi (~₹450 – ₹1,200 sleeper/3AC).\n"
                "• AC Sleeper Bus: Convenient overnight routes (~₹900 – ₹1,800).\n"
                "• Flight: Direct 1h 15m flights (~₹2,400+)."
            )

        # Active selected trip query fallback
        if self._active_trip:
            name = self._active_trip.get("name")
            dest = self._active_trip.get("destination")
            return (
                f"Regarding your trip '{name}' to {dest}: ✈\n\n"
                f"• Dates: {self._active_trip.get('start_date')} to {self._active_trip.get('end_date')}\n"
                f"• Budget: {DEFAULT_CURRENCY}{self._active_trip.get('budget', 0):,.0f}\n\n"
                "What specific details or places would you like to explore for this trip?"
            )

        return (
            "I'm your Elite Travel Concierge! ✈ Where would you like to explore today?\n\n"
            "Ask me anything about:\n"
            "• Destination recommendations (e.g. Paris, Tokyo, Bali, Goa)\n"
            "• Itineraries, top attractions, and food spots\n"
            "• Travel logistics, flight routes, and budgets"
        )




# ── Singleton ──────────────────────────────────────────────────────────────────
chat_service = ChatService()
