"""
Journal service — CRUD for travel journal entries.
"""
from __future__ import annotations

from app.database.repositories import journal_repo


class JournalService:

    def create_entry(self, data: dict) -> int:
        return journal_repo.insert(data)

    def update_entry(self, entry_id: int, data: dict) -> None:
        journal_repo.update(entry_id, data)

    def delete_entry(self, entry_id: int) -> None:
        journal_repo.delete(entry_id)

    def get_all(self, trip_id: int | None = None) -> list[dict]:
        return journal_repo.get_all(trip_id)

    def get_entry(self, entry_id: int) -> dict | None:
        return journal_repo.get_by_id(entry_id)

    def get_map_entries(self) -> list[dict]:
        """Return entries that have GPS coordinates (for map markers)."""
        return journal_repo.get_with_location()


journal_service = JournalService()
