"""
Expense service — budget calculations and analytics data.
"""
from __future__ import annotations

import logging
from app.database.repositories import expense_repo, trip_repo

logger = logging.getLogger(__name__)

CATEGORY_COLORS = {
    "Transport":       "#6366F1",
    "Accommodation":   "#EC4899",
    "Food":            "#F97316",
    "Activities":      "#22C55E",
    "Shopping":        "#A855F7",
    "Fuel":            "#EAB308",
    "Local Transport": "#06B6D4",
    "Other":           "#94A3B8",
}


class ExpenseService:

    def add_expense(self, data: dict) -> int:
        return expense_repo.insert(data)

    def delete_expense(self, expense_id: int) -> None:
        expense_repo.delete(expense_id)

    def update_expense(self, expense_id: int, data: dict) -> None:
        expense_repo.update(expense_id, data)

    def get_trip_summary(self, trip_id: int) -> dict:
        trip         = trip_repo.get_by_id(trip_id)
        budget       = (trip.get("budget") or 0) if trip else 0
        spent        = expense_repo.get_total(trip_id)
        remaining    = budget - spent
        pct          = (spent / budget * 100) if budget > 0 else 0
        by_cat       = expense_repo.get_by_category(trip_id)
        daily        = expense_repo.get_daily_totals(trip_id)
        currency_sym = (trip.get("currency_sym") or "₹") if trip else "₹"
        return {
            "budget":       budget,
            "spent":        spent,
            "remaining":    remaining,
            "pct":          min(pct, 100),
            "by_category":  by_cat,
            "daily_totals": daily,
            "currency_sym": currency_sym,
            "category_colors": CATEGORY_COLORS,
        }

    def get_all_time_total(self) -> float:
        rows = expense_repo.get_recent(9999)
        return sum(r.get("amount", 0) for r in rows)

    def get_recent(self, limit: int = 10) -> list[dict]:
        return expense_repo.get_recent(limit)


expense_service = ExpenseService()
