"""
TripSphere Gemini Client — Isolated connection layer to Google Gemini API.

Phase 2C adds tool/function calling support via a bounded tool loop.

This module is the ONLY place in the codebase that imports google.genai.
It is intentionally kept thin and free of business logic so that:
  - It can be tested independently.
  - assistant_agent.py can import it without circular dependencies.
  - The API key never leaks into logs or terminal output.

Model: gemini-3.5-flash
  Rationale:
    • Free-tier supported.
    • Confirmed working with function calling + thinking_budget=0.
    • Low-latency — suitable for interactive travel chat.
"""
from __future__ import annotations

import logging
import os
import time
from dataclasses import dataclass, field
from typing import Callable, Optional

logger = logging.getLogger(__name__)

# ── Model Configuration ────────────────────────────────────────────────────────
# Default to gemini-3.1-flash-lite (current supported Google GenAI model on free tier).
# Configurable via GEMINI_MODEL in environment / .env file.
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-3.1-flash-lite")

# Maximum number of tool-call rounds per single user message.
# Prevents runaway Gemini tool loops (e.g. 5 × search_location in one turn).
MAX_TOOL_ITERATIONS = 5


# ── Response Container ─────────────────────────────────────────────────────────

@dataclass
class GeminiResponse:
    """Typed result returned by the Gemini client."""
    text: str
    model: str
    success: bool = True
    error: Optional[str] = None
    usage: dict = field(default_factory=dict)
    # Total tool calls executed in this exchange (informational)
    tool_calls_made: int = 0


# ── Key Validation ─────────────────────────────────────────────────────────────

class GeminiKeyError(RuntimeError):
    """Raised when the GEMINI_API_KEY is missing or empty."""


def _get_api_key() -> str:
    """
    Read the API key from the environment.

    config.py calls load_dotenv() at import time, so the key is available via
    os.environ when this function runs. The key is never stored in a module-level
    variable, never logged, and never printed.
    """
    key = os.environ.get("GEMINI_API_KEY", "").strip()
    if not key:
        raise GeminiKeyError(
            "GEMINI_API_KEY is missing. "
            "Add it to your .env file: GEMINI_API_KEY=<your-key>"
        )
    return key


# ── Client Factory (cached singleton) ─────────────────────────────────────────
# The client is built once and reused across all chat() calls.
# Avoids per-call TCP handshake + auth overhead (~50-150 ms on first connection).

_cached_client = None
_cached_client_lock = __import__('threading').Lock()


def _build_client():
    """
    Return a cached google.genai.Client instance, creating it on first call.

    Imported lazily so the rest of the app doesn't fail at startup when
    google-genai is not yet installed.
    """
    global _cached_client
    # Fast path: already initialised
    if _cached_client is not None:
        return _cached_client

    with _cached_client_lock:
        # Re-check after acquiring lock (double-checked locking)
        if _cached_client is not None:
            return _cached_client

        try:
            from google import genai  # type: ignore[import]
        except ImportError as exc:
            raise ImportError(
                "google-genai is not installed. Run: pip install google-genai>=1.0.0"
            ) from exc

        api_key = _get_api_key()
        _cached_client = genai.Client(api_key=api_key)
        logger.info("Gemini client created and cached (key length: %d)", len(api_key))
        return _cached_client


# ── Internal: content builder ──────────────────────────────────────────────────

def _build_initial_contents(
    user_message: str,
    history: Optional[list[dict]],
    types: object,
) -> list:
    """
    Convert conversation history + current user message into a list of
    google.genai.types.Content objects for the initial generate_content call.

    history format:  [{"role": "user"|"model", "content": str}, ...]
    The current user_message is appended as the final Content.
    """
    contents = []

    if history:
        for msg in history:
            role = "user" if msg.get("role") == "user" else "model"
            contents.append(
                types.Content(
                    role=role,
                    parts=[types.Part(text=msg["content"])],
                )
            )

    # Append the current user turn
    contents.append(
        types.Content(
            role="user",
            parts=[types.Part(text=user_message)],
        )
    )
    return contents


# ── Internal: tool loop ────────────────────────────────────────────────────────

def _generate_with_retry(client, model: str, contents: list, config: object, max_retries: int = 3):
    """
    Call client.models.generate_content with exponential backoff on transient 429/503.
    """
    delay = 3.0
    for attempt in range(max_retries):
        try:
            return client.models.generate_content(
                model=model,
                contents=contents,
                config=config,
            )
        except Exception as exc:
            exc_str = str(exc).lower()
            is_transient = "429" in exc_str or "503" in exc_str or "resource_exhausted" in exc_str
            if is_transient and attempt < max_retries - 1:
                logger.warning(
                    "Gemini API rate limit or transient error (attempt %d/%d). Backing off for %.1fs...",
                    attempt + 1, max_retries, delay,
                )
                time.sleep(delay)
                delay *= 2.0
            else:
                raise


def _extract_usage(response) -> dict:
    """Pull token counts from a GenerateContentResponse."""
    usage_meta = {}
    if hasattr(response, "usage_metadata") and response.usage_metadata:
        um = response.usage_metadata
        usage_meta = {
            "input_tokens":  getattr(um, "prompt_token_count", 0),
            "output_tokens": getattr(um, "candidates_token_count", 0),
        }
    return usage_meta


def _get_function_calls(response) -> list:
    """
    Extract all function_call parts from a GenerateContentResponse.
    Returns a list of FunctionCall objects (may be empty).
    """
    if not response.candidates:
        return []
    parts = response.candidates[0].content.parts or []
    return [p.function_call for p in parts if p.function_call]


def _run_tool_loop(
    client,
    model: str,
    contents: list,
    generate_config,
    tool_executor: Callable[[str, dict], dict],
    types: object,
) -> tuple[object, int]:
    """
    Execute the tool call ↔ Gemini conversation loop.

    Each iteration:
      1. Call Gemini.
      2. If the response contains function_call parts → execute each tool via
         tool_executor and append (model function_call + user function_response)
         to contents.
      3. Call Gemini again with the enriched contents.
      4. Repeat until Gemini returns a text response or MAX_TOOL_ITERATIONS reached.

    Returns:
      (final_response, total_tool_calls_made)

    SECURITY:
      tool_executor is the AssistantAgent._execute_tool() method which
      validates every call against an explicit allowlist before execution.
      This function never calls eval() / exec() or dynamic imports.
    """
    total_tool_calls = 0

    for iteration in range(MAX_TOOL_ITERATIONS):
        response = _generate_with_retry(
            client=client,
            model=model,
            contents=contents,
            config=generate_config,
        )

        function_calls = _get_function_calls(response)

        # No function calls → Gemini returned a final text response
        if not function_calls:
            logger.info(
                "Tool loop finished after %d iteration(s), %d tool call(s)",
                iteration + 1,
                total_tool_calls,
            )
            return response, total_tool_calls

        # Append the model's actual response turn directly to history.
        # This preserves model-internal thought_signature, call IDs, and thoughts
        # required by gemini-3.5-flash / thinking models during multi-turn tool loops.
        contents.append(response.candidates[0].content)

        # Process every function_call in this response turn
        user_function_responses = []

        for fc in function_calls:
            tool_name = fc.name
            tool_args = dict(fc.args) if fc.args else {}
            total_tool_calls += 1

            logger.info(
                "Gemini requested tool [iter=%d, call=%d]: %s(%s)",
                iteration + 1,
                total_tool_calls,
                tool_name,
                {k: str(v)[:40] for k, v in tool_args.items()},
            )

            # Execute via the allowlist-guarded executor
            tool_result = tool_executor(tool_name, tool_args)

            logger.info(
                "Tool result for %s: success=%s",
                tool_name,
                tool_result.get("found", tool_result.get("success", True)),
            )

            # Collect the function_response for the user's Content turn
            user_function_responses.append(
                types.Part.from_function_response(
                    name=tool_name,
                    response=tool_result,
                )
            )

        # Append our tool-result turn (role must be "user" per Gemini protocol)
        contents.append(
            types.Content(role="user", parts=user_function_responses)
        )

    # MAX_TOOL_ITERATIONS reached without a text response
    logger.warning(
        "Tool loop hit MAX_TOOL_ITERATIONS (%d). Forcing final Gemini call.",
        MAX_TOOL_ITERATIONS,
    )
    # One final call without tools to force a text response
    thinking_cfg = types.ThinkingConfig(thinking_budget=0) if "3.5" in model else None
    final_config = types.GenerateContentConfig(
        temperature=0.7,
        max_output_tokens=1024,
        thinking_config=thinking_cfg,
        system_instruction=generate_config.system_instruction,
        # No tools in this final call — forces text output
    )
    response = _generate_with_retry(
        client=client,
        model=model,
        contents=contents,
        config=final_config,
    )
    return response, total_tool_calls


# ── Public API ─────────────────────────────────────────────────────────────────

def chat(
    user_message: str,
    system_instruction: str = "",
    history: Optional[list[dict]] = None,
    tools: Optional[list] = None,
    tool_executor: Optional[Callable[[str, dict], dict]] = None,
    model: str = GEMINI_MODEL,
) -> GeminiResponse:
    """
    Send a user message to Gemini and return the final natural-language response.

    Supports multi-turn conversation (history) and Gemini tool/function calling
    (tools + tool_executor). When Gemini requests a tool call, the loop in
    _run_tool_loop() executes Python functions via the allowlist-guarded
    tool_executor, sends results back, and loops until Gemini returns text.

    THREADING NOTE:
      This function makes one or more synchronous network calls to Gemini.
      It MUST be called from a background QThread worker (chat.py) to avoid
      blocking the Qt main thread. The tool execution also happens in the worker
      thread (safe: only geocoding HTTP calls, no Qt or SQLite writes).

    Args:
        user_message:       The user's input text (current turn).
        system_instruction: Optional system prompt (context injected by agent).
        history:            Prior turns [{role, content}] — excludes current msg.
        tools:              List of google.genai.types.Tool declarations to offer.
        tool_executor:      Callable(tool_name, args) -> dict.
                            Must validate against an allowlist before execution.
        model:              Gemini model name (default: gemini-3.5-flash).

    Returns:
        GeminiResponse with text=final_text, success=True/False, tool_calls_made.

    Error Classification (all return success=False, no exceptions escape):
        Missing key      → GeminiKeyError
        Invalid key      → 401
        Permission       → 403
        Rate limit       → 429
        Overloaded       → 503
        Model not found  → 404
        Network          → ConnectionError / Timeout
        SDK missing      → ImportError
    """
    try:
        from google import genai       # type: ignore[import]
        from google.genai import types  # type: ignore[import]

        client = _build_client()

        # Build the GenerateContentConfig.
        # thinking_budget=0 is only required on gemini-3.5-flash to prevent silent
        # reasoning loops; newer models like gemini-3.6-flash reject thinking_budget=0.
        thinking_cfg = types.ThinkingConfig(thinking_budget=0) if "3.5" in model else None
        generate_config = types.GenerateContentConfig(
            temperature=0.7,
            max_output_tokens=1024,
            thinking_config=thinking_cfg,
            system_instruction=system_instruction if system_instruction else None,
            tools=tools if tools else None,
        )

        tool_names = [
            fd.name
            for t in (tools or [])
            for fd in getattr(t, "function_declarations", [])
        ]
        logger.info(
            "Gemini chat | model=%s | history=%d turns | tools=%s | msg_len=%d",
            model,
            len(history) if history else 0,
            tool_names if tool_names else "none",
            len(user_message),
        )

        # Build the initial contents list (history + current user turn)
        contents = _build_initial_contents(user_message, history, types)

        # Run tool loop (handles 0 or more tool call rounds)
        if tools and tool_executor:
            response, tool_calls_made = _run_tool_loop(
                client, model, contents, generate_config, tool_executor, types
            )
        else:
            response = _generate_with_retry(
                client=client,
                model=model,
                contents=contents,
                config=generate_config,
            )
            tool_calls_made = 0

        # ── Extract final text ─────────────────────────────────────────────────
        if not response.candidates:
            logger.error("Gemini returned 0 candidates. Response: %s", response)
            return GeminiResponse(
                text="",
                model=model,
                success=False,
                error="Gemini returned no candidates in response.",
                tool_calls_made=tool_calls_made,
            )

        text = response.text  # SDK property; raises if content blocked
        if text is None:
            # This can happen if the last response was also a function_call
            # (very unusual — means MAX_TOOL_ITERATIONS was insufficient)
            logger.error("Gemini response.text is None after tool loop. Parts: %s",
                         response.candidates[0].content.parts)
            return GeminiResponse(
                text="",
                model=model,
                success=False,
                error="Gemini did not return a text response after tool calls.",
                tool_calls_made=tool_calls_made,
            )

        usage_meta = _extract_usage(response)
        logger.info(
            "Gemini done | tools_called=%d | tokens in=%s out=%s",
            tool_calls_made,
            usage_meta.get("input_tokens", "?"),
            usage_meta.get("output_tokens", "?"),
        )

        return GeminiResponse(
            text=text,
            model=model,
            success=True,
            usage=usage_meta,
            tool_calls_made=tool_calls_made,
        )

    except GeminiKeyError as exc:
        logger.error("Gemini API key error: %s", exc)
        return GeminiResponse(
            text="", model=model, success=False,
            error=str(exc), tool_calls_made=0,
        )

    except ImportError as exc:
        logger.error("google-genai SDK not installed: %s", exc)
        return GeminiResponse(
            text="", model=model, success=False,
            error="google-genai package is not installed.", tool_calls_made=0,
        )

    except Exception as exc:
        exc_str   = str(exc)
        exc_lower = exc_str.lower()

        # Check 404 FIRST — model-not-found errors may also mention 'quota'
        if "404" in exc_str:
            msg = (
                f"Gemini model '{model}' not found or removed. "
                "Check the model name against current available models."
            )
        elif "401" in exc_str or "invalid api key" in exc_lower or "api_key_invalid" in exc_lower:
            msg = "Gemini API key is invalid. Check your .env file."
        elif "403" in exc_str or "permission_denied" in exc_lower:
            msg = "Gemini API permission denied. Check project billing or API access."
        elif "429" in exc_str or "resource_exhausted" in exc_lower:
            msg = "Gemini API rate limit reached. Please wait before retrying."
        elif "503" in exc_str or "unavailable" in exc_lower:
            msg = "Gemini model is temporarily overloaded. Please try again in a few seconds."
        elif "network" in exc_lower or "connection" in exc_lower or "timeout" in exc_lower:
            msg = "Network error communicating with Gemini API. Check internet connection."
        else:
            msg = f"Gemini API error: {exc_str}"

        logger.error("Gemini call failed [%s]: %s", type(exc).__name__, msg)
        return GeminiResponse(
            text="", model=model, success=False,
            error=msg, tool_calls_made=0,
        )
