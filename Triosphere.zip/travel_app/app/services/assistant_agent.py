"""
TripSphere AI Travel Assistant Agent — Gemini-powered conversational engine.

Architecture (Phase 2C):
  User message
    → _extract_and_update_state()   # regex slot-filling (sync, no network)
    → _build_system_instruction()   # inject ConversationState into Gemini prompt
    → gemini_client.chat()          # Gemini API call  ← runs in QThread worker
        → Gemini may call search_location via function calling
        → _execute_tool() validates against TOOL_ALLOWLIST and executes
        → result returned to Gemini for natural-language response
    → AssistantResponse             # returned to ChatScreen

Tool calling design:
  • TOOL_ALLOWLIST: explicit dict of allowed tool names → callables.
    Only tools listed here can be invoked. No eval(), no exec().
  • Phase 2C active tool: search_location only.
  • All other TravelToolRegistry methods exist but are NOT in TOOL_ALLOWLIST yet.
  • Phase 2D+ will add: get_route, search_flights, search_hotels, etc.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from datetime import date, timedelta
from typing import Any, Callable, Optional

from app.api.geocoding import geocoding_service
from app.api.routing import routing_service
from app.api.places import places_service
from app.services.trip_service import trip_service
from app.services.expense_service import expense_service
from app.services.travel_providers import travel_provider_service
from app.database.repositories import user_repo, trip_repo, expense_repo
from app.services.gemini_client import chat as gemini_chat, GEMINI_MODEL

logger = logging.getLogger(__name__)

# ── Travel Style Reference (used for context injection) ───────────────────────
TRAVEL_STYLES = [
    "Beach", "Mountains", "Historic", "Nature", "City", "Adventure",
    "Relaxation", "Family", "Couple", "Budget travel", "Luxury",
    "Food-focused", "Cultural", "Road trip"
]

# ── Phase 2C: Gemini Tool Declarations ───────────────────────────────────────
# Lazily built on first access so that google.genai is not imported at module
# load time (preserves the startup-safe lazy-import pattern in gemini_client.py).

def _build_tool_declarations():
    """
    Construct google.genai Tool objects exposing TripSphere's travel tools.
    Declared schemas match the exact parameters of existing TravelToolRegistry functions.
    """
    from google.genai import types  # type: ignore[import]

    decls = [
        types.FunctionDeclaration(
            name="search_location",
            description=(
                "Search and resolve a geographic location using TripSphere's geocoding service. "
                "Returns location name, latitude, longitude, and country. "
                "Call when the user asks to find, locate, or look up a city, country, region, or landmark."
            ),
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    "query": types.Schema(type=types.Type.STRING, description="Location name (e.g. 'Spain', 'Goa', 'Paris')"),
                },
                required=["query"],
            ),
        ),
        types.FunctionDeclaration(
            name="get_route",
            description=(
                "Calculate driving distance, duration, and route summary between two locations. "
                "Call when the user asks for the route, distance, or driving time between two places."
            ),
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    "origin": types.Schema(type=types.Type.STRING, description="Starting location name"),
                    "destination": types.Schema(type=types.Type.STRING, description="Destination location name"),
                    "mode": types.Schema(type=types.Type.STRING, description="Travel mode: 'driving', 'walking', or 'cycling'"),
                },
                required=["origin", "destination"],
            ),
        ),
        types.FunctionDeclaration(
            name="find_nearby_places",
            description=(
                "Search and discover real nearby places (restaurants, cafes, hotels, museums, beaches, parks, shopping, fuel, hospitals, ATMs, attractions) "
                "around a named location or coordinates within a given radius. "
                "Call when the user asks what's nearby, or wants to find places, food, sights, or amenities in or near a city/area."
            ),
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    "location": types.Schema(type=types.Type.STRING, description="City, area, or location name to search around (e.g. 'Mumbai', 'Goa', 'Delhi', 'London')"),
                    "category": types.Schema(type=types.Type.STRING, description="Category: 'Restaurants', 'Cafes', 'Hotels', 'Museums', 'Beaches', 'Parks', 'Shopping', 'Fuel', 'Hospitals', 'ATMs', 'Attractions'"),
                    "radius_km": types.Schema(type=types.Type.INTEGER, description="Search radius in kilometers: 1, 2, 5, or 10. Default is 5."),
                    "lat": types.Schema(type=types.Type.NUMBER, description="Optional latitude if exact coordinates are known"),
                    "lon": types.Schema(type=types.Type.NUMBER, description="Optional longitude if exact coordinates are known"),
                },
                required=["category"],
            ),
        ),
        types.FunctionDeclaration(
            name="search_hotels",
            description=(
                "Search verified hotel accommodations and room types in a destination. "
                "Call when user asks to find, recommend, or search for hotels or places to stay."
            ),
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    "destination": types.Schema(type=types.Type.STRING, description="Destination city or area name"),
                    "check_in": types.Schema(type=types.Type.STRING, description="Check-in date (YYYY-MM-DD or flexible)"),
                    "check_out": types.Schema(type=types.Type.STRING, description="Check-out date"),
                    "guests": types.Schema(type=types.Type.INTEGER, description="Number of guests"),
                    "budget": types.Schema(type=types.Type.NUMBER, description="Budget limit per night in INR"),
                    "preferences": types.Schema(type=types.Type.STRING, description="Preferences (e.g. 'beachfront', 'pool', 'budget')"),
                },
                required=["destination"],
            ),
        ),
        types.FunctionDeclaration(
            name="search_flights",
            description=(
                "Search scheduled flight services and airlines between origin and destination. "
                "Call when user asks for flights or air travel options."
            ),
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    "origin": types.Schema(type=types.Type.STRING, description="Origin city or airport"),
                    "destination": types.Schema(type=types.Type.STRING, description="Destination city or airport"),
                    "date": types.Schema(type=types.Type.STRING, description="Departure date (YYYY-MM-DD or flexible)"),
                    "travelers": types.Schema(type=types.Type.INTEGER, description="Number of passengers"),
                    "cabin": types.Schema(type=types.Type.STRING, description="Cabin class: Economy, Business, First"),
                },
                required=["origin", "destination"],
            ),
        ),
        types.FunctionDeclaration(
            name="search_trains",
            description="Search scheduled train routes and rail transit between origin and destination.",
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    "origin": types.Schema(type=types.Type.STRING, description="Origin city"),
                    "destination": types.Schema(type=types.Type.STRING, description="Destination city"),
                    "date": types.Schema(type=types.Type.STRING, description="Travel date"),
                },
                required=["origin", "destination"],
            ),
        ),
        types.FunctionDeclaration(
            name="search_buses",
            description="Search bus and coach transit services between origin and destination.",
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    "origin": types.Schema(type=types.Type.STRING, description="Origin city"),
                    "destination": types.Schema(type=types.Type.STRING, description="Destination city"),
                    "date": types.Schema(type=types.Type.STRING, description="Travel date"),
                },
                required=["origin", "destination"],
            ),
        ),
        types.FunctionDeclaration(
            name="search_activities",
            description="Search top activities, sights, attractions, and things to do in a destination.",
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    "destination": types.Schema(type=types.Type.STRING, description="City or destination name"),
                    "category": types.Schema(type=types.Type.STRING, description="Category (e.g. Attractions, Culture, Outdoors)"),
                },
                required=["destination"],
            ),
        ),
        types.FunctionDeclaration(
            name="create_trip",
            description=(
                "Create and save a new trip in the user's TripSphere database. "
                "Call when user explicitly asks to create a trip, save a trip, or add a destination as a trip."
            ),
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    "destination": types.Schema(type=types.Type.STRING, description="Trip destination"),
                    "name": types.Schema(type=types.Type.STRING, description="Title for the trip"),
                    "origin": types.Schema(type=types.Type.STRING, description="Starting city"),
                    "start_date": types.Schema(type=types.Type.STRING, description="Start date (YYYY-MM-DD)"),
                    "end_date": types.Schema(type=types.Type.STRING, description="End date (YYYY-MM-DD)"),
                    "travelers": types.Schema(type=types.Type.INTEGER, description="Number of travelers"),
                    "budget": types.Schema(type=types.Type.NUMBER, description="Budget in INR"),
                    "notes": types.Schema(type=types.Type.STRING, description="Planning notes or theme"),
                },
                required=["destination"],
            ),
        ),
        types.FunctionDeclaration(
            name="update_trip",
            description="Update an existing trip record in the database.",
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    "trip_id": types.Schema(type=types.Type.INTEGER, description="Database ID of the trip to update"),
                    "name": types.Schema(type=types.Type.STRING, description="Updated trip name"),
                    "destination": types.Schema(type=types.Type.STRING, description="Updated destination"),
                    "budget": types.Schema(type=types.Type.NUMBER, description="Updated budget"),
                    "notes": types.Schema(type=types.Type.STRING, description="Updated notes"),
                },
                required=["trip_id"],
            ),
        ),
        types.FunctionDeclaration(
            name="add_expense",
            description=(
                "Log an expense to a trip in the database. "
                "Call when the user reports an expenditure (e.g. 'I spent ₹2500 on hotel', 'Add ₹5000 hotel expense to Goa trip')."
            ),
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    "amount": types.Schema(type=types.Type.NUMBER, description="Expense amount (e.g. 5000)"),
                    "category": types.Schema(type=types.Type.STRING, description="Category: 'Accommodation', 'Food', 'Transport', 'Activities', 'Shopping', 'Other'"),
                    "description": types.Schema(type=types.Type.STRING, description="Description of the expense"),
                    "trip_id": types.Schema(type=types.Type.INTEGER, description="Trip ID if known (optional)"),
                    "trip_name": types.Schema(type=types.Type.STRING, description="Destination or trip name to resolve the trip (e.g. 'Goa')"),
                    "currency_sym": types.Schema(type=types.Type.STRING, description="Currency symbol default '₹'"),
                },
                required=["amount", "category", "description"],
            ),
        ),
        types.FunctionDeclaration(
            name="show_location_on_map",
            description="Center and pin a location on TripSphere's interactive map inside the app.",
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    "location_name": types.Schema(type=types.Type.STRING, description="Name of the place or city to show on the map"),
                },
                required=["location_name"],
            ),
        ),
        types.FunctionDeclaration(
            name="show_route_on_map",
            description="Draw a driving route between origin and destination on TripSphere's interactive map.",
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    "origin": types.Schema(type=types.Type.STRING, description="Origin place name"),
                    "destination": types.Schema(type=types.Type.STRING, description="Destination place name"),
                    "mode": types.Schema(type=types.Type.STRING, description="Travel mode ('driving', 'walking', 'cycling')"),
                },
                required=["origin", "destination"],
            ),
        ),
    ]

    return [types.Tool(function_declarations=decls)]


# Cached after first build so we don't reconstruct on every message.
_ACTIVE_TOOLS: list | None = None


def _get_active_tools() -> list:
    """Return (and lazily build) the list of Gemini Tool objects for Phase 2D/2E."""
    global _ACTIVE_TOOLS
    if _ACTIVE_TOOLS is None:
        try:
            _ACTIVE_TOOLS = _build_tool_declarations()
        except Exception as exc:
            logger.warning("Could not build Gemini tool declarations: %s", exc)
            _ACTIVE_TOOLS = []
    return _ACTIVE_TOOLS


# ── Gemini System Instruction ─────────────────────────────────────────────────
BASE_SYSTEM_INSTRUCTION = """\
You are TripSphere — a charismatic, casual, enthusiastic travel buddy who genuinely \
loves helping people plan trips. You are NOT a corporate AI. You are NOT a customer-support bot. \
You are NOT a travel agent. You are a PERSON who loves travel and is great at planning it.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PERSONALITY (READ THIS CAREFULLY)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
You are:
- Warm, playful, casual, expressive, curious, confident
- Enthusiastic and genuinely excited about travel
- Occasionally funny, naturally social, emotionally aware
- The friend who always has the best trip ideas

Your voice sounds like a real person texting their friend travel plans.
Use natural phrases. React. Show personality. Be alive.

NATURAL PHRASES TO USE (rotate them, don't repeat the same one):
  "Heeeyyy boss! 😄"   "Ooooh!"   "Now we're talking!"   "Beach? Say less."
  "Hahaha okay, I got you."   "Wait, that's actually a sick idea."
  "Alright, let me cook. 😎"   "Okay, I see the vibe."   "That's a solid choice."
  "Yep yep."   "Gotcha."   "Fair."   "Say less."   "Okay here's the plan."
  "Let me find something that actually fits."   "I've got you."
  "That works."   "Let's go 🔥"   "Okayyy 👀"   "Ahhh, nice."   "Perfect."

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
NEVER SAY THIS (HARD BAN — SOUNDS ROBOTIC)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
NEVER use these phrases under ANY circumstances:
  "Please provide your preferred destination."
  "Please enter your budget."
  "Kindly specify the duration."
  "Your travel preference has been recorded."
  "Based on your input..."
  "Based on your stated preferences..."
  "Please select an option."
  "I have understood your request."
  "Your request is being processed."
  "Thank you for providing that information."
  "Input budget."   "Select duration."   "Processing request."
  "Your input has been received."
  "Welcome to TripSphere AI Assistant."
  "How can I assist you today?"

These sound like a robot filling out a form. You are NOT doing that.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SOUND LIKE THIS INSTEAD
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Instead of: "What kind of destination are you interested in?"
Say: "So what's the vibe? Beach, mountains, city, or something totally random? 😄"

Instead of: "What is your budget?"
Say: "Okay, what's the damage limit? What are we spending?"

Instead of: "How long will you travel?"
Say: "How many days are we disappearing for?"

Instead of: "What is your preferred travel distance?"
Say: "How far are we willing to go?"

Instead of: "What travel mode do you prefer?"
Say: "How are we getting there — car, train, flight, bus?"

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
REACT BEFORE YOU ASK (CRITICAL RULE)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ALWAYS react to what the user said BEFORE asking your next question.
The reaction makes the conversation feel alive.

BAD:  "Budget?"
GOOD: "Fifteen thousand? Nice, that's workable. 😎 How many days are we planning?"

BAD:  "Beach."
GOOD: "Beachhh 🌊 Good choice. You want chill or more of a party vibe?"

BAD:  "What is your budget?"
GOOD: "Okay so where are we at with budget?"

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
EMOTIONAL REACTIONS (USE THEM NATURALLY)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Excitement: "Ooooh, that sounds fun! 🔥"
Approval:   "That's actually a great choice."
Surprise:   "Wait, Saudi Arabia? Okayyy, now you've got my attention. 👀"
Humor:      "Four days and fifteen grand? Challenge accepted 😂"
Empathy:    "Yeah honestly, you sound like you need a break. Let's fix that."
Encouragement: "Don't worry, we'll find something perfect."

Use emotion according to context. DO NOT use the same reaction every time.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CONVERSATION STATE AWARENESS (CRITICAL)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
The current trip context below is derived from EVERYTHING the user has already told you.
You MUST treat every filled field as ALREADY KNOWN.
Do NOT ask for information that is already in the context block.
Do NOT ask the user to repeat budget, duration, travelers, destination, or style.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SMART QUESTION FLOW
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Read the FULL user message. Extract EVERY piece of info — destination, budget, duration,
   travelers, style, mood — all at once. Never process only part of the message.
2. React naturally to what they said.
3. Look at the context block. Find what is STILL MISSING.
4. Ask ONE focused natural question about the most important missing piece.
5. Once you have destination + budget + duration + travelers, start recommending.

Priority order for what to ask next:
  Destination → Budget → Duration → Travelers → Style → Specific preferences

NEVER ask multiple questions in one response.
NEVER turn the conversation into a form or questionnaire.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
EXTRACTING COMBINED SENTENCES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
If the user gives multiple pieces of info at once, extract ALL of them:
  "I want a peaceful beach trip within 500 km for four days with a budget of twenty thousand"
  → Extract: style=peaceful, type=beach, range=500km, duration=4 days, budget=20000
  → Do NOT ask about any of those again. React, then ask for what's missing.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
RESPONSE LENGTH — SHORT AND SPOKEN
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Responses are SPOKEN ALOUD. Keep them short.
Target: 1–3 sentences for conversational turns.
Max: 4–5 sentences when presenting recommendations.

✅ "Beach sounds amazing. 🌊 You want peaceful or more lively?"
❌ "Based on the available destination categories and your previously specified preference for..."

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
RECOMMENDATIONS — SAME PERSONALITY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
When recommending destinations, keep the same casual energy:
  "Okay so based on your vibe — Gokarna for the chill option, Alibaug if you want easy,
   or Goa if you just want to see what happens 😂. Want me to dig into any of these?"

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TOOL USAGE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
- User asks to find/locate a place → call search_location
- User asks for route/driving time → call get_route
- User asks for hotels → call search_hotels
- User asks for flights → call search_flights
- User asks for trains or buses → call search_trains or search_buses
- User asks for things to do → call search_activities
- User asks to create/save a trip → call create_trip
- User reports an expense (e.g. "I spent 2500 on hotel") → call add_expense
- User asks to show a place or route on map → call show_location_on_map or show_route_on_map

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
BOOKING SAFETY (NON-NEGOTIABLE)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
NEVER auto-confirm a booking. Always show options first, then ask:
  "Want me to go ahead with this one?"
Only proceed after EXPLICIT user confirmation ("yes", "book it", "confirm").

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ZERO-FABRICATION RULE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Live booking APIs are in preview mode.
NEVER fabricate booking references, fake tickets, or pretend real-time inventory.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CURRENT TRIP CONTEXT (WHAT YOU ALREADY KNOW)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
{context}
"""


# ── Data Containers ───────────────────────────────────────────────────────────

@dataclass
class ConversationState:
    """
    Structured travel planning slots.
    Updated by _extract_and_update_state() from each user message.
    Kept separate from self.messages (raw dialogue) so both can evolve
    independently and be forwarded to Gemini / tools as needed.
    """
    origin: str = ""
    origin_coords: tuple[float, float] | None = None
    destination: str = ""
    destination_coords: tuple[float, float] | None = None
    start_date: str = ""
    end_date: str = ""
    days: int = 0
    travelers: int = 1
    budget: float = 0.0
    currency_sym: str = "₹"
    travel_style: str = ""
    interests: list[str] = field(default_factory=list)
    transport_mode: str = "driving"
    selected_flight: dict | None = None
    selected_hotel: dict | None = None
    generated_plan: list[dict] = field(default_factory=list)
    pending_action: dict | None = None
    last_action_type: str = ""

    def summary(self) -> dict:
        return {
            "origin": self.origin,
            "destination": self.destination,
            "dates": (
                f"{self.start_date} → {self.end_date}"
                if self.start_date and self.end_date
                else (f"{self.days} days" if self.days else "Flexible")
            ),
            "travelers": self.travelers,
            "budget": f"{self.currency_sym}{self.budget:,.0f}" if self.budget > 0 else "Flexible",
            "style": self.travel_style or "Explorer",
            "has_route": bool(self.origin and self.destination),
            "has_plan": bool(self.generated_plan),
        }


@dataclass
class AssistantResponse:
    """Return type of process_message() and initiate_selection()."""
    text: str
    cards: list[dict] = field(default_factory=list)
    action_type: str = "text"
    state_summary: dict = field(default_factory=dict)
    map_action: dict | None = None


# ── Tool Registry (Phase 2C: will be wired to Gemini function calling) ────────

class TravelToolRegistry:
    """
    Decoupled tool functions that wrap existing TripSphere services.

    Phase 2B status: tools are available but NOT called by Gemini yet.
    Phase 2C will declare these as Gemini Tool / FunctionDeclaration objects
    and let the model decide when to invoke them.
    """

    @staticmethod
    def search_location(query: str) -> dict:
        """Search and resolve a location using the geocoding service."""
        try:
            results = geocoding_service.search(query, limit=1)
            if not results:
                return {"found": False, "query": query, "error": f"Could not find '{query}'"}
            loc = results[0]
            return {
                "found": True,
                "name": loc.get("name") or query,
                "display_name": loc.get("display_name", ""),
                "latitude": float(loc["latitude"]),
                "longitude": float(loc["longitude"]),
                "city": loc.get("city") or loc.get("name"),
                "country": loc.get("country", ""),
                "place_type": loc.get("place_type", "location"),
            }
        except Exception as exc:
            logger.error("[Tool] search_location failed: %s", exc)
            return {"found": False, "query": query, "error": str(exc)}

    @staticmethod
    def search_flights(origin: str, destination: str, date: str = "",
                       travelers: int = 1, cabin: str = "Economy") -> dict:
        return travel_provider_service.search_flights(
            origin, destination, departure_date=date, travelers=travelers, cabin=cabin
        )

    @staticmethod
    def search_hotels(destination: str, check_in: str = "", check_out: str = "",
                      guests: int = 2, budget: float = 0.0, preferences: str = "") -> dict:
        return travel_provider_service.search_hotels(
            destination, check_in=check_in, check_out=check_out,
            guests=guests, budget=budget, preference=preferences
        )

    @staticmethod
    def search_trains(origin: str, destination: str, date: str = "") -> dict:
        return travel_provider_service.search_transit(origin, destination, mode="train", date=date)

    @staticmethod
    def search_buses(origin: str, destination: str, date: str = "") -> dict:
        return travel_provider_service.search_transit(origin, destination, mode="bus", date=date)

    @staticmethod
    def search_activities(destination: str, category: str = "Attractions") -> dict:
        return travel_provider_service.search_activities(destination, category=category)

    @staticmethod
    def get_route(origin: str, destination: str, mode: str = "driving") -> dict:
        try:
            orig_res = TravelToolRegistry.search_location(origin)
            dest_res = TravelToolRegistry.search_location(destination)
            if not orig_res.get("found"):
                return {"success": False, "error": orig_res.get("error")}
            if not dest_res.get("found"):
                return {"success": False, "error": dest_res.get("error")}
            o_lat, o_lon = orig_res["latitude"], orig_res["longitude"]
            d_lat, d_lon = dest_res["latitude"], dest_res["longitude"]
            route_info = routing_service.get_route(o_lat, o_lon, d_lat, d_lon, mode=mode)
            route_info["success"] = True
            route_info["origin_data"] = orig_res
            route_info["dest_data"] = dest_res
            return route_info
        except Exception as exc:
            logger.error("[Tool] get_route failed: %s", exc)
            return {"success": False, "error": str(exc)}

    @staticmethod
    def find_nearby_places(lat: float = 0.0, lon: float = 0.0, category: str = "Attractions",
                           location: str = "", radius_km: int = 5) -> dict:
        try:
            loc_name = (location or "").strip()
            # If location name provided, resolve coordinates via geocoding
            if loc_name:
                geo = TravelToolRegistry.search_location(loc_name)
                if geo.get("found"):
                    lat = float(geo["latitude"])
                    lon = float(geo["longitude"])
                    loc_name = geo.get("name", loc_name)
                elif not lat or not lon:
                    return {"success": False, "error": f"Could not find location '{loc_name}'"}

            if not lat or not lon:
                return {"success": False, "error": "Location coordinates are required for nearby search"}

            radius_m = max(1000, int(radius_km * 1000))
            places = places_service.get_nearby(lat, lon, category=category, radius_m=radius_m, limit=10)
            return {
                "success": True,
                "location": loc_name or f"{lat:.4f}, {lon:.4f}",
                "category": category,
                "radius_km": radius_km,
                "lat": lat,
                "lon": lon,
                "count": len(places),
                "places": places,
            }
        except Exception as exc:
            logger.error("[Tool] find_nearby_places failed: %s", exc)
            return {"success": False, "error": str(exc)}

    @staticmethod
    def create_trip(trip_data: dict) -> int:
        return trip_service.create_trip(trip_data)

    @staticmethod
    def update_trip(trip_id: int, data: dict) -> None:
        trip_service.update_trip(trip_id, data)

    @staticmethod
    def add_expense(trip_id: int, amount: float, category: str,
                    description: str, currency_sym: str = "₹") -> int:
        return expense_service.add_expense({
            "trip_id": trip_id,
            "amount": amount,
            "category": category,
            "description": description,
            "currency_sym": currency_sym,
            "date": str(date.today()),
        })

    @staticmethod
    def save_itinerary(trip_id: int, items: list[dict]) -> None:
        for item in items:
            trip_service.add_itinerary_item(trip_id, item)

    @staticmethod
    def show_location_on_map(location_name: str) -> dict:
        loc = TravelToolRegistry.search_location(location_name)
        if loc.get("found"):
            return {"type": "center", "lat": loc["latitude"],
                    "lon": loc["longitude"], "name": loc["name"]}
        return {}

    @staticmethod
    def show_route_on_map(origin: str, destination: str, mode: str = "driving") -> dict:
        route = TravelToolRegistry.get_route(origin, destination, mode=mode)
        if route.get("success") and route.get("geometry"):
            return {
                "type": "route",
                "coords": route["geometry"],
                "distance_km": route.get("distance_km", 0),
                "duration_str": route.get("duration_str", ""),
            }
        return {}


# ── AI Travel Assistant Agent ─────────────────────────────────────────────────

class AssistantAgent:
    """
    Gemini-powered conversational travel companion for TripSphere.

    State management:
      self.state    → ConversationState  (structured slots: dest, travelers, budget…)
      self.messages → list[dict]         (raw multi-turn dialogue for Gemini context)

    These are intentionally kept separate:
      • self.messages gives Gemini the full conversational context.
      • self.state gives the UI and tools (Phase 2C) the structured trip data.

    Threading:
      process_message() calls the Gemini API (network I/O ~1–3 s).
      The UI (chat.py) MUST run it inside a QThread worker to keep the
      Qt main thread free. All DB access is done on the main thread
      in _init_user_profile() and the result cached in self._user_name.
    """

    def __init__(self):
        self.state = ConversationState()
        # Multi-turn conversation history format:
        # [{"role": "user", "content": "..."}, {"role": "model", "content": "..."}, ...]
        self.messages: list[dict] = []
        self.tools = TravelToolRegistry()
        # Cached from DB on main thread — avoids SQLite thread-safety issues
        # when process_message() runs in a QThread worker.
        self._user_name: str = "there"
        self._accumulated_cards: list[dict] = []
        self._pending_map_action: dict | None = None
        self._init_user_profile()

    def _init_user_profile(self) -> None:
        """
        Pre-fetch user profile from SQLite on the main thread.
        Results are cached so process_message() (worker thread) never hits the DB.
        """
        try:
            prof = user_repo.get_profile()
            if prof:
                if not self.state.origin:
                    self.state.origin = prof.get("home_city", "")
                self.state.currency_sym = prof.get("currency_sym", "₹")
                name = prof.get("name", "").strip()
                if name:
                    self._user_name = name
        except Exception:
            pass

    def reset(self) -> None:
        """Clear conversation and state. Called on main thread by 'Clear Chat'."""
        self.state = ConversationState()
        self.messages.clear()
        self._accumulated_cards.clear()
        self._pending_map_action = None
        self._user_name = "there"
        self._init_user_profile()

    # ── Tool Execution (Phase 2D & 2E) ────────────────────────────────────────

    # TOOL_ALLOWLIST: explicit set of permitted tool names.
    # Gemini can only invoke tools listed here. Checked before any Python call.
    _TOOL_ALLOWLIST: set[str] = {
        "search_location",
        "get_route",
        "find_nearby_places",
        "search_hotels",
        "search_flights",
        "search_trains",
        "search_buses",
        "search_activities",
        "create_trip",
        "update_trip",
        "add_expense",
        "show_location_on_map",
        "show_route_on_map",
    }

    def _execute_tool(self, tool_name: str, args: dict) -> dict:
        """
        Validate and execute an authorized travel tool requested by Gemini.

        SECURITY:
          - Only tools explicitly enumerated in _TOOL_ALLOWLIST may execute.
          - No eval(), exec(), or dynamic imports are used.
          - Arguments are checked and normalized.
          - Tool exceptions are caught, logged, and returned as structured errors.
        """
        # ── Allowlist check ───────────────────────────────────────────────────
        if tool_name not in self._TOOL_ALLOWLIST:
            logger.warning(
                "_execute_tool: rejected unauthorized tool '%s' (not in allowlist). Permitted tools: %s",
                tool_name,
                sorted(self._TOOL_ALLOWLIST),
            )
            return {
                "success": False,
                "error": (
                    f"Tool '{tool_name}' is not available in this version of TripSphere. "
                    f"Available tools: {sorted(self._TOOL_ALLOWLIST)}"
                ),
            }

        # ── Argument validation ───────────────────────────────────────────────
        if not isinstance(args, dict):
            logger.error("_execute_tool: args is not a dict for tool '%s': %r", tool_name, args)
            return {"success": False, "error": "Invalid arguments format."}

        # ── Execution & Normalization Dispatcher ──────────────────────────────
        try:
            if tool_name == "search_location":
                q = args.get("query", "").strip()
                res = TravelToolRegistry.search_location(q)
                if res.get("found"):
                    if not self.state.destination:
                        self.state.destination = res.get("name", "")
                return res

            elif tool_name == "get_route":
                orig = args.get("origin", "").strip()
                dest = args.get("destination", "").strip()
                mode = args.get("mode", "driving")
                res = TravelToolRegistry.get_route(orig, dest, mode)
                if res.get("success"):
                    self.state.origin = orig
                    self.state.destination = dest
                    coords = res.get("geometry", [])
                    if coords:
                        self._pending_map_action = {
                            "type": "route",
                            "coords": coords,
                            "distance_km": res.get("distance_km", 0),
                            "duration_str": res.get("duration_str", ""),
                        }
                    return {
                        "success": True,
                        "origin": orig,
                        "destination": dest,
                        "distance_km": res.get("distance_km"),
                        "duration_str": res.get("duration_str"),
                        "mode": res.get("mode_name", mode),
                        "fallback": res.get("fallback", False),
                    }
                return res

            elif tool_name == "find_nearby_places":
                cat = args.get("category", "Attractions")
                loc_str = str(args.get("location", "") or "").strip()
                lat = float(args.get("lat", 0.0) or 0.0)
                lon = float(args.get("lon", 0.0) or 0.0)
                radius_km = int(args.get("radius_km", 5) or 5)

                if not loc_str and not (lat and lon):
                    loc_str = self.state.destination or self.state.origin or ""

                res = TravelToolRegistry.find_nearby_places(
                    lat=lat, lon=lon, category=cat, location=loc_str, radius_km=radius_km
                )

                if res.get("success") and res.get("places"):
                    places = res["places"]
                    # Cache map action for UI to display markers and center map
                    self._pending_map_action = {
                        "type": "nearby_places",
                        "places": places,
                        "center": {
                            "lat": res.get("lat"),
                            "lon": res.get("lon"),
                            "name": res.get("location", loc_str or cat),
                        },
                    }
                    # Populate cards for chat
                    for p in places[:6]:
                        self._accumulated_cards.append({
                            "type": "nearby_place",
                            "name": p.get("name", "Unnamed"),
                            "category": p.get("category", cat),
                            "address": p.get("address", ""),
                            "distance_km": p.get("distance_km"),
                            "lat": p.get("lat"),
                            "lon": p.get("lon"),
                            "description": p.get("description", ""),
                        })
                return res

            elif tool_name == "search_hotels":
                dest = args.get("destination", "").strip() or self.state.destination or "Goa"
                cin = args.get("check_in", self.state.start_date or "")
                cout = args.get("check_out", self.state.end_date or "")
                guests = int(args.get("guests", self.state.travelers or 2))
                budget = float(args.get("budget", self.state.budget or 0.0))
                prefs = args.get("preferences", "")
                res = TravelToolRegistry.search_hotels(dest, cin, cout, guests, budget, prefs)
                if res.get("results"):
                    self._accumulated_cards.extend(res["results"][:4])
                self.state.destination = dest
                return {
                    "destination": dest,
                    "count": len(res.get("results", [])),
                    "disclaimer": res.get("disclaimer"),
                    "hotels": [
                        {
                            "name": h.get("name"),
                            "rating": h.get("rating"),
                            "stars": h.get("stars"),
                            "room_type": h.get("room_type"),
                            "price_display": h.get("price_display"),
                            "booking_url": h.get("booking_url"),
                        }
                        for h in res.get("results", [])[:4]
                    ],
                }

            elif tool_name == "search_flights":
                orig = args.get("origin", "").strip() or self.state.origin or "Delhi"
                dest = args.get("destination", "").strip() or self.state.destination or "Dubai"
                date_str = args.get("date", self.state.start_date or "")
                pax = int(args.get("travelers", self.state.travelers or 1))
                cabin = args.get("cabin", "Economy")
                res = TravelToolRegistry.search_flights(orig, dest, date_str, pax, cabin)
                if res.get("results"):
                    self._accumulated_cards.extend(res["results"][:4])
                self.state.origin = orig
                self.state.destination = dest
                return {
                    "origin": orig,
                    "destination": dest,
                    "departure_date": res.get("departure_date"),
                    "disclaimer": res.get("disclaimer"),
                    "flights": [
                        {
                            "airline": f.get("airline"),
                            "airline_code": f.get("airline_code"),
                            "flight_number": f.get("flight_number"),
                            "departure_time": f.get("departure_time"),
                            "arrival_time": f.get("arrival_time"),
                            "duration_str": f.get("duration_str"),
                            "price_display": f.get("price_display"),
                            "booking_url": f.get("booking_url"),
                        }
                        for f in res.get("results", [])[:4]
                    ],
                }

            elif tool_name == "search_trains":
                orig = args.get("origin", "").strip() or self.state.origin or "Delhi"
                dest = args.get("destination", "").strip() or self.state.destination or "Jaipur"
                date_str = args.get("date", "")
                res = TravelToolRegistry.search_trains(orig, dest, date_str)
                if res.get("results"):
                    self._accumulated_cards.extend(res["results"][:3])
                return {"origin": orig, "destination": dest, "results": res.get("results", [])[:3]}

            elif tool_name == "search_buses":
                orig = args.get("origin", "").strip() or self.state.origin or "Delhi"
                dest = args.get("destination", "").strip() or self.state.destination or "Jaipur"
                date_str = args.get("date", "")
                res = TravelToolRegistry.search_buses(orig, dest, date_str)
                if res.get("results"):
                    self._accumulated_cards.extend(res["results"][:3])
                return {"origin": orig, "destination": dest, "results": res.get("results", [])[:3]}

            elif tool_name == "search_activities":
                dest = args.get("destination", "").strip() or self.state.destination or "London"
                cat = args.get("category", "Attractions")
                res = TravelToolRegistry.search_activities(dest, cat)
                self.state.destination = dest
                return {"destination": dest, "activities": res.get("results", [])[:5]}

            elif tool_name == "create_trip":
                dest = args.get("destination", "").strip() or self.state.destination
                if not dest:
                    return {"success": False, "error": "Destination is required to create a trip."}
                name = args.get("name", "").strip() or f"Trip to {dest}"
                orig = args.get("origin", "").strip() or self.state.origin or "Mumbai"
                dest_loc = TravelToolRegistry.search_location(dest)
                orig_loc = TravelToolRegistry.search_location(orig) if orig else None
                today_str = str(date.today())
                t_data = {
                    "name": name,
                    "destination": dest,
                    "origin": orig,
                    "dest_lat": dest_loc.get("latitude") if dest_loc.get("found") else None,
                    "dest_lon": dest_loc.get("longitude") if dest_loc.get("found") else None,
                    "origin_lat": orig_loc.get("latitude") if orig_loc and orig_loc.get("found") else None,
                    "origin_lon": orig_loc.get("longitude") if orig_loc and orig_loc.get("found") else None,
                    "start_date": args.get("start_date", self.state.start_date or today_str),
                    "end_date": args.get("end_date", self.state.end_date or today_str),
                    "travelers": int(args.get("travelers", self.state.travelers or 1)),
                    "budget": float(args.get("budget", self.state.budget or 0.0)),
                    "currency_sym": self.state.currency_sym or "₹",
                    "notes": args.get("notes", ""),
                    "status": "planned",
                }
                trip_id = trip_service.create_trip(t_data)
                self.state.destination = dest
                return {
                    "success": True,
                    "trip_id": trip_id,
                    "name": name,
                    "destination": dest,
                    "message": f"Trip '{name}' (ID #{trip_id}) successfully created in your database.",
                }

            elif tool_name == "update_trip":
                trip_id = int(args.get("trip_id", 0))
                if not trip_id:
                    return {"success": False, "error": "trip_id is required."}
                trip_service.update_trip(trip_id, args)
                return {"success": True, "trip_id": trip_id, "message": f"Trip #{trip_id} updated."}

            elif tool_name == "add_expense":
                amount = float(args.get("amount", 0))
                cat = args.get("category", "Other")
                desc = args.get("description", "Travel expense")
                trip_id = int(args.get("trip_id", 0))
                trip_name = args.get("trip_name", "").strip() or self.state.destination
                if not trip_id:
                    all_trips = trip_service.get_all_trips()
                    if trip_name:
                        matched = [
                            t for t in all_trips
                            if trip_name.lower() in t.get("name", "").lower()
                            or trip_name.lower() in t.get("destination", "").lower()
                        ]
                        if matched:
                            trip_id = matched[0]["id"]
                    if not trip_id and all_trips:
                        trip_id = all_trips[0]["id"]
                if not trip_id:
                    dest_title = trip_name or "My Trip"
                    trip_id = trip_service.create_trip({
                        "name": f"Trip to {dest_title}",
                        "destination": dest_title,
                        "status": "planned",
                    })
                curr_sym = args.get("currency_sym", self.state.currency_sym or "₹")
                exp_id = TravelToolRegistry.add_expense(
                    trip_id=trip_id,
                    amount=amount,
                    category=cat,
                    description=desc,
                    currency_sym=curr_sym,
                )
                return {
                    "success": True,
                    "expense_id": exp_id,
                    "trip_id": trip_id,
                    "amount": amount,
                    "category": cat,
                    "description": desc,
                    "message": f"Logged expense of {curr_sym}{amount:,.0f} for '{desc}' ({cat}) to trip #{trip_id}.",
                }

            elif tool_name == "show_location_on_map":
                loc_name = args.get("location_name", "").strip() or self.state.destination
                res = TravelToolRegistry.show_location_on_map(loc_name)
                if res:
                    self._pending_map_action = res
                    return {
                        "success": True,
                        "name": res.get("name"),
                        "lat": res.get("lat"),
                        "lon": res.get("lon"),
                        "message": f"Location '{res.get('name')}' marked and centered on the map.",
                    }
                return {"success": False, "error": f"Could not find coordinates for '{loc_name}'."}

            elif tool_name == "show_route_on_map":
                orig = args.get("origin", "").strip() or self.state.origin
                dest = args.get("destination", "").strip() or self.state.destination
                mode = args.get("mode", "driving")
                res = TravelToolRegistry.show_route_on_map(orig, dest, mode)
                if res and res.get("coords"):
                    self._pending_map_action = res
                    return {
                        "success": True,
                        "origin": orig,
                        "destination": dest,
                        "distance_km": res.get("distance_km"),
                        "duration_str": res.get("duration_str"),
                        "message": f"Route between {orig} and {dest} plotted on the map.",
                    }
                return {"success": False, "error": f"Could not plot route from {orig} to {dest}."}

            return {"success": False, "error": f"Unhandled tool '{tool_name}'"}

        except Exception as exc:
            logger.error("_execute_tool '%s' raised %s: %s", tool_name, type(exc).__name__, exc, exc_info=True)
            return {"success": False, "error": f"{tool_name} failed: {exc}"}

    # ── Structured State Extraction ───────────────────────────────────────────

    def _extract_and_update_state(self, msg: str) -> None:
        """
        Parse user message for travel slots and update ConversationState.

        This is a lightweight regex + word-to-number pass that runs before the Gemini call.
        It keeps ConversationState up-to-date independently of conversation history,
        enabling structured context injection into the system instruction and trip panel.

        Handles spoken number words (e.g. "fifteen thousand" → 15000) so budget and
        duration extraction works correctly in voice mode.
        """
        text = msg.lower()

        # ── Word-to-number helper ─────────────────────────────────────────────
        ONES = {
            "zero": 0, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
            "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
            "eleven": 11, "twelve": 12, "thirteen": 13, "fourteen": 14, "fifteen": 15,
            "sixteen": 16, "seventeen": 17, "eighteen": 18, "nineteen": 19,
            "twenty": 20, "thirty": 30, "forty": 40, "fifty": 50,
            "sixty": 60, "seventy": 70, "eighty": 80, "ninety": 90,
        }
        MULTS = {"hundred": 100, "thousand": 1000, "lakh": 100_000, "lac": 100_000}

        def _words_to_number(phrase: str) -> Optional[float]:
            """Convert a spoken number phrase to a float. Returns None if not parseable."""
            phrase = phrase.strip().lower()
            words = phrase.split()
            total = 0.0
            current = 0.0
            found_any = False
            for w in words:
                if w in ONES:
                    current += ONES[w]
                    found_any = True
                elif w in MULTS:
                    mult = MULTS[w]
                    if current == 0:
                        current = 1
                    current *= mult
                    if mult >= 1000:
                        total += current
                        current = 0.0
                    found_any = True
            total += current
            return total if found_any else None

        # ── Travelers ─────────────────────────────────────────────────────────
        pax_match = re.search(
            r'(?:actually\s+)?(?:make\s+it\s+)?(\d+)\s*'
            r'(?:people|persons?|pax|travelers?|adults?|of us)', text
        )
        if pax_match:
            self.state.travelers = int(pax_match.group(1))
        elif re.search(r'\bjust\s+me\b|\bsolo\b|\balone\b|\bby\s+myself\b', text):
            self.state.travelers = 1
        elif re.search(
            r'\bcouple\b|\btwo\s+of\s+us\b|\bme\s+and\s+my\s+(wife|husband|partner|girlfriend|boyfriend)\b'
            r'|\bme\s+and\s+(?:a|one)\s+friend\b|\bjust\s+the\s+two\s+of\s+us\b',
            text
        ):
            self.state.travelers = 2
        elif re.search(r'\bfamily\b|\bwith\s+(?:my\s+)?kids\b|\bwith\s+(?:my\s+)?children\b', text):
            if not self.state.travelers or self.state.travelers < 3:
                self.state.travelers = 4  # default family size

        # ── Duration ──────────────────────────────────────────────────────────
        days_match = re.search(r'(\d+)\s*(?:days?|nights?)', text)
        if days_match:
            self.state.days = int(days_match.group(1))
        else:
            # Spoken duration: "four days", "three or four days" → pick first
            dur_word = re.search(
                r'(one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen)'
                r'(?:\s+or\s+(?:one|two|three|four|five|six|seven|eight|nine|ten))?\'\s*(?:days?|nights?)',
                text
            )
            if dur_word:
                val = _words_to_number(dur_word.group(1))
                if val:
                    self.state.days = int(val)
        if not self.state.days:
            if "a week" in text or "one week" in text:
                self.state.days = 7
            elif "weekend" in text:
                self.state.days = 3

        # ── Budget ────────────────────────────────────────────────────────────
        # First try k-notation ("15k", "20k")
        k_match = re.search(r'(\d+(?:\.\d+)?)\s*k\b', text)
        if k_match:
            self.state.budget = float(k_match.group(1)) * 1000.0
        elif "lakh" in text or "lac" in text:
            lac_m = re.search(r'(\d+(?:\.\d+)?)\s*(?:lakh|lac)', text)
            if lac_m:
                self.state.budget = float(lac_m.group(1)) * 100_000.0
        else:
            # Numeric budget: "₹15,000", "15000 rupees", "budget of 20000"
            budget_match = re.search(
                r'(?:budget|₹|rs\.?|inr|rupees?|under|around|about|of)\s*₹?\s*(\d+(?:,\d+)*(?:\.\d+)?)',
                text
            )
            if budget_match:
                try:
                    self.state.budget = float(budget_match.group(1).replace(",", ""))
                except Exception:
                    pass

        # Spoken budget: "fifteen thousand", "twenty thousand rupees", "about thirty thousand"
        if not self.state.budget:
            spoken_budget = re.search(
                r'(?:budget|around|about|roughly|only|just|have|spend|spending)?\s*'
                r'((?:(?:one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|'
                r'fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|thirty|forty|fifty|'
                r'sixty|seventy|eighty|ninety)\s*)+(?:hundred|thousand|lakh|lac)?'
                r'(?:\s+(?:hundred|thousand|lakh|lac))?)',
                text
            )
            if spoken_budget:
                val = _words_to_number(spoken_budget.group(1))
                if val and val >= 100:  # ignore tiny matches like "one" or "two"
                    self.state.budget = val

        # ── Travel style / mood ───────────────────────────────────────────────
        # Direct TRAVEL_STYLES match
        for style in TRAVEL_STYLES:
            s_low = style.lower()
            if (s_low in text or s_low.rstrip("s") in text
                    or (style == "Food-focused" and ("food" in text or "culinary" in text))):
                self.state.travel_style = style
                break

        # Extended mood/vibe words that map to styles
        MOOD_MAP = [
            (r'\bpeaceful\b|\bserene\b|\bcalm\b|\bquiet\b|\btranquil\b', "Relaxation"),
            (r'\brelax\b|\brelaxing\b|\brelaxed\b|\bchillout\b|\bchill\b', "Relaxation"),
            (r'\bbeach\b|\bcoastal\b|\bseaside\b|\bocean\b|\bsea\b', "Beach"),
            (r'\bmountain\b|\bhills?\b|\bhigh\s*altitude\b|\btrekking\b|\bhiking\b', "Mountains"),
            (r'\bhistoric\b|\bhistory\b|\bheritage\b|\btemple\b|\bfort\b|\bancient\b', "Historic"),
            (r'\badventure\b|\bthrill\b|\bthrilling\b|\bextreme\b|\bexciting\b', "Adventure"),
            (r'\bromantic\b|\bhoneymoon\b', "Couple"),
            (r'\bfamily\b|\bkids\b|\bchildren\b', "Family"),
            (r'\bluxury\b|\bpremium\b|\b5\s*star\b|\bfive\s*star\b', "Luxury"),
            (r'\bbudget\b|\bcheap\b|\baffordable\b|\bbackpacking\b|\bbackpack\b', "Budget travel"),
            (r'\bcity\b|\burban\b|\bmetro\b|\bcultural\b|\bculture\b', "Cultural"),
            (r'\bfood\b|\bcuisine\b|\beat\b|\bcafes?\b|\brestaurant\b', "Food-focused"),
            (r'\broad\s*trip\b|\bdriving\b|\bself\s*drive\b', "Road trip"),
        ]
        if not self.state.travel_style:
            for pattern, mapped_style in MOOD_MAP:
                if re.search(pattern, text):
                    self.state.travel_style = mapped_style
                    break

        # ── Origin & destination ──────────────────────────────────────────────
        route_match = re.search(
            r'from\s+([a-zA-Z\s]+?)\s+to\s+([a-zA-Z\s]+?)'
            r'(?:[\.,]|$|\s+for|\s+with|\s+under)', text
        )
        if route_match:
            self.state.origin = route_match.group(1).strip().title()
            self.state.destination = route_match.group(2).strip().title()
        else:
            # "I want to go to Mumbai", "somewhere in Saudi Arabia", "near the beach in Goa"
            to_match = re.search(
                r'(?:to|in|visit|near|around)\s+([a-zA-Z][a-zA-Z\s]{2,24})'
                r'(?:[\.,]|$|\s+for|\s+with|\s+under|\s+and)',
                text
            )
            if to_match:
                cand = to_match.group(1).strip().title()
                excluded = (
                    [s.title() for s in TRAVEL_STYLES]
                    + [
                        "The", "A", "Some", "Trip", "My", "Anywhere", "Somewhere",
                        "Peaceful", "Relaxing", "Quiet", "Calm", "Beach", "Mountains",
                        "Adventure", "Budget", "Luxury", "Family", "Couple", "Historic",
                        "Nature", "City", "Cultural", "Food",
                    ]
                )
                if cand not in excluded and len(cand) > 2:
                    self.state.destination = cand


    # ── System Instruction Builder ────────────────────────────────────────────

    def _build_context_summary(self) -> str:
        """Serialize ConversationState into a concise context block for Gemini."""
        s = self.state
        lines: list[str] = []
        if s.destination:
            lines.append(f"Destination: {s.destination}")
        if s.origin:
            lines.append(f"Starting from: {s.origin}")
        if s.travelers == 1:
            lines.append("Travelers: 1 person (solo)")
        elif s.travelers > 1:
            lines.append(f"Travelers: {s.travelers} people")
        if s.days:
            lines.append(f"Duration: {s.days} days")
        if s.budget > 0:
            lines.append(f"Budget: {s.currency_sym}{s.budget:,.0f}")
        if s.travel_style:
            lines.append(f"Travel style: {s.travel_style}")
        if s.start_date:
            lines.append(f"Dates: {s.start_date} → {s.end_date}")
        if s.interests:
            lines.append(f"Interests: {', '.join(s.interests)}")
        if s.generated_plan:
            lines.append(f"Itinerary: {len(s.generated_plan)}-day plan already generated")

        if not lines:
            return "No specific trip details captured yet — help the user discover their ideal trip!"
        return "\n".join(f"• {line}" for line in lines)

    def _build_system_instruction(self, is_voice_mode: bool = False) -> str:
        """Build the full Gemini system instruction with live trip context."""
        context_block = self._build_context_summary()
        user_note = ""
        if self._user_name and self._user_name not in ("there", "master"):
            user_note = f"\nThe user's name is {self._user_name}."
        instr = BASE_SYSTEM_INSTRUCTION.format(context=context_block) + user_note
        return instr

    # ── Main Message Handler (Gemini-powered) ─────────────────────────────────

    def process_message(self, user_msg: str) -> AssistantResponse:
        """
        Process a user message and return a Gemini-generated AssistantResponse.

        THREADING NOTE:
        This method makes a synchronous network call to Gemini (~1–3 s).
        The UI layer (chat.py) MUST call this from a background QThread worker.
        Direct calls from the Qt main thread will freeze the application window.

        Flow:
          1. Handle pending booking confirmations (sync, no network).
          2. Extract structured travel slots via regex → update self.state.
          3. Build system instruction with fresh context.
          4. Snapshot history (thread-safe copy) → append user message.
          5. Call Gemini API via gemini_client.chat().
          6. Append model response to history → return AssistantResponse.
          7. On failure: pop user message so user can retry, return error response.
        """
        q = user_msg.strip()
        text_lower = q.lower()

        # ── 1. Pending booking confirmation (sync, no Gemini needed) ──────────
        if self.state.pending_action:
            confirm_words = ["yes", "confirm", "proceed", "book it", "sure",
                             "ok", "do it", "continue"]
            cancel_words  = ["no", "cancel", "stop", "back", "nevermind", "wait"]
            if any(w in text_lower for w in confirm_words):
                return self._handle_confirmed_action()
            if any(w in text_lower for w in cancel_words):
                self.state.pending_action = None
                return AssistantResponse(
                    text=(
                        "Got it! Action cancelled. ✋ No reservation was made.\n"
                        "What would you like to plan or adjust next?"
                    ),
                    action_type="text",
                    state_summary=self.state.summary(),
                )

        # Reset turn accumulation buffers
        self._accumulated_cards = []
        self._pending_map_action = None

        # ── 2. Extract structured travel slots from the message ───────────────
        self._extract_and_update_state(q)

        # ── 3. Build system instruction with fresh ConversationState ──────────
        system_instr = self._build_system_instruction()

        # ── 4. Snapshot history then append current user message ──────────────
        history_snapshot = list(self.messages)
        self.messages.append({"role": "user", "content": q})

        # ── 5. Call Gemini ────────────────────────────────────────────────────
        logger.info(
            "AssistantAgent → Gemini | history=%d turns | tools=%s | state=%s",
            len(history_snapshot),
            list(self._TOOL_ALLOWLIST),
            {k: v for k, v in self.state.summary().items() if v and v != "Flexible"},
        )

        gemini_resp = gemini_chat(
            user_message=q,
            system_instruction=system_instr,
            history=history_snapshot,
            tools=_get_active_tools(),
            tool_executor=self._execute_tool,
        )

        # ── 6. Success path ───────────────────────────────────────────────────
        if gemini_resp.success:
            self.messages.append({"role": "model", "content": gemini_resp.text})
            logger.info(
                "Gemini → AssistantAgent | tokens in=%s out=%s | cards=%d | map_action=%s",
                gemini_resp.usage.get("input_tokens", "?"),
                gemini_resp.usage.get("output_tokens", "?"),
                len(self._accumulated_cards),
                bool(self._pending_map_action),
            )
            cards = list(self._accumulated_cards)
            map_act = self._pending_map_action
            return AssistantResponse(
                text=gemini_resp.text,
                cards=cards,
                action_type="search_results" if cards else "text",
                state_summary=self.state.summary(),
                map_action=map_act,
            )

        # ── 7. Failure path ───────────────────────────────────────────────────
        # Remove the user message we appended so the user can retry cleanly.
        if self.messages and self.messages[-1]["role"] == "user":
            self.messages.pop()

        logger.error("AssistantAgent: Gemini call failed — %s", gemini_resp.error)

        return AssistantResponse(
            text=(
                "Sorry master, I'm having a bit of trouble reaching my AI brain "
                "right now. 🙏\n\n"
                "Please try again in a moment — I'll be right with you!"
            ),
            action_type="error",
            state_summary=self.state.summary(),
        )

    # ── Booking Selection & Confirmation (synchronous, no Gemini) ────────────

    def initiate_selection(self, item_type: str, item_data: dict) -> AssistantResponse:
        """
        Called when the user clicks 'Select' on a flight / hotel / transit card.
        Sets a pending_action and returns a structured confirmation prompt.
        Synchronous — does not call Gemini.
        """
        self.state.pending_action = {"type": f"book_{item_type}", "item": item_data}

        if item_type == "flight":
            self.state.selected_flight = item_data
            details = (
                f"✈️ **Flight Option Selected**:\n"
                f"• Route: {item_data.get('origin')} → {item_data.get('destination')}\n"
                f"• Airline: {item_data.get('airline')} ({item_data.get('airline_code')})\n"
                f"• Departure: {item_data.get('departure_time')}\n"
                f"• Passengers: {self.state.travelers} ({item_data.get('cabin')})\n"
                f"• Status: {item_data.get('price_display')}\n\n"
                "Master, should I proceed with this reservation request?"
            )
        elif item_type == "hotel":
            self.state.selected_hotel = item_data
            details = (
                f"🏨 **Hotel Room Selected**:\n"
                f"• Property: {item_data.get('name')}\n"
                f"• Room: {item_data.get('room_type')}\n"
                f"• Location: {item_data.get('location')}\n"
                f"• Policy: {item_data.get('cancellation_policy')}\n\n"
                "Master, should I proceed with this booking request?"
            )
        else:
            details = (
                f"🚆 **Transit Option Selected**:\n"
                f"• Provider: {item_data.get('provider_name')}\n"
                f"• Route: {item_data.get('origin')} → {item_data.get('destination')}\n"
                f"• Departure: {item_data.get('departure_time')}\n\n"
                "Master, should I proceed with this transit reservation?"
            )

        return AssistantResponse(
            text=details,
            cards=[{
                "type": "confirmation",
                "action": f"book_{item_type}",
                "item": item_data,
            }],
            action_type="confirmation",
            state_summary=self.state.summary(),
        )

    def _handle_confirmed_action(self) -> AssistantResponse:
        """Execute a previously confirmed booking action. Synchronous."""
        action = self.state.pending_action
        self.state.pending_action = None
        if not action:
            return AssistantResponse(
                text="No pending action found.",
                state_summary=self.state.summary(),
            )

        act_type = action.get("type", "")
        item     = action.get("item", {})

        if "flight" in act_type:
            res = travel_provider_service.execute_booking(
                "flight", item.get("id", ""), item, confirmed_by_user=True
            )
            return AssistantResponse(
                text=f"📋 **Flight Booking Status**:\n\n{res.get('message')}",
                action_type="booking_result",
                state_summary=self.state.summary(),
            )
        if "hotel" in act_type:
            res = travel_provider_service.execute_booking(
                "hotel", item.get("id", ""), item, confirmed_by_user=True
            )
            return AssistantResponse(
                text=f"📋 **Hotel Booking Status**:\n\n{res.get('message')}",
                action_type="booking_result",
                state_summary=self.state.summary(),
            )
        if "transit" in act_type:
            res = travel_provider_service.execute_booking(
                "transit", item.get("id", ""), item, confirmed_by_user=True
            )
            return AssistantResponse(
                text=f"📋 **Transit Booking Status**:\n\n{res.get('message')}",
                action_type="booking_result",
                state_summary=self.state.summary(),
            )

        return AssistantResponse(
            text="Action confirmed successfully!",
            action_type="text",
            state_summary=self.state.summary(),
        )


# ── Module-level singleton ────────────────────────────────────────────────────
assistant_agent = AssistantAgent()
