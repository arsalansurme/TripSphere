"""
TripSphere Voice Service — Speech Recognition (STT), Text-to-Speech (TTS),
and Continuous Conversation Loop with natural turn detection.

Fixes applied:
  • pause_threshold raised to 1.4 s so brief mid-sentence pauses do NOT end the turn.
  • non_speaking_duration set to 0.5 s to buffer trailing audio cleanly.
  • phrase_time_limit raised to 25 s (enough for any natural sentence).
  • timeout raised to 8 s so the listener waits long enough for speech to begin.
  • dynamic_energy_threshold kept True but initial energy_threshold lowered to 200
    so quiet voices are not missed.
  • Microphone is MUTED (flag-gated) while TTS is speaking — prevents echo.
  • Full debug logging at every pipeline stage.
  • STT language hint set to en-IN for better Indian-accent recognition.

Latency optimisations (added):
  • Sentence-level TTS pipeline: AI response is split into sentences.
    Audio for sentence 1 is generated first (~300-500 ms), playback starts
    immediately, then sentences 2-N are generated in a background thread
    while sentence 1 is already playing.  No MCI partial-file issues.
  • Gemini client is now cached (see gemini_client.py) — no new connection per call.
  • Detailed per-stage timing logs: SPEECH_END → AI_REQUEST_START →
    AI_FIRST_RESPONSE → TTS_REQUEST_START → TTS_FIRST_AUDIO →
    AUDIO_PLAYBACK_STARTED → RESPONSE_COMPLETE.
"""
from __future__ import annotations

import os
import sys
import re
import time
import logging
import tempfile
import threading
import queue
import ctypes
import asyncio
from typing import Optional, Callable, List
from enum import Enum

from PySide6.QtCore import QObject, Signal, Slot

logger = logging.getLogger(__name__)


class VoiceState(str, Enum):
    IDLE = "IDLE"
    LISTENING = "LISTENING"
    THINKING = "THINKING"
    SPEAKING = "SPEAKING"
    ERROR = "ERROR"




# ── Sentence splitter for TTS pipeline ───────────────────────────────────────
_SENTENCE_SPLIT_RE = re.compile(r'(?<=[.!?])\s+')


def _split_tts_sentences(text: str) -> List[str]:
    """
    Split a TTS text string into sentence-sized chunks for pipelining.

    Rules:
      - Split at sentence-ending punctuation (.!?) followed by whitespace.
      - Accumulate fragments shorter than MIN_CHARS into the previous chunk
        so we don't generate a tiny audio file for a 2-word leftover.
      - Always return at least one element (the full text).
    """
    MIN_CHARS = 30
    raw = [s.strip() for s in _SENTENCE_SPLIT_RE.split(text.strip()) if s.strip()]
    if not raw:
        return [text.strip()] if text.strip() else []

    merged: List[str] = []
    current = raw[0]
    for s in raw[1:]:
        if len(s) < MIN_CHARS:
            current = current + " " + s
        else:
            merged.append(current)
            current = s
    merged.append(current)
    return merged


def clean_text_for_speech(text: str) -> str:
    """
    Format and clean markdown text for natural, conversational TTS.
    Strips markdown formatting, bold/italics markers, URLs, emojis, and bullet syntax.
    Converts currency symbols to spoken words (e.g. ₹ -> rupees).
    """
    if not text:
        return ""
    # Convert currency symbols to spoken words (handles formatted numbers like 15,000 or 500.50)
    text = re.sub(r"₹\s*([\d,]+(?:\.\d+)?)", r"\1 rupees", text)
    text = text.replace("₹", " rupees ")
    text = re.sub(r"\$\s*([\d,]+(?:\.\d+)?)", r"\1 dollars", text)
    text = text.replace("$", " dollars ")
    text = re.sub(r"€\s*([\d,]+(?:\.\d+)?)", r"\1 euros", text)
    text = text.replace("€", " euros ")
    text = re.sub(r"£\s*([\d,]+(?:\.\d+)?)", r"\1 pounds", text)
    text = text.replace("£", " pounds ")

    # Strip code blocks
    text = re.sub(r"```[\s\S]*?```", "", text)
    text = re.sub(r"`.*?`", "", text)
    # Strip markdown links [label](url) -> label
    text = re.sub(r"\[([^\]]+)\]\([^\)]+\)", r"\1", text)
    # Strip bold / italics markers
    text = re.sub(r"\*\*([^*]+)\*\*", r"\1", text)
    text = re.sub(r"\*([^*]+)\*", r"\1", text)
    text = re.sub(r"__([^_]+)__", r"\1", text)
    text = re.sub(r"_([^_]+)_", r"\1", text)
    # Strip headers # Header
    text = re.sub(r"#{1,6}\s*", "", text)
    # Strip bullet points and list numbering
    text = re.sub(r"^\s*[-*+•]\s+", "", text, flags=re.MULTILINE)
    text = re.sub(r"^\s*\d+\.\s+", "", text, flags=re.MULTILINE)
    # Strip emojis and non-ASCII / non-latin punctuation
    text = re.sub(r"[^\w\s.,!?'\-\"]", " ", text)
    # Replace multiple newlines and spaces
    text = re.sub(r"\s+", " ", text).strip()
    return text


class TTSEngine:
    """
    High-fidelity Neural Text-To-Speech engine.
    
    Primary: Microsoft Edge Neural TTS with 'en-US-AvaNeural' (Copilot's conversational,
             warm, youthful, charming travel companion voice) and dynamic emotional prosody.
    Playback: Windows Native Media Control Interface (MCI) with zero-latency interruption.
    Fallback: Windows SAPI.SpVoice (Microsoft Zira Desktop) and pyttsx3 for offline resilience.
    """

    DEFAULT_VOICE = "en-US-AvaNeural"

    def __init__(self, voice: str = DEFAULT_VOICE):
        self.voice = voice
        self._sapi_voice = None
        self._has_edge_tts = False
        self._is_speaking = False
        self._current_alias: Optional[str] = None
        self._lock = threading.Lock()
        self._init_engine()

    def _init_engine(self):
        # 1. Check Neural TTS (edge-tts) availability
        try:
            import edge_tts
            self._has_edge_tts = True
            logger.info("[TTS] High-Fidelity Neural TTS ready (voice=%s)", self.voice)
        except ImportError:
            self._has_edge_tts = False
            logger.warning("[TTS] edge-tts not available, will use SAPI fallback.")

        # 2. Initialize SAPI fallback
        try:
            import win32com.client
            sapi = win32com.client.Dispatch("SAPI.SpVoice")
            voices = sapi.GetVoices()
            chosen = None
            female_fallback = None

            for i in range(voices.Count):
                v = voices.Item(i)
                desc = v.GetDescription().lower()
                try:
                    gender = v.GetAttribute("Gender").lower()
                except Exception:
                    gender = ""

                if "zira" in desc:
                    chosen = v
                    break
                if gender == "female" and female_fallback is None:
                    female_fallback = v

            chosen = chosen or female_fallback
            if chosen is not None:
                sapi.Voice = chosen
            sapi.Rate = -1
            sapi.Volume = 95
            self._sapi_voice = sapi
            logger.info("[TTS] SAPI fallback ready: %s", chosen.GetDescription() if chosen else "default")
        except Exception as exc:
            logger.warning("[TTS] SAPI fallback init failed: %s", exc)
            self._sapi_voice = None

    # ── Prosody Engine ────────────────────────────────────────────────────────

    def _detect_prosody(self, text: str) -> tuple[str, str, int]:
        """
        Detect emotional tone from text and return:
        (neural_rate, neural_pitch, sapi_rate)
        
        Neural TTS parameters:
          rate: percentage change (e.g. '+6%', '-2%')
          pitch: Hz change (e.g. '+4Hz', '+1Hz')
        SAPI rate: integer (-10 to +10)
        """
        t = text.lower()

        # Excited, enthusiastic, celebrating
        if re.search(r'\b(ooo+h|heee+y+|yess+|wow+|woo+|yay|amazing|love it|so fun|gonna be fun|awesome|epic)\b', t):
            return "+6%", "+4Hz", 2

        # Playful, charming, teasing, witty
        if re.search(r'\b(haha+|lol|challenge accepted|say less|boss|deal|now you.re speaking|alrighty)\b', t):
            return "+4%", "+3Hz", 1

        # Reassuring, warm, soothing, protective
        if re.search(r"\b(don.t worry|i.ve got you|we.ll find|i got you|no worries|relax|take it easy|count on me)\b", t):
            return "-2%", "+1Hz", -2

        # Curious, questioning, exploring options
        if text.strip().endswith('?') and re.search(r'\b(what|how|where|which|when|who|why|far|budget|days|vibe|kind|feeling)\b', t):
            return "+2%", "+3Hz", 0

        # Calm affirmation
        if re.search(r'^(alright|okay|got it|perfect|nice|yep|sure|fair|absolutely|sounds good)', t):
            return "+1%", "+2Hz", -1

        # Default conversational baseline: youthful, warm, cute, pleasant bounce
        return "+3%", "+2Hz", -1

    def speak(self, text: str, on_finish: Optional[Callable[[], None]] = None) -> None:
        """
        Speak text using high-fidelity Neural TTS with automatic SAPI fallback.
        Non-blocking, supports instant interruption via stop().
        """
        cleaned = clean_text_for_speech(text)
        if not cleaned:
            if on_finish:
                on_finish()
            return

        with self._lock:
            self._is_speaking = True

        logger.info("[TTS START] Speaking: %.80s...", cleaned)

        def _run():
            neural_spoken = False
            neural_rate, neural_pitch, sapi_rate = self._detect_prosody(cleaned)

            if self._has_edge_tts:
                neural_spoken = self._speak_neural(cleaned, neural_rate, neural_pitch)

            if not neural_spoken:
                self._speak_sapi(cleaned, sapi_rate)

            with self._lock:
                was_speaking = self._is_speaking
                self._is_speaking = False
            logger.info("[TTS END] Speech finished (natural=%s)", was_speaking)
            if was_speaking and on_finish:
                on_finish()

        t = threading.Thread(target=_run, daemon=True, name="TTSPlaybackThread")
        t.start()

    def _generate_audio_file(self, text: str, rate: str, pitch: str) -> Optional[str]:
        """
        Generate a complete MP3 audio file for *text* and return the file path.
        Returns None on error.  Always generates a complete, playable file.
        """
        import edge_tts
        alias = f"tts_{int(time.time() * 1000) % 1000000}_{threading.get_ident()}"
        temp_file = os.path.join(tempfile.gettempdir(), f"{alias}.mp3")
        try:
            communicate = edge_tts.Communicate(text, self.voice, rate=rate, pitch=pitch)
            asyncio.run(communicate.save(temp_file))
            return temp_file
        except Exception as exc:
            logger.warning("[TTS NEURAL] Audio generation error: %s", exc)
            if os.path.exists(temp_file):
                try:
                    os.remove(temp_file)
                except Exception:
                    pass
            return None

    def _play_file_via_mci(self, temp_file: str) -> bool:
        """
        Open *temp_file* with MCI and block until playback finishes or is interrupted.
        Returns True when done, False if MCI open failed.
        """
        alias = f"tts_{int(time.time() * 1000) % 1000000}_{threading.get_ident()}"
        with self._lock:
            self._current_alias = alias

        mci = ctypes.windll.winmm.mciSendStringW
        mci(f'close {alias}', None, 0, None)
        res = mci(f'open "{temp_file}" type mpegvideo alias {alias}', None, 0, None)
        if res != 0:
            logger.warning("[TTS] MCI open failed (%d)", res)
            return False

        mci(f'play {alias}', None, 0, None)
        logger.info("[LATENCY] AUDIO_PLAYBACK_STARTED")

        # Poll MCI mode until stopped or interrupted
        buf = ctypes.create_unicode_buffer(64)
        try:
            while True:
                with self._lock:
                    if not self._is_speaking:
                        mci(f'stop {alias}', None, 0, None)
                        return True
                mci(f'status {alias} mode', buf, 64, None)
                if buf.value.lower() in ('stopped', 'paused', ''):
                    return True
                time.sleep(0.04)
        finally:
            mci(f'close {alias}', None, 0, None)
            if os.path.exists(temp_file):
                try:
                    os.remove(temp_file)
                except Exception:
                    pass

    def _speak_neural(self, text: str, rate: str, pitch: str) -> bool:
        """
        Sentence-level pipelined TTS via Edge Neural TTS + Windows MCI.

        Pipeline:
          1. Split the full text into sentence-sized chunks.
          2. Generate audio for sentence 1 (fast — typically 300-500 ms).
          3. Start a background thread that pre-generates audio for sentences 2-N.
          4. Play sentence 1 via MCI immediately once its file is ready.
          5. When sentence 1 finishes, sentence 2 is already generated — play with
             zero gap.  Repeat until all sentences done or interrupted.

        This avoids the MCI partial-file problem entirely (every file is a complete,
        independently playable MP3) and gives a real TTFS reduction equal to the
        time saved by not generating sentences 2-N before starting playback.
        """
        t_tts_request = time.perf_counter()
        logger.info("[LATENCY] TTS_REQUEST_START")

        # Split text into sentences
        sentences = _split_tts_sentences(text)
        logger.info("[TTS NEURAL] Pipeline: %d sentence(s), voice=%s, rate=%s, pitch=%s",
                    len(sentences), self.voice, rate, pitch)

        # Queue for background-generated sentences; sentinel signals completion
        audio_queue: queue.Queue = queue.Queue(maxsize=4)
        _SENTINEL = object()

        # Generate sentence 0 on THIS thread first (so playback starts ASAP)
        first_file = self._generate_audio_file(sentences[0], rate, pitch)
        t_first_audio = time.perf_counter()
        logger.info(
            "[LATENCY] TTS_FIRST_AUDIO  +%.0f ms after TTS_REQUEST_START (sentence 1 of %d ready)",
            (t_first_audio - t_tts_request) * 1000,
            len(sentences),
        )

        if not first_file:
            logger.warning("[TTS NEURAL] First sentence generation failed; falling back to SAPI")
            return False

        # If there are more sentences, start pre-generating them in background
        if len(sentences) > 1:
            remaining = sentences[1:]

            def _bg_producer():
                for i, sentence in enumerate(remaining, start=1):
                    with self._lock:
                        if not self._is_speaking:
                            break
                    fp = self._generate_audio_file(sentence, rate, pitch)
                    audio_queue.put((i, fp))
                audio_queue.put(_SENTINEL)

            threading.Thread(target=_bg_producer, daemon=True, name="TTSGenThread").start()
        else:
            # Only one sentence — signal immediately
            audio_queue.put(_SENTINEL)

        # ── Play sentence 1 ───────────────────────────────────────────────────
        with self._lock:
            if not self._is_speaking:
                if os.path.exists(first_file):
                    try:
                        os.remove(first_file)
                    except Exception:
                        pass
                return True  # interrupted before we even start

        self._play_file_via_mci(first_file)

        # ── Play remaining sentences from the queue ────────────────────────────
        while True:
            item = audio_queue.get()
            if item is _SENTINEL:
                break
            idx, fp = item
            if fp is None:
                logger.warning("[TTS NEURAL] Sentence %d generation failed; skipping", idx)
                continue
            with self._lock:
                if not self._is_speaking:
                    if fp and os.path.exists(fp):
                        try:
                            os.remove(fp)
                        except Exception:
                            pass
                    break
            self._play_file_via_mci(fp)

        return True

    def _speak_sapi(self, text: str, rate: int) -> None:
        """Fallback to Windows SAPI.SpVoice or pyttsx3."""
        try:
            if self._sapi_voice is not None:
                self._sapi_voice.Rate = rate
                # SVSFlagsAsync=1, SVSFPurgeBeforeSpeak=2
                self._sapi_voice.Speak(text, 1 | 2)

                while True:
                    with self._lock:
                        if not self._is_speaking:
                            break
                    try:
                        if self._sapi_voice.Status.RunningState != 2:
                            break
                    except Exception:
                        break
                    time.sleep(0.05)
            else:
                import pyttsx3
                engine = pyttsx3.init()
                pv = engine.getProperty('voices')
                for v in (pv or []):
                    if 'zira' in v.name.lower() or 'female' in v.name.lower():
                        engine.setProperty('voice', v.id)
                        break
                engine.setProperty("rate", 155)
                engine.setProperty("volume", 0.93)
                engine.say(text)
                engine.runAndWait()
        except Exception as exc:
            logger.error("[TTS SAPI] Error: %s", exc)

    def stop(self) -> None:
        """Interrupt and halt any currently playing audio immediately."""
        with self._lock:
            if not self._is_speaking:
                return
            self._is_speaking = False
            alias = self._current_alias

        logger.info("[TTS] Interrupted/stopped.")
        if alias:
            try:
                ctypes.windll.winmm.mciSendStringW(f'stop {alias}', None, 0, None)
                ctypes.windll.winmm.mciSendStringW(f'close {alias}', None, 0, None)
            except Exception:
                pass
        try:
            if self._sapi_voice is not None:
                self._sapi_voice.Speak("", 2 | 1)
        except Exception as exc:
            logger.debug("[TTS] SAPI purge error: %s", exc)

    @property
    def is_speaking(self) -> bool:
        with self._lock:
            return self._is_speaking


class STTEngine:
    """
    Speech-To-Text engine using SpeechRecognition with carefully tuned VAD parameters
    for natural conversational capture.

    Key parameters (tuned for natural speech):
      pause_threshold       = 1.4 s  — wait 1.4 s of silence before ending the turn.
                                        Allows brief mid-sentence pauses without
                                        cutting the user off prematurely.
      non_speaking_duration = 0.5 s  — trailing silence kept in audio buffer.
      phrase_time_limit     = 25 s   — captures up to 25 s of continuous speech.
      timeout               = 8.0 s  — waits up to 8 s for speech to begin.
      energy_threshold      = 200    — low baseline; auto-calibrated upward dynamically.
      dynamic_energy_threshold = True — adapts to ambient noise.

    Mic muting:
      listen_and_recognize() accepts a tts_engine argument.
      If tts_engine.is_speaking is True, returns None immediately to prevent
      the assistant's own TTS voice from being captured as user speech.
    """

    def __init__(self):
        self._recognizer = None
        self._mic = None
        self._available = False
        self._init_engine()

    def _init_engine(self):
        try:
            import speech_recognition as sr
            r = sr.Recognizer()

            # ── VAD Parameters (tuned for natural conversation) ──────────────
            # pause_threshold: seconds of silence to conclude the user's turn.
            # 1.4 s allows natural mid-sentence pauses ("I want to go... because").
            r.pause_threshold = 1.4

            # non_speaking_duration: trailing silence kept in the audio buffer.
            # 0.5 s ensures word-final sounds are not clipped.
            r.non_speaking_duration = 0.5

            # dynamic_energy_threshold: auto-adjust for ambient noise.
            r.dynamic_energy_threshold = True
            # Slower adaptation = more stable threshold (avoids over-adaptation).
            r.dynamic_energy_adjustment_damping = 0.15
            # Speech must be 1.5x louder than ambient noise to be detected.
            r.dynamic_energy_ratio = 1.5

            # Low starting threshold; dynamic mode will raise it as needed.
            r.energy_threshold = 200

            self._recognizer = r
            self._mic = sr.Microphone()
            self._available = True
            logger.info(
                "[STT] Microphone initialized. pause_threshold=%.1f s, "
                "energy_threshold=%d, phrase_limit=25 s",
                r.pause_threshold, r.energy_threshold
            )
        except Exception as exc:
            logger.warning("[STT] Init failed: %s", exc)
            self._available = False

    @property
    def is_available(self) -> bool:
        return self._available

    def calibrate(self, duration: float = 1.0) -> None:
        """
        Calibrate ambient noise baseline.
        Call once at startup (off the main thread) with a 1-second sample.
        """
        if not self._available or not self._mic:
            return
        try:
            import speech_recognition as sr
            logger.info("[STT] Calibrating ambient noise (%.1f s)...", duration)
            with self._mic as source:
                self._recognizer.adjust_for_ambient_noise(source, duration=duration)
            logger.info("[STT] Calibration done. energy_threshold=%.0f",
                        self._recognizer.energy_threshold)
        except Exception as exc:
            logger.debug("[STT] Calibration error: %s", exc)

    def listen_and_recognize(
        self,
        timeout: float = 8.0,
        phrase_time_limit: float = 25.0,
        tts_engine: Optional["TTSEngine"] = None,
        language: str = "en-IN",
    ) -> Optional[str]:
        """
        Listen for user speech on the microphone and convert to text.

        Args:
            timeout:          Seconds to wait for speech to BEGIN (returns None on silence).
            phrase_time_limit: Maximum seconds of audio to capture per turn.
            tts_engine:       If provided and is_speaking is True, returns None immediately
                              (mic muted during TTS playback to prevent echo capture).
            language:         BCP-47 language tag for Google STT. en-IN improves accuracy
                              for Indian-accented English and Indian place names.

        Returns:
            Recognized text string, or None if silence / timeout / echo-muted / error.
        """
        if not self._available or not self._mic or not self._recognizer:
            return None

        # ── Mic mute: do NOT capture while TTS is speaking ───────────────────
        if tts_engine is not None and tts_engine.is_speaking:
            logger.debug("[STT] Mic muted — TTS is currently speaking.")
            return None

        import speech_recognition as sr
        try:
            logger.info(
                "[MIC START] Waiting for user speech (timeout=%.1f s, phrase_limit=%.1f s)...",
                timeout, phrase_time_limit
            )
            with self._mic as source:
                audio = self._recognizer.listen(
                    source,
                    timeout=timeout,
                    phrase_time_limit=phrase_time_limit,
                )

            logger.info(
                "[MIC STOP] Audio captured (%d bytes). Sending to Google STT...",
                len(audio.get_raw_data())
            )
            logger.debug("[PARTIAL TRANSCRIPT] Recognizing...")

            text = self._recognizer.recognize_google(audio, language=language)
            text = text.strip()

            logger.info("[FINAL TRANSCRIPT] '%s'", text)
            return text

        except sr.WaitTimeoutError:
            logger.debug("[STT] WaitTimeoutError — no speech detected in %.1f s.", timeout)
            return None
        except sr.UnknownValueError:
            logger.debug("[STT] UnknownValueError — audio was too unclear to transcribe.")
            return None
        except Exception as exc:
            logger.debug("[STT] Exception during listen: %s", exc)
            return None


class ContinuousVoiceWorker(QObject):
    """
    QObject worker running in a background QThread to manage the voice conversation lifecycle.

    Turn flow (LISTEN → UNDERSTAND → REMEMBER → RESPOND → SPEAK → LISTEN):
      1. ASSISTANT SPEAKS (TTS)
      2. TTS FINISHES → mic automatically becomes active (is_speaking=False)
      3. LISTENING: wait up to 8 s for user to start speaking
      4. User speaks → 1.4 s silence detected → FINAL TRANSCRIPT produced
      5. THINKING: AI processes full transcript
      6. AI RESPONDS → SPEAKING (TTS)
      7. TTS FINISHES → go to step 3

    Echo prevention:
      The listen loop checks tts_engine.is_speaking before each STT call.
      While the assistant is speaking, the microphone is ignored.

    Interruption:
      User can tap orb while assistant speaks. TTS stops immediately,
      microphone becomes active, new listening turn begins.
    """

    state_changed = Signal(str)              # emits VoiceState value
    user_spoken = Signal(str)               # emits recognized user text
    assistant_spoken = Signal(str, object)  # emits assistant text, AssistantResponse object
    error_occurred = Signal(str)            # emits error message

    def __init__(self, tts: TTSEngine, stt: STTEngine):
        super().__init__()
        self.tts = tts
        self.stt = stt
        self._running = False
        self._current_state = VoiceState.IDLE
        self._interrupted = False
        self._lock = threading.Lock()

    @property
    def current_state(self) -> VoiceState:
        with self._lock:
            return self._current_state

    def _set_state(self, state: VoiceState):
        with self._lock:
            self._current_state = state
        self.state_changed.emit(state.value)
        logger.info("[STATE] → %s", state.value)

    @Slot()
    def start_conversation(self, initial_greeting: str = "Heeeyyy boss! \ud83d\ude04 What's the order today? Beach, mountains, city \u2014 or are we just escaping somewhere?"):
        """Begin hands-free conversational loop."""
        self._running = True
        self._interrupted = False

        # 1. Speak initial greeting
        self._set_state(VoiceState.SPEAKING)
        self.assistant_spoken.emit(initial_greeting, None)

        def _on_greeting_finished():
            if self._running and not self._interrupted:
                self._enter_listening_loop()

        logger.info("[TTS START] Initial greeting")
        self.tts.speak(initial_greeting, on_finish=_on_greeting_finished)

    @Slot()
    def interrupt(self):
        """User interrupted assistant speech."""
        logger.info("[INTERRUPT] User triggered interrupt.")
        self.tts.stop()
        with self._lock:
            self._interrupted = True
        # Immediately enter listening state
        self._enter_listening_loop()

    @Slot()
    def stop(self):
        """Stop voice assistant loop completely."""
        logger.info("[STOP] Voice loop stopped.")
        self._running = False
        self.tts.stop()
        self._set_state(VoiceState.IDLE)

    @Slot(str)
    def submit_text_input(self, text: str):
        """Direct text input fallback (processes through AI and speaks aloud)."""
        if not text or not text.strip():
            return
        logger.info("[TEXT INPUT] '%s'", text.strip())
        self.tts.stop()
        self.user_spoken.emit(text.strip())
        self._process_ai_response(text.strip())

    def _enter_listening_loop(self):
        """Background thread: listen for a complete user turn."""
        if not self._running:
            return

        self._set_state(VoiceState.LISTENING)

        def _listen_job():
            with self._lock:
                self._interrupted = False

            # Keep listening until speech is detected or the assistant is stopped.
            while self._running:
                with self._lock:
                    if self._interrupted:
                        logger.debug("[LISTEN LOOP] Interrupted — exiting.")
                        break
                    if self._current_state != VoiceState.LISTENING:
                        logger.debug("[LISTEN LOOP] State changed away from LISTENING — exiting.")
                        break

                # Echo gate: skip this frame if TTS is still speaking.
                # (Handles edge-case where the on_finish callback fires slightly early.)
                if self.tts.is_speaking:
                    logger.debug("[LISTEN LOOP] TTS still active — gating mic for 100 ms.")
                    time.sleep(0.1)
                    continue

                logger.info("[VAD SPEECH START] Listening for user turn...")
                spoken_text = self.stt.listen_and_recognize(
                    timeout=8.0,
                    phrase_time_limit=25.0,
                    tts_engine=self.tts,
                )

                if not self._running:
                    break

                with self._lock:
                    if self._interrupted:
                        break

                if spoken_text:
                    logger.info("[VAD SPEECH END] Turn complete. Transcript: '%s'", spoken_text)
                    self.user_spoken.emit(spoken_text)
                    self._process_ai_response(spoken_text)
                    break
                else:
                    # Silence / timeout — continue waiting for user to start speaking.
                    logger.debug("[LISTEN LOOP] No speech in this frame — continuing.")
                    time.sleep(0.05)

        t = threading.Thread(target=_listen_job, daemon=True, name="VoiceListenThread")
        t.start()

    def _process_ai_response(self, user_text: str):
        """Send recognized text to the AI Travel Assistant and speak the result."""
        self._set_state(VoiceState.THINKING)

        def _ai_job():
            t_speech_end = time.perf_counter()  # proxy: speech_end ≈ job start
            logger.info("[LATENCY] SPEECH_END (entering AI job)")
            logger.info("[LATENCY] AI_REQUEST_START")
            logger.info("[AI REQUEST START] Processing: '%s'", user_text)
            t_ai_start = time.perf_counter()
            try:
                from app.services.assistant_agent import assistant_agent
                resp = assistant_agent.process_message(user_text)
                assistant_text = (
                    resp.text if resp
                    else "I couldn't process that. Could you say that again?"
                )
                t_ai_done = time.perf_counter()
                logger.info(
                    "[LATENCY] AI_FIRST_RESPONSE  +%.0f ms after AI_REQUEST_START",
                    (t_ai_done - t_ai_start) * 1000,
                )
                logger.info("[AI RESPONSE RECEIVED] %.120s...", assistant_text)
            except Exception as exc:
                logger.error("[AI] Reasoning error: %s", exc, exc_info=True)
                assistant_text = "I had a momentary connection issue. What were you saying?"
                resp = None
                t_ai_done = time.perf_counter()

            if not self._running:
                logger.debug("[AI JOB] Voice loop stopped before speaking.")
                return

            # Transition to SPEAKING
            self._set_state(VoiceState.SPEAKING)
            self.assistant_spoken.emit(assistant_text, resp)

            t_tts_start = time.perf_counter()
            logger.info(
                "[LATENCY] TTS_REQUEST_START  +%.0f ms after SPEECH_END",
                (t_tts_start - t_speech_end) * 1000,
            )

            def _on_speak_finished():
                t_done = time.perf_counter()
                logger.info(
                    "[LATENCY] RESPONSE_COMPLETE  total=+%.0f ms after SPEECH_END",
                    (t_done - t_speech_end) * 1000,
                )
                logger.info("[TTS END] Response spoken. Resuming listening loop.")
                if self._running:
                    with self._lock:
                        if self._interrupted:
                            logger.debug("[TTS END] Interrupted — not resuming listening.")
                            return
                    self._enter_listening_loop()

            logger.info("[TTS START] Speaking assistant response.")
            self.tts.speak(assistant_text, on_finish=_on_speak_finished)

        t = threading.Thread(target=_ai_job, daemon=True, name="VoiceAIThread")
        t.start()


class VoiceService:
    """Singleton service providing TTS and STT engines."""

    def __init__(self):
        self.tts = TTSEngine()
        self.stt = STTEngine()

    def calibrate(self, duration: float = 1.0) -> None:
        """Run ambient noise calibration off the main thread at startup."""
        self.stt.calibrate(duration=duration)

    def create_worker(self) -> ContinuousVoiceWorker:
        return ContinuousVoiceWorker(self.tts, self.stt)


voice_service = VoiceService()
