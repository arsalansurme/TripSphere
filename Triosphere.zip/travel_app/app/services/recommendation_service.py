"""
Recommendation service — popular places and destination suggestions.
"""
from __future__ import annotations

import random
import logging
from app.database.repositories import destination_repo, place_repo
from app.api.places import places_service

logger = logging.getLogger(__name__)


class RecommendationService:

    def get_popular_places(self, destination_name: str) -> list[dict]:
        """Return popular places for a destination name."""
        return places_service.get_popular(destination_name)

    def get_featured_destinations(self, limit: int = 6) -> list[dict]:
        """Return featured/trending destinations."""
        dests = destination_repo.get_all()
        return dests[:limit]

    def get_random_destination(self, filters: dict | None = None) -> dict | None:
        """Return a random destination, optionally filtered."""
        dest = destination_repo.get_random(filters)
        if not dest:
            return None
        dest = dict(dest)
        dest["places"] = place_repo.get_by_destination(dest["id"])
        return dest

    def get_by_category(self, category: str, limit: int = 6) -> list[dict]:
        rows = destination_repo.get_by_category(category)
        return rows[:limit]

    def get_similar(self, destination_name: str, limit: int = 4) -> list[dict]:
        """Find destinations with similar tags."""
        dests = destination_repo.search(destination_name)
        if not dests:
            return []
        target = dests[0]
        tags = (target.get("tags") or "").split(",")
        if not tags:
            return []
        tag = random.choice(tags).strip()
        if not tag:
            return []
        similar = destination_repo.get_all()
        result  = []
        for d in similar:
            if d["id"] == target["id"]:
                continue
            if tag in (d.get("tags") or ""):
                result.append(d)
            if len(result) >= limit:
                break
        return result


recommendation_service = RecommendationService()
