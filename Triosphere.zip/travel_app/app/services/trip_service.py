"""
Trip service — business logic for trip management.
Orchestrates repository calls and routing calculations.
"""
from __future__ import annotations

import logging
from typing import Optional

from app.database.repositories import (
    trip_repo, trip_stop_repo, itinerary_repo, expense_repo
)
from app.api.routing import routing_service

logger = logging.getLogger(__name__)


class TripService:
    """High-level trip operations."""

    def create_trip(self, data: dict) -> int:
        """Create a new trip and return its ID."""
        trip_id = trip_repo.insert(data)
        # Add origin as first stop if coordinates provided
        if data.get("origin") and data.get("origin_lat"):
            trip_stop_repo.insert({
                "trip_id":    trip_id,
                "stop_order": 0,
                "place_name": data["origin"],
                "lat":        data.get("origin_lat"),
                "lon":        data.get("origin_lon"),
                "nights":     0,
            })
        # Add destination as second stop if coordinates provided
        if data.get("destination") and data.get("dest_lat"):
            trip_stop_repo.insert({
                "trip_id":    trip_id,
                "stop_order": 1,
                "place_name": data["destination"],
                "lat":        data.get("dest_lat"),
                "lon":        data.get("dest_lon"),
                "nights":     data.get("nights", 1),
            })
        return trip_id

    def get_trip(self, trip_id: int) -> Optional[dict]:
        trip = trip_repo.get_by_id(trip_id)
        if not trip:
            return None
        trip = dict(trip)
        trip["stops"]     = trip_stop_repo.get_by_trip(trip_id)
        trip["itinerary"] = itinerary_repo.get_by_trip(trip_id)
        trip["expenses"]  = expense_repo.get_all(trip_id)
        trip["spent"]     = expense_repo.get_total(trip_id)
        trip["remaining"] = (trip.get("budget") or 0) - trip["spent"]
        trip["category_breakdown"] = expense_repo.get_by_category(trip_id)
        return trip

    def get_all_trips(self) -> list[dict]:
        trips = trip_repo.get_all()
        enriched = []
        for t in trips:
            t = dict(t)
            t["spent"]     = expense_repo.get_total(t["id"])
            t["remaining"] = (t.get("budget") or 0) - t["spent"]
            enriched.append(t)
        return enriched

    def calculate_route(self, trip_id: int, mode: str = "driving") -> dict:
        """Calculate the full multi-stop route for a trip."""
        stops = trip_stop_repo.get_by_trip(trip_id)
        if len(stops) < 2:
            return {"distance_km": 0, "duration_min": 0, "duration_str": "—",
                    "geometry": [], "fallback": False}
        waypoints = [(s["lat"], s["lon"]) for s in stops if s.get("lat") and s.get("lon")]
        return routing_service.get_multi_route(waypoints, mode)

    def add_stop(self, trip_id: int, stop_data: dict) -> int:
        stops = trip_stop_repo.get_by_trip(trip_id)
        stop_data["trip_id"]    = trip_id
        stop_data["stop_order"] = len(stops)
        return trip_stop_repo.insert(stop_data)

    def remove_stop(self, stop_id: int) -> None:
        trip_stop_repo.delete(stop_id)

    def add_itinerary_item(self, trip_id: int, item: dict) -> int:
        item["trip_id"] = trip_id
        return itinerary_repo.insert(item)

    def delete_trip(self, trip_id: int) -> None:
        trip_repo.delete(trip_id)

    def update_trip(self, trip_id: int, data: dict) -> None:
        trip_repo.update(trip_id, data)


trip_service = TripService()
