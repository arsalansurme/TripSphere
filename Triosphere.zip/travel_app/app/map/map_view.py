"""
MapView — PySide6 QWebEngineView wrapping the Leaflet map.
Provides a clean Python API and a bidirectional bridge to JavaScript.
"""
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Optional

from PySide6.QtCore    import QObject, QUrl, Qt, Signal, Slot, QTimer
from PySide6.QtWebEngineCore import QWebEngineNewWindowRequest
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtWebEngineCore import QWebEnginePage
from PySide6.QtWebChannel import QWebChannel
from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel

logger = logging.getLogger(__name__)

_MAP_HTML = Path(__file__).parent / "map.html"


class _MapPage(QWebEnginePage):
    """
    Custom QWebEnginePage that blocks all new-window creation.

    In Qt 6.8+, new-window requests are delivered via the newWindowRequested
    signal rather than createWindow().  If newWindowRequested is not connected,
    Qt creates a new top-level native QWebEngineView — the second "ghost" window
    visible in Alt-Tab.  By connecting the signal to _block_new_window (which
    does NOT call request.openIn()), we tell Qt "handled — do not create a
    default window", discarding the request safely.

    createWindow() is kept for older Qt versions / edge-cases where it may
    still be invoked.

    Triggered by: Leaflet OSM attribution link, any navigation inside the map
    HTML that Chromium would open in a new tab/window.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        # Qt 6.8+: newWindowRequested replaces createWindow() as the primary
        # mechanism for new-window requests.  Connecting it to a no-op slot
        # suppresses the default native window creation.
        self.newWindowRequested.connect(self._block_new_window)

    @Slot(QWebEngineNewWindowRequest)
    def _block_new_window(self, request: QWebEngineNewWindowRequest) -> None:
        """Discard any new-window request — never create a second native window."""
        logger.debug(
            "MapPage: blocked new-window request (destination=%s, url=%s).",
            request.destination(),
            request.requestedUrl().toString(),
        )
        # Intentionally do NOT call request.openIn() — this discards the
        # request and prevents Qt from spawning a top-level native window.

    def createWindow(self, window_type: QWebEnginePage.WebWindowType) -> "QWebEnginePage | None":
        """Fallback for older Qt versions — return None to block window creation."""
        logger.debug(
            "MapPage: createWindow blocked (type=%s) — keeping navigation embedded.",
            window_type,
        )
        return None


class MapBridge(QObject):
    """JavaScript-to-Python bridge object, registered with QWebChannel."""

    #: emitted when user clicks on the map
    location_clicked = Signal(float, float)
    #: emitted when user clicks "Select" on a marker popup
    marker_selected  = Signal(int)
    #: emitted when user clicks "Save" on a marker popup
    add_favorite     = Signal(int)

    def __init__(self, parent: QObject | None = None):
        super().__init__(parent)
        # Keep a registry of marker data so Python code can look them up
        self._marker_data: dict[int, dict] = {}

    def register_marker(self, marker_id: int, data: dict) -> None:
        self._marker_data[marker_id] = data

    def get_marker_data(self, marker_id: int) -> Optional[dict]:
        return self._marker_data.get(marker_id)

    def clear_marker_registry(self) -> None:
        self._marker_data.clear()

    # ── Slots callable from JavaScript ────────────────────────────────────────

    @Slot(float, float)
    def on_map_clicked(self, lat: float, lng: float) -> None:
        logger.debug("Map clicked: %.4f, %.4f", lat, lng)
        self.location_clicked.emit(lat, lng)

    @Slot(int)
    def on_marker_selected(self, marker_id: int) -> None:
        logger.debug("Marker selected: %d", marker_id)
        self.marker_selected.emit(marker_id)

    @Slot(int)
    def on_add_favorite(self, marker_id: int) -> None:
        logger.debug("Add favorite: %d", marker_id)
        self.add_favorite.emit(marker_id)


class MapView(QWebEngineView):
    """
    Interactive Leaflet map embedded in a QWebEngineView.

    Usage:
        mv = MapView()
        mv.center(28.61, 77.20, zoom=12)
        mid = mv.add_marker(28.61, 77.20, "Delhi", "City")
        mv.draw_route([[28.61, 77.20], [19.07, 72.87]])
    """

    # Signals forwarded from the bridge
    location_clicked = Signal(float, float)
    marker_selected  = Signal(int)
    add_favorite     = Signal(int)

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self._next_id    = 1
        self._ready      = False
        self._pending    = []   # JS calls queued before page is ready

        # Install the custom page FIRST so createWindow() is overridden
        # before any content loads.  This prevents the Chromium engine from
        # spawning a second native top-level window when the embedded page
        # requests a new tab/window (e.g. via the Leaflet attribution link).
        self.setPage(_MapPage(self))

        # Set up the bridge
        self._bridge = MapBridge(self)
        self._bridge.location_clicked.connect(self.location_clicked)
        self._bridge.marker_selected.connect(self.marker_selected)
        self._bridge.add_favorite.connect(self.add_favorite)

        # Set up WebChannel
        channel = QWebChannel(self)
        channel.registerObject("bridge", self._bridge)
        self.page().setWebChannel(channel)

        # Allow local file access (needed for qrc:// scheme)
        self.settings().setAttribute(
            self.settings().WebAttribute.LocalContentCanAccessRemoteUrls, True
        )

        # Load the map HTML
        self.loadFinished.connect(self._on_load_finished)
        self._load_map()

    # ── Loading ───────────────────────────────────────────────────────────────

    def _load_map(self) -> None:
        if _MAP_HTML.exists():
            url = QUrl.fromLocalFile(str(_MAP_HTML))
        else:
            logger.error("map.html not found at %s", _MAP_HTML)
            return
        self.load(url)

    def _on_load_finished(self, ok: bool) -> None:
        if not ok:
            logger.error("Map HTML failed to load.")
            return
        logger.info("Map HTML loaded successfully.")
        self._ready = True
        # Init the Leaflet map
        self._js("initMap(20.5937, 78.9629, 5)")
        QTimer.singleShot(0, lambda: self._js("if (map) map.invalidateSize(false)"))
        QTimer.singleShot(250, lambda: self._js("if (map) map.invalidateSize(false)"))
        # Flush pending calls
        for call in self._pending:
            self.page().runJavaScript(call)
        self._pending.clear()

    def _js(self, code: str) -> None:
        """Run JavaScript, queuing if not yet ready."""
        if self._ready:
            self.page().runJavaScript(code)
        else:
            self._pending.append(code)

    # ── Public Map API ────────────────────────────────────────────────────────

    def center(self, lat: float, lon: float, zoom: int = 12) -> None:
        """Fly the map to given coordinates."""
        self._js(f"centerMap({lat}, {lon}, {zoom})")

    def add_marker(
        self,
        lat: float,
        lon: float,
        name: str = "",
        category: str = "",
        description: str = "",
        rating: float = 0,
        marker_type: str = "place",
    ) -> int:
        """
        Add a marker and return its integer ID.
        marker_type: 'main' | 'place' | 'journal' | 'stop' | 'home'
        """
        mid = self._next_id
        self._next_id += 1

        js_name  = json.dumps(name)
        js_cat   = json.dumps(category)
        js_desc  = json.dumps(description)
        js_type  = json.dumps(marker_type)
        self._js(
            f"addMarker({lat}, {lon}, {js_name}, {js_cat}, {js_desc}, {rating}, {js_type})"
        )
        self._bridge.register_marker(mid, {
            "lat": lat, "lon": lon, "name": name,
            "category": category, "description": description,
        })
        return mid

    def remove_marker(self, marker_id: int) -> None:
        """Remove a marker by ID."""
        self._js(f"removeMarker({marker_id})")
        self._bridge._marker_data.pop(marker_id, None)

    def clear_markers(self) -> None:
        """Remove all markers."""
        self._js("clearMarkers()")
        self._bridge.clear_marker_registry()

    def draw_route(self, latlngs: list[list[float]], color: str = "#38BDF8") -> None:
        """Draw a route polyline. latlngs: [[lat,lon], ...]"""
        js_coords = json.dumps(latlngs)
        js_color  = json.dumps(color)
        self._js(f"drawRoute({js_coords}, {js_color})")

    def clear_route(self) -> None:
        self._js("clearRoute()")

    def clear_all(self) -> None:
        self._js("clearAll()")
        self._bridge.clear_marker_registry()

    def fit_bounds(self, latlngs: list[list[float]]) -> None:
        js_coords = json.dumps(latlngs)
        self._js(f"fitBounds({js_coords})")

    def show_popup(self, lat: float, lon: float, html: str) -> None:
        js_html = json.dumps(html)
        self._js(f"showPopup({lat}, {lon}, {js_html})")

    def add_stop_marker(self, lat: float, lon: float, label: str, order: int) -> int:
        return self.add_marker(lat, lon, label, f"Stop {order+1}", "", 0, "stop")

    def add_journal_marker(self, lat: float, lon: float, title: str) -> int:
        return self.add_marker(lat, lon, title, "Journal", "", 0, "journal")

    def get_bridge(self) -> MapBridge:
        return self._bridge
